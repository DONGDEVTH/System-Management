package Win32::Job;

use strict;
use warnings;

1;
