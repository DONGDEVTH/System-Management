package Win32;

use strict;
use warnings;

1;
