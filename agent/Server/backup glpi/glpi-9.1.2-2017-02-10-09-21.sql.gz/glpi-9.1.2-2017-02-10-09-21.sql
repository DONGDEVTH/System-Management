#GLPI Dump database on 2017-02-10 09:21

### Dump table glpi_alerts

DROP TABLE IF EXISTS `glpi_alerts`;
CREATE TABLE `glpi_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php ALERT_* constant',
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`type`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_apiclients

DROP TABLE IF EXISTS `glpi_apiclients`;
CREATE TABLE `glpi_apiclients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `ipv4_range_start` bigint(20) DEFAULT NULL,
  `ipv4_range_end` bigint(20) DEFAULT NULL,
  `ipv6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token_date` datetime DEFAULT NULL,
  `dolog_method` tinyint(4) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_apiclients` VALUES ('1','0','1','full access from localhost',NULL,'1','2130706433','2130706433','::1','',NULL,'0',NULL);

### Dump table glpi_authldapreplicates

DROP TABLE IF EXISTS `glpi_authldapreplicates`;
CREATE TABLE `glpi_authldapreplicates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authldaps_id` (`authldaps_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_authldaps

DROP TABLE IF EXISTS `glpi_authldaps`;
CREATE TABLE `glpi_authldaps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rootdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `condition` text COLLATE utf8_unicode_ci,
  `login_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'uid',
  `use_tls` tinyint(1) NOT NULL DEFAULT '0',
  `group_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group_condition` text COLLATE utf8_unicode_ci,
  `group_search_type` int(11) NOT NULL DEFAULT '0',
  `group_member_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email1_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_dn` tinyint(1) NOT NULL DEFAULT '1',
  `time_offset` int(11) NOT NULL DEFAULT '0' COMMENT 'in seconds',
  `deref_option` int(11) NOT NULL DEFAULT '0',
  `title_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_condition` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `rootdn_passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_number_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email3_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email4_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagesize` int(11) NOT NULL DEFAULT '0',
  `ldap_maxlimit` int(11) NOT NULL DEFAULT '0',
  `can_support_pagesize` tinyint(1) NOT NULL DEFAULT '0',
  `picture_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_default` (`is_default`),
  KEY `is_active` (`is_active`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_authmails

DROP TABLE IF EXISTS `glpi_authmails`;
CREATE TABLE `glpi_authmails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `connect_string` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_autoupdatesystems

DROP TABLE IF EXISTS `glpi_autoupdatesystems`;
CREATE TABLE `glpi_autoupdatesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklistedmailcontents

DROP TABLE IF EXISTS `glpi_blacklistedmailcontents`;
CREATE TABLE `glpi_blacklistedmailcontents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklists

DROP TABLE IF EXISTS `glpi_blacklists`;
CREATE TABLE `glpi_blacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_blacklists` VALUES ('1','1','empty IP','',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('2','1','localhost','127.0.0.1',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('3','1','zero IP','0.0.0.0',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('4','2','empty MAC','',NULL,NULL,NULL);

### Dump table glpi_bookmarks

DROP TABLE IF EXISTS `glpi_bookmarks`;
CREATE TABLE `glpi_bookmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php BOOKMARK_* constant',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `is_private` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `query` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id` (`users_id`),
  KEY `is_private` (`is_private`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_bookmarks_users

DROP TABLE IF EXISTS `glpi_bookmarks_users`;
CREATE TABLE `glpi_bookmarks_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `bookmarks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`),
  KEY `bookmarks_id` (`bookmarks_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_budgets

DROP TABLE IF EXISTS `glpi_budgets`;
CREATE TABLE `glpi_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `budgettypes_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `begin_date` (`begin_date`),
  KEY `is_template` (`is_template`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `locations_id` (`locations_id`),
  KEY `budgettypes_id` (`budgettypes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_budgettypes

DROP TABLE IF EXISTS `glpi_budgettypes`;
CREATE TABLE `glpi_budgettypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendars

DROP TABLE IF EXISTS `glpi_calendars`;
CREATE TABLE `glpi_calendars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `cache_duration` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendars` VALUES ('1','Default','0','1','Default calendar',NULL,'[0,43200,43200,43200,43200,43200,0]',NULL);

### Dump table glpi_calendars_holidays

DROP TABLE IF EXISTS `glpi_calendars_holidays`;
CREATE TABLE `glpi_calendars_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `holidays_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`calendars_id`,`holidays_id`),
  KEY `holidays_id` (`holidays_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendarsegments

DROP TABLE IF EXISTS `glpi_calendarsegments`;
CREATE TABLE `glpi_calendarsegments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `day` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'numer of the day based on date(w)',
  `begin` time DEFAULT NULL,
  `end` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendars_id` (`calendars_id`),
  KEY `day` (`day`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendarsegments` VALUES ('1','1','0','0','1','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('2','1','0','0','2','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('3','1','0','0','3','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('4','1','0','0','4','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('5','1','0','0','5','08:00:00','20:00:00');

### Dump table glpi_cartridgeitems

DROP TABLE IF EXISTS `glpi_cartridgeitems`;
CREATE TABLE `glpi_cartridgeitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `cartridgeitemtypes_id` (`cartridgeitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridgeitems_printermodels

DROP TABLE IF EXISTS `glpi_cartridgeitems_printermodels`;
CREATE TABLE `glpi_cartridgeitems_printermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printermodels_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`printermodels_id`,`cartridgeitems_id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridgeitemtypes

DROP TABLE IF EXISTS `glpi_cartridgeitemtypes`;
CREATE TABLE `glpi_cartridgeitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridges

DROP TABLE IF EXISTS `glpi_cartridges`;
CREATE TABLE `glpi_cartridges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printers_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_use` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `pages` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`),
  KEY `printers_id` (`printers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changecosts

DROP TABLE IF EXISTS `glpi_changecosts`;
CREATE TABLE `glpi_changecosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `changes_id` (`changes_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes

DROP TABLE IF EXISTS `glpi_changes`;
CREATE TABLE `glpi_changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `content` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `impactcontent` longtext COLLATE utf8_unicode_ci,
  `controlistcontent` longtext COLLATE utf8_unicode_ci,
  `rolloutplancontent` longtext COLLATE utf8_unicode_ci,
  `backoutplancontent` longtext COLLATE utf8_unicode_ci,
  `checklistcontent` longtext COLLATE utf8_unicode_ci,
  `global_validation` int(11) NOT NULL DEFAULT '1',
  `validation_percent` int(11) NOT NULL DEFAULT '0',
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin_waiting_date` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `date_mod` (`date_mod`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `due_date` (`due_date`),
  KEY `global_validation` (`global_validation`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_groups

DROP TABLE IF EXISTS `glpi_changes_groups`;
CREATE TABLE `glpi_changes_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_items

DROP TABLE IF EXISTS `glpi_changes_items`;
CREATE TABLE `glpi_changes_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_problems

DROP TABLE IF EXISTS `glpi_changes_problems`;
CREATE TABLE `glpi_changes_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `problems_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`problems_id`),
  KEY `problems_id` (`problems_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_projects

DROP TABLE IF EXISTS `glpi_changes_projects`;
CREATE TABLE `glpi_changes_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`projects_id`),
  KEY `projects_id` (`projects_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_suppliers

DROP TABLE IF EXISTS `glpi_changes_suppliers`;
CREATE TABLE `glpi_changes_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_tickets

DROP TABLE IF EXISTS `glpi_changes_tickets`;
CREATE TABLE `glpi_changes_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_users

DROP TABLE IF EXISTS `glpi_changes_users`;
CREATE TABLE `glpi_changes_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changetasks

DROP TABLE IF EXISTS `glpi_changetasks`;
CREATE TABLE `glpi_changetasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `changes_id` (`changes_id`),
  KEY `state` (`state`),
  KEY `users_id` (`users_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `taskcategories_id` (`taskcategories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changevalidations

DROP TABLE IF EXISTS `glpi_changevalidations`;
CREATE TABLE `glpi_changevalidations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id_validate` int(11) NOT NULL DEFAULT '0',
  `comment_submission` text COLLATE utf8_unicode_ci,
  `comment_validation` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `submission_date` datetime DEFAULT NULL,
  `validation_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `users_id` (`users_id`),
  KEY `users_id_validate` (`users_id_validate`),
  KEY `changes_id` (`changes_id`),
  KEY `submission_date` (`submission_date`),
  KEY `validation_date` (`validation_date`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computerantiviruses

DROP TABLE IF EXISTS `glpi_computerantiviruses`;
CREATE TABLE `glpi_computerantiviruses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `antivirus_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `signature_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_uptodate` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_expiration` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `antivirus_version` (`antivirus_version`),
  KEY `signature_version` (`signature_version`),
  KEY `is_active` (`is_active`),
  KEY `is_uptodate` (`is_uptodate`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `is_deleted` (`is_deleted`),
  KEY `computers_id` (`computers_id`),
  KEY `date_expiration` (`date_expiration`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computerdisks

DROP TABLE IF EXISTS `glpi_computerdisks`;
CREATE TABLE `glpi_computerdisks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mountpoint` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesystems_id` int(11) NOT NULL DEFAULT '0',
  `totalsize` int(11) NOT NULL DEFAULT '0',
  `freesize` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `device` (`device`),
  KEY `mountpoint` (`mountpoint`),
  KEY `totalsize` (`totalsize`),
  KEY `freesize` (`freesize`),
  KEY `computers_id` (`computers_id`),
  KEY `filesystems_id` (`filesystems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computermodels

DROP TABLE IF EXISTS `glpi_computermodels`;
CREATE TABLE `glpi_computermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers

DROP TABLE IF EXISTS `glpi_computers`;
CREATE TABLE `glpi_computers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `operatingsystems_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemversions_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemservicepacks_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemarchitectures_id` int(11) NOT NULL DEFAULT '0',
  `os_license_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os_licenseid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os_kernel_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autoupdatesystems_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `computermodels_id` int(11) NOT NULL DEFAULT '0',
  `computertypes_id` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `computermodels_id` (`computermodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `operatingsystems_id` (`operatingsystems_id`),
  KEY `operatingsystemservicepacks_id` (`operatingsystemservicepacks_id`),
  KEY `operatingsystemversions_id` (`operatingsystemversions_id`),
  KEY `operatingsystemarchitectures_id` (`operatingsystemarchitectures_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `computertypes_id` (`computertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `uuid` (`uuid`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_items

DROP TABLE IF EXISTS `glpi_computers_items`;
CREATE TABLE `glpi_computers_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to itemtype (ID)',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_softwarelicenses

DROP TABLE IF EXISTS `glpi_computers_softwarelicenses`;
CREATE TABLE `glpi_computers_softwarelicenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwarelicenses_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`computers_id`,`softwarelicenses_id`),
  KEY `computers_id` (`computers_id`),
  KEY `softwarelicenses_id` (`softwarelicenses_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_softwareversions

DROP TABLE IF EXISTS `glpi_computers_softwareversions`;
CREATE TABLE `glpi_computers_softwareversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwareversions_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted_computer` tinyint(1) NOT NULL DEFAULT '0',
  `is_template_computer` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_install` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`computers_id`,`softwareversions_id`),
  KEY `softwareversions_id` (`softwareversions_id`),
  KEY `computers_info` (`entities_id`,`is_template_computer`,`is_deleted_computer`),
  KEY `is_template` (`is_template_computer`),
  KEY `is_deleted` (`is_deleted_computer`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_install` (`date_install`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computertypes

DROP TABLE IF EXISTS `glpi_computertypes`;
CREATE TABLE `glpi_computertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computervirtualmachines

DROP TABLE IF EXISTS `glpi_computervirtualmachines`;
CREATE TABLE `glpi_computervirtualmachines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `virtualmachinestates_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinesystems_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinetypes_id` int(11) NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vcpu` int(11) NOT NULL DEFAULT '0',
  `ram` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `virtualmachinestates_id` (`virtualmachinestates_id`),
  KEY `virtualmachinesystems_id` (`virtualmachinesystems_id`),
  KEY `vcpu` (`vcpu`),
  KEY `ram` (`ram`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `uuid` (`uuid`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_configs

DROP TABLE IF EXISTS `glpi_configs`;
CREATE TABLE `glpi_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `context` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`context`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_configs` VALUES ('1','core','version','9.1.2');
INSERT INTO `glpi_configs` VALUES ('2','core','show_jobs_at_login','0');
INSERT INTO `glpi_configs` VALUES ('3','core','cut','250');
INSERT INTO `glpi_configs` VALUES ('4','core','list_limit','15');
INSERT INTO `glpi_configs` VALUES ('5','core','list_limit_max','50');
INSERT INTO `glpi_configs` VALUES ('6','core','url_maxlength','30');
INSERT INTO `glpi_configs` VALUES ('7','core','event_loglevel','5');
INSERT INTO `glpi_configs` VALUES ('8','core','use_mailing','1');
INSERT INTO `glpi_configs` VALUES ('9','core','admin_email','suthamtg@gmail.com');
INSERT INTO `glpi_configs` VALUES ('10','core','admin_email_name','DONG');
INSERT INTO `glpi_configs` VALUES ('11','core','admin_reply','suthamtg@gmail.com');
INSERT INTO `glpi_configs` VALUES ('12','core','admin_reply_name','');
INSERT INTO `glpi_configs` VALUES ('13','core','mailing_signature','SIGNATURE');
INSERT INTO `glpi_configs` VALUES ('14','core','use_anonymous_helpdesk','0');
INSERT INTO `glpi_configs` VALUES ('15','core','use_anonymous_followups','0');
INSERT INTO `glpi_configs` VALUES ('16','core','language','en_GB');
INSERT INTO `glpi_configs` VALUES ('17','core','priority_1','#fff2f2');
INSERT INTO `glpi_configs` VALUES ('18','core','priority_2','#ffe0e0');
INSERT INTO `glpi_configs` VALUES ('19','core','priority_3','#ffcece');
INSERT INTO `glpi_configs` VALUES ('20','core','priority_4','#ffbfbf');
INSERT INTO `glpi_configs` VALUES ('21','core','priority_5','#ffadad');
INSERT INTO `glpi_configs` VALUES ('22','core','priority_6','#ff5555');
INSERT INTO `glpi_configs` VALUES ('23','core','date_tax','2005-12-31');
INSERT INTO `glpi_configs` VALUES ('24','core','cas_host','');
INSERT INTO `glpi_configs` VALUES ('25','core','cas_port','443');
INSERT INTO `glpi_configs` VALUES ('26','core','cas_uri','');
INSERT INTO `glpi_configs` VALUES ('27','core','cas_logout','');
INSERT INTO `glpi_configs` VALUES ('28','core','existing_auth_server_field_clean_domain','0');
INSERT INTO `glpi_configs` VALUES ('29','core','planning_begin','08:00:00');
INSERT INTO `glpi_configs` VALUES ('30','core','planning_end','20:00:00');
INSERT INTO `glpi_configs` VALUES ('31','core','utf8_conv','1');
INSERT INTO `glpi_configs` VALUES ('32','core','use_public_faq','0');
INSERT INTO `glpi_configs` VALUES ('33','core','url_base','http://itkamala.com/glpi');
INSERT INTO `glpi_configs` VALUES ('34','core','show_link_in_mail','0');
INSERT INTO `glpi_configs` VALUES ('35','core','text_login','');
INSERT INTO `glpi_configs` VALUES ('36','core','founded_new_version','');
INSERT INTO `glpi_configs` VALUES ('37','core','dropdown_max','100');
INSERT INTO `glpi_configs` VALUES ('38','core','ajax_wildcard','*');
INSERT INTO `glpi_configs` VALUES ('42','core','ajax_limit_count','50');
INSERT INTO `glpi_configs` VALUES ('43','core','use_ajax_autocompletion','1');
INSERT INTO `glpi_configs` VALUES ('44','core','is_users_auto_add','1');
INSERT INTO `glpi_configs` VALUES ('45','core','date_format','0');
INSERT INTO `glpi_configs` VALUES ('46','core','number_format','0');
INSERT INTO `glpi_configs` VALUES ('47','core','csv_delimiter',';');
INSERT INTO `glpi_configs` VALUES ('48','core','is_ids_visible','0');
INSERT INTO `glpi_configs` VALUES ('50','core','smtp_mode','3');
INSERT INTO `glpi_configs` VALUES ('51','core','smtp_host','smtp.gmail.com');
INSERT INTO `glpi_configs` VALUES ('52','core','smtp_port','25');
INSERT INTO `glpi_configs` VALUES ('53','core','smtp_username','suthamtg@gmail.com');
INSERT INTO `glpi_configs` VALUES ('54','core','proxy_name','');
INSERT INTO `glpi_configs` VALUES ('55','core','proxy_port','8080');
INSERT INTO `glpi_configs` VALUES ('56','core','proxy_user','');
INSERT INTO `glpi_configs` VALUES ('57','core','add_followup_on_update_ticket','1');
INSERT INTO `glpi_configs` VALUES ('58','core','keep_tickets_on_delete','0');
INSERT INTO `glpi_configs` VALUES ('59','core','time_step','5');
INSERT INTO `glpi_configs` VALUES ('60','core','decimal_number','2');
INSERT INTO `glpi_configs` VALUES ('61','core','helpdesk_doc_url','');
INSERT INTO `glpi_configs` VALUES ('62','core','central_doc_url','');
INSERT INTO `glpi_configs` VALUES ('63','core','documentcategories_id_forticket','0');
INSERT INTO `glpi_configs` VALUES ('64','core','monitors_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('65','core','phones_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('66','core','peripherals_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('67','core','printers_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('68','core','use_log_in_files','1');
INSERT INTO `glpi_configs` VALUES ('69','core','time_offset','0');
INSERT INTO `glpi_configs` VALUES ('70','core','is_contact_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('71','core','is_user_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('72','core','is_group_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('73','core','is_location_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('74','core','state_autoupdate_mode','0');
INSERT INTO `glpi_configs` VALUES ('75','core','is_contact_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('76','core','is_user_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('77','core','is_group_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('78','core','is_location_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('79','core','state_autoclean_mode','0');
INSERT INTO `glpi_configs` VALUES ('80','core','use_flat_dropdowntree','0');
INSERT INTO `glpi_configs` VALUES ('81','core','use_autoname_by_entity','1');
INSERT INTO `glpi_configs` VALUES ('84','core','softwarecategories_id_ondelete','1');
INSERT INTO `glpi_configs` VALUES ('85','core','x509_email_field','');
INSERT INTO `glpi_configs` VALUES ('86','core','x509_cn_restrict','');
INSERT INTO `glpi_configs` VALUES ('87','core','x509_o_restrict','');
INSERT INTO `glpi_configs` VALUES ('88','core','x509_ou_restrict','');
INSERT INTO `glpi_configs` VALUES ('89','core','default_mailcollector_filesize_max','2097152');
INSERT INTO `glpi_configs` VALUES ('90','core','followup_private','0');
INSERT INTO `glpi_configs` VALUES ('91','core','task_private','0');
INSERT INTO `glpi_configs` VALUES ('92','core','default_software_helpdesk_visible','1');
INSERT INTO `glpi_configs` VALUES ('93','core','names_format','0');
INSERT INTO `glpi_configs` VALUES ('94','core','default_graphtype','svg');
INSERT INTO `glpi_configs` VALUES ('95','core','default_requesttypes_id','1');
INSERT INTO `glpi_configs` VALUES ('96','core','use_noright_users_add','1');
INSERT INTO `glpi_configs` VALUES ('97','core','cron_limit','5');
INSERT INTO `glpi_configs` VALUES ('98','core','priority_matrix','{\"1\":{\"1\":1,\"2\":1,\"3\":2,\"4\":2,\"5\":2},\"2\":{\"1\":1,\"2\":2,\"3\":2,\"4\":3,\"5\":3},\"3\":{\"1\":2,\"2\":2,\"3\":3,\"4\":4,\"5\":4},\"4\":{\"1\":2,\"2\":3,\"3\":4,\"4\":4,\"5\":5},\"5\":{\"1\":2,\"2\":3,\"3\":4,\"4\":5,\"5\":5}}');
INSERT INTO `glpi_configs` VALUES ('99','core','urgency_mask','62');
INSERT INTO `glpi_configs` VALUES ('100','core','impact_mask','62');
INSERT INTO `glpi_configs` VALUES ('101','core','user_deleted_ldap','0');
INSERT INTO `glpi_configs` VALUES ('102','core','auto_create_infocoms','0');
INSERT INTO `glpi_configs` VALUES ('103','core','use_slave_for_search','0');
INSERT INTO `glpi_configs` VALUES ('104','core','proxy_passwd','');
INSERT INTO `glpi_configs` VALUES ('105','core','smtp_passwd','');
INSERT INTO `glpi_configs` VALUES ('106','core','transfers_id_auto','0');
INSERT INTO `glpi_configs` VALUES ('107','core','show_count_on_tabs','1');
INSERT INTO `glpi_configs` VALUES ('108','core','refresh_ticket_list','0');
INSERT INTO `glpi_configs` VALUES ('109','core','set_default_tech','1');
INSERT INTO `glpi_configs` VALUES ('110','core','allow_search_view','2');
INSERT INTO `glpi_configs` VALUES ('111','core','allow_search_all','1');
INSERT INTO `glpi_configs` VALUES ('112','core','allow_search_global','1');
INSERT INTO `glpi_configs` VALUES ('113','core','display_count_on_home','5');
INSERT INTO `glpi_configs` VALUES ('114','core','use_password_security','0');
INSERT INTO `glpi_configs` VALUES ('115','core','password_min_length','8');
INSERT INTO `glpi_configs` VALUES ('116','core','password_need_number','1');
INSERT INTO `glpi_configs` VALUES ('117','core','password_need_letter','1');
INSERT INTO `glpi_configs` VALUES ('118','core','password_need_caps','1');
INSERT INTO `glpi_configs` VALUES ('119','core','password_need_symbol','1');
INSERT INTO `glpi_configs` VALUES ('120','core','use_check_pref','0');
INSERT INTO `glpi_configs` VALUES ('121','core','notification_to_myself','1');
INSERT INTO `glpi_configs` VALUES ('122','core','duedateok_color','#06ff00');
INSERT INTO `glpi_configs` VALUES ('123','core','duedatewarning_color','#ffb800');
INSERT INTO `glpi_configs` VALUES ('124','core','duedatecritical_color','#ff0000');
INSERT INTO `glpi_configs` VALUES ('125','core','duedatewarning_less','20');
INSERT INTO `glpi_configs` VALUES ('126','core','duedatecritical_less','5');
INSERT INTO `glpi_configs` VALUES ('127','core','duedatewarning_unit','%');
INSERT INTO `glpi_configs` VALUES ('128','core','duedatecritical_unit','%');
INSERT INTO `glpi_configs` VALUES ('129','core','realname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('130','core','firstname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('131','core','email1_ssofield','');
INSERT INTO `glpi_configs` VALUES ('132','core','email2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('133','core','email3_ssofield','');
INSERT INTO `glpi_configs` VALUES ('134','core','email4_ssofield','');
INSERT INTO `glpi_configs` VALUES ('135','core','phone_ssofield','');
INSERT INTO `glpi_configs` VALUES ('136','core','phone2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('137','core','mobile_ssofield','');
INSERT INTO `glpi_configs` VALUES ('138','core','comment_ssofield','');
INSERT INTO `glpi_configs` VALUES ('139','core','title_ssofield','');
INSERT INTO `glpi_configs` VALUES ('140','core','category_ssofield','');
INSERT INTO `glpi_configs` VALUES ('141','core','language_ssofield','');
INSERT INTO `glpi_configs` VALUES ('142','core','entity_ssofield','');
INSERT INTO `glpi_configs` VALUES ('143','core','registration_number_ssofield','');
INSERT INTO `glpi_configs` VALUES ('144','core','ssovariables_id','0');
INSERT INTO `glpi_configs` VALUES ('145','core','translate_kb','0');
INSERT INTO `glpi_configs` VALUES ('146','core','translate_dropdowns','0');
INSERT INTO `glpi_configs` VALUES ('147','core','pdffont','helvetica');
INSERT INTO `glpi_configs` VALUES ('148','core','keep_devices_when_purging_item','0');
INSERT INTO `glpi_configs` VALUES ('149','core','maintenance_mode','0');
INSERT INTO `glpi_configs` VALUES ('150','core','maintenance_text','');
INSERT INTO `glpi_configs` VALUES ('151','core','use_rich_text','0');
INSERT INTO `glpi_configs` VALUES ('152','core','attach_ticket_documents_to_mail','0');
INSERT INTO `glpi_configs` VALUES ('153','core','backcreated','0');
INSERT INTO `glpi_configs` VALUES ('154','core','task_state','1');
INSERT INTO `glpi_configs` VALUES ('155','core','layout','lefttab');
INSERT INTO `glpi_configs` VALUES ('156','core','ticket_timeline','1');
INSERT INTO `glpi_configs` VALUES ('157','core','ticket_timeline_keep_replaced_tabs','0');
INSERT INTO `glpi_configs` VALUES ('158','core','palette','auror');
INSERT INTO `glpi_configs` VALUES ('159','core','lock_use_lock_item','0');
INSERT INTO `glpi_configs` VALUES ('160','core','lock_autolock_mode','1');
INSERT INTO `glpi_configs` VALUES ('161','core','lock_directunlock_notification','0');
INSERT INTO `glpi_configs` VALUES ('162','core','lock_item_list','[]');
INSERT INTO `glpi_configs` VALUES ('163','core','lock_lockprofile_id','8');
INSERT INTO `glpi_configs` VALUES ('164','core','set_default_requester','1');
INSERT INTO `glpi_configs` VALUES ('165','core','highcontrast_css','0');
INSERT INTO `glpi_configs` VALUES ('166','core','smtp_check_certificate','0');
INSERT INTO `glpi_configs` VALUES ('167','core','enable_api','0');
INSERT INTO `glpi_configs` VALUES ('168','core','enable_api_login_credentials','0');
INSERT INTO `glpi_configs` VALUES ('169','core','enable_api_login_external_token','1');
INSERT INTO `glpi_configs` VALUES ('170','core','url_base_api','http://itkamala.com/glpi/apirest.php/');
INSERT INTO `glpi_configs` VALUES ('171','core','_no_history','');
INSERT INTO `glpi_configs` VALUES ('172','core','_blank_smtp_passwd','on');

### Dump table glpi_consumableitems

DROP TABLE IF EXISTS `glpi_consumableitems`;
CREATE TABLE `glpi_consumableitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `consumableitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `consumableitemtypes_id` (`consumableitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumableitemtypes

DROP TABLE IF EXISTS `glpi_consumableitemtypes`;
CREATE TABLE `glpi_consumableitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumables

DROP TABLE IF EXISTS `glpi_consumables`;
CREATE TABLE `glpi_consumables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `consumableitems_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_in` (`date_in`),
  KEY `date_out` (`date_out`),
  KEY `consumableitems_id` (`consumableitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts

DROP TABLE IF EXISTS `glpi_contacts`;
CREATE TABLE `glpi_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contacttypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `usertitles_id` int(11) NOT NULL DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `contacttypes_id` (`contacttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `usertitles_id` (`usertitles_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts_suppliers

DROP TABLE IF EXISTS `glpi_contacts_suppliers`;
CREATE TABLE `glpi_contacts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contacts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contacts_id`),
  KEY `contacts_id` (`contacts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacttypes

DROP TABLE IF EXISTS `glpi_contacttypes`;
CREATE TABLE `glpi_contacttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contractcosts

DROP TABLE IF EXISTS `glpi_contractcosts`;
CREATE TABLE `glpi_contractcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `contracts_id` (`contracts_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts

DROP TABLE IF EXISTS `glpi_contracts`;
CREATE TABLE `glpi_contracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contracttypes_id` int(11) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `notice` int(11) NOT NULL DEFAULT '0',
  `periodicity` int(11) NOT NULL DEFAULT '0',
  `billing` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `accounting_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `week_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `week_end_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_saturday` tinyint(1) NOT NULL DEFAULT '0',
  `monday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `monday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_monday` tinyint(1) NOT NULL DEFAULT '0',
  `max_links_allowed` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `renewal` int(11) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `begin_date` (`begin_date`),
  KEY `name` (`name`),
  KEY `contracttypes_id` (`contracttypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `use_monday` (`use_monday`),
  KEY `use_saturday` (`use_saturday`),
  KEY `alert` (`alert`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_items

DROP TABLE IF EXISTS `glpi_contracts_items`;
CREATE TABLE `glpi_contracts_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`contracts_id`,`itemtype`,`items_id`),
  KEY `FK_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_suppliers

DROP TABLE IF EXISTS `glpi_contracts_suppliers`;
CREATE TABLE `glpi_contracts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contracts_id`),
  KEY `contracts_id` (`contracts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracttypes

DROP TABLE IF EXISTS `glpi_contracttypes`;
CREATE TABLE `glpi_contracttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_crontasklogs

DROP TABLE IF EXISTS `glpi_crontasklogs`;
CREATE TABLE `glpi_crontasklogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crontasks_id` int(11) NOT NULL,
  `crontasklogs_id` int(11) NOT NULL COMMENT 'id of ''start'' event',
  `date` datetime NOT NULL,
  `state` int(11) NOT NULL COMMENT '0:start, 1:run, 2:stop',
  `elapsed` float NOT NULL COMMENT 'time elapsed since start',
  `volume` int(11) NOT NULL COMMENT 'for statistics',
  `content` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'message',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `crontasks_id` (`crontasks_id`),
  KEY `crontasklogs_id_state` (`crontasklogs_id`,`state`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_crontasklogs` VALUES ('1','18','0','2017-02-05 03:24:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('2','18','1','2017-02-05 03:24:53','2','0.038353','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('3','19','0','2017-02-05 03:26:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('4','19','3','2017-02-05 03:26:21','2','0.00191212','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('5','20','0','2017-02-05 03:30:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('6','20','5','2017-02-05 03:30:28','2','0.00172305','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('7','21','0','2017-02-05 03:30:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('8','21','7','2017-02-05 03:30:48','2','0.00136399','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('9','22','0','2017-02-05 03:43:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('10','22','9','2017-02-05 03:43:40','2','0.00153399','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('11','23','0','2017-02-05 03:52:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('12','23','11','2017-02-05 03:52:26','2','0.12289','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('13','24','0','2017-02-05 05:55:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('14','24','13','2017-02-05 05:55:30','1','0.0885561','1','Clean 1 temporary file created since more than 3600 seconds
');
INSERT INTO `glpi_crontasklogs` VALUES ('15','24','13','2017-02-05 05:55:30','2','0.089206','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('16','25','0','2017-02-05 06:30:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('17','25','16','2017-02-05 06:30:38','2','0.00155711','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('18','5','0','2017-02-05 12:42:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('19','5','18','2017-02-05 12:42:53','2','0.00208902','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('20','6','0','2017-02-05 13:20:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('21','6','20','2017-02-05 13:20:04','2','0.00135303','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('22','8','0','2017-02-05 13:20:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('23','8','22','2017-02-05 13:20:35','2','0.307256','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('24','9','0','2017-02-06 01:40:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('25','9','24','2017-02-06 01:40:45','2','0.134441','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('26','12','0','2017-02-06 03:01:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('27','12','26','2017-02-06 03:01:06','1','0.001791','12','Clean 12 session files created since more than 1440 seconds
');
INSERT INTO `glpi_crontasklogs` VALUES ('28','12','26','2017-02-06 03:01:06','2','0.00227404','12','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('29','13','0','2017-02-06 04:13:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('30','13','29','2017-02-06 04:13:23','1','0.0285759','1','Clean 1 graph file created since more than 3600 seconds
');
INSERT INTO `glpi_crontasklogs` VALUES ('31','13','29','2017-02-06 04:13:23','2','0.0292089','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('32','14','0','2017-02-06 04:19:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('33','14','32','2017-02-06 04:19:26','2','0.00141501','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('34','15','0','2017-02-06 04:22:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('35','15','34','2017-02-06 04:22:31','2','0.00217104','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('36','16','0','2017-02-06 04:27:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('37','16','36','2017-02-06 04:27:41','2','0.00149393','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('38','17','0','2017-02-06 04:33:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('39','17','38','2017-02-06 04:33:04','2','0.0470662','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('40','21','0','2017-02-06 04:38:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('41','21','40','2017-02-06 04:38:11','2','0.00150299','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('42','22','0','2017-02-06 04:45:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('43','22','42','2017-02-06 04:45:09','2','0.00145602','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('44','20','0','2017-02-06 04:46:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('45','20','44','2017-02-06 04:46:03','2','0.0017879','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('46','24','0','2017-02-06 04:48:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('47','24','46','2017-02-06 04:48:55','2','0.0162959','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('48','9','0','2017-02-06 05:09:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('49','9','48','2017-02-06 05:09:32','2','0.0024581','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('50','18','0','2017-02-06 05:14:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('51','18','50','2017-02-06 05:14:34','2','0.00316882','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('52','19','0','2017-02-06 05:23:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('53','19','52','2017-02-06 05:23:27','2','0.00176692','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('54','23','0','2017-02-06 06:26:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('55','23','54','2017-02-06 06:26:10','2','0.00212884','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('56','17','0','2017-02-07 03:56:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('57','17','56','2017-02-07 03:56:07','2','0.224174','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('58','21','0','2017-02-07 04:51:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('59','21','58','2017-02-07 04:51:34','2','0.00144696','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('60','22','0','2017-02-07 04:52:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('61','22','60','2017-02-07 04:52:32','2','0.00156689','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('62','13','0','2017-02-07 06:23:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('63','13','62','2017-02-07 06:23:29','1','0.00301504','24','Clean 24 graph files created since more than 3600 seconds
');
INSERT INTO `glpi_crontasklogs` VALUES ('64','13','62','2017-02-07 06:23:29','2','0.00350904','24','Action completed, fully processed');

### Dump table glpi_crontasks

DROP TABLE IF EXISTS `glpi_crontasks`;
CREATE TABLE `glpi_crontasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL COMMENT 'task name',
  `frequency` int(11) NOT NULL COMMENT 'second between launch',
  `param` int(11) DEFAULT NULL COMMENT 'task specify parameter',
  `state` int(11) NOT NULL DEFAULT '1' COMMENT '0:disabled, 1:waiting, 2:running',
  `mode` int(11) NOT NULL DEFAULT '1' COMMENT '1:internal, 2:external',
  `allowmode` int(11) NOT NULL DEFAULT '3' COMMENT '1:internal, 2:external, 3:both',
  `hourmin` int(11) NOT NULL DEFAULT '0',
  `hourmax` int(11) NOT NULL DEFAULT '24',
  `logs_lifetime` int(11) NOT NULL DEFAULT '30' COMMENT 'number of days',
  `lastrun` datetime DEFAULT NULL COMMENT 'last run date',
  `lastcode` int(11) DEFAULT NULL COMMENT 'last run return code',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`name`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Task run by internal / external cron.';

INSERT INTO `glpi_crontasks` VALUES ('2','CartridgeItem','cartridge','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('3','ConsumableItem','consumable','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('4','SoftwareLicense','software','86400',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('5','Contract','contract','86400',NULL,'1','1','3','0','24','30','2017-02-08 01:20:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('6','InfoCom','infocom','86400',NULL,'1','1','3','0','24','30','2017-02-08 01:25:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('7','CronTask','logs','86400','30','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('8','CronTask','optimize','604800',NULL,'1','1','3','0','24','30','2017-02-05 13:20:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('9','MailCollector','mailgate','600','10','1','1','3','0','24','30','2017-02-10 09:08:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('10','DBconnection','checkdbreplicate','300',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('11','CronTask','checkupdate','604800',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('12','CronTask','session','86400',NULL,'1','1','3','0','24','30','2017-02-08 01:34:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('13','CronTask','graph','3600',NULL,'1','1','3','0','24','30','2017-02-10 09:14:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('14','ReservationItem','reservation','3600',NULL,'1','1','3','0','24','30','2017-02-10 09:19:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('15','Ticket','closeticket','43200',NULL,'1','1','3','0','24','30','2017-02-08 01:28:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('16','Ticket','alertnotclosed','43200',NULL,'1','1','3','0','24','30','2017-02-08 01:29:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('17','SlaLevel_Ticket','slaticket','300',NULL,'1','1','3','0','24','30','2017-02-10 09:08:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('18','Ticket','createinquest','86400',NULL,'1','1','3','0','24','30','2017-02-08 01:55:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('19','Crontask','watcher','86400',NULL,'1','1','3','0','24','30','2017-02-08 02:00:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('20','TicketRecurrent','ticketrecurrent','3600',NULL,'1','1','3','0','24','30','2017-02-08 12:23:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('21','PlanningRecall','planningrecall','300',NULL,'1','1','3','0','24','30','2017-02-10 09:19:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('22','QueuedMail','queuedmail','60','50','1','1','3','0','24','30','2017-02-10 05:11:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('23','QueuedMail','queuedmailclean','86400','30','1','1','3','0','24','30','2017-02-08 02:07:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('24','Crontask','temp','3600',NULL,'1','1','3','0','24','30','2017-02-08 12:29:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('25','MailCollector','mailgateerror','86400',NULL,'1','1','3','0','24','30','2017-02-08 01:19:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('26','Crontask','circularlogs','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('27','ObjectLock','unlockobject','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);

### Dump table glpi_devicecases

DROP TABLE IF EXISTS `glpi_devicecases`;
CREATE TABLE `glpi_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecasetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicecasetypes_id` (`devicecasetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecasetypes

DROP TABLE IF EXISTS `glpi_devicecasetypes`;
CREATE TABLE `glpi_devicecasetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecontrols

DROP TABLE IF EXISTS `glpi_devicecontrols`;
CREATE TABLE `glpi_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_raid` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicedrives

DROP TABLE IF EXISTS `glpi_devicedrives`;
CREATE TABLE `glpi_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_writer` tinyint(1) NOT NULL DEFAULT '1',
  `speed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegraphiccards

DROP TABLE IF EXISTS `glpi_devicegraphiccards`;
CREATE TABLE `glpi_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `memory_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `chipset` (`chipset`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceharddrives

DROP TABLE IF EXISTS `glpi_deviceharddrives`;
CREATE TABLE `glpi_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rpm` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `cache` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `capacity_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememories

DROP TABLE IF EXISTS `glpi_devicememories`;
CREATE TABLE `glpi_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `size_default` int(11) NOT NULL DEFAULT '0',
  `devicememorytypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicememorytypes_id` (`devicememorytypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememorytypes

DROP TABLE IF EXISTS `glpi_devicememorytypes`;
CREATE TABLE `glpi_devicememorytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicememorytypes` VALUES ('1','EDO',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('2','DDR',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('3','SDRAM',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('4','SDRAM-2',NULL,NULL,NULL);

### Dump table glpi_devicemotherboards

DROP TABLE IF EXISTS `glpi_devicemotherboards`;
CREATE TABLE `glpi_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicenetworkcards

DROP TABLE IF EXISTS `glpi_devicenetworkcards`;
CREATE TABLE `glpi_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bandwidth` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `mac_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepcis

DROP TABLE IF EXISTS `glpi_devicepcis`;
CREATE TABLE `glpi_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepowersupplies

DROP TABLE IF EXISTS `glpi_devicepowersupplies`;
CREATE TABLE `glpi_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `power` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_atx` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceprocessors

DROP TABLE IF EXISTS `glpi_deviceprocessors`;
CREATE TABLE `glpi_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `frequency_default` int(11) NOT NULL DEFAULT '0',
  `nbcores_default` int(11) DEFAULT NULL,
  `nbthreads_default` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesoundcards

DROP TABLE IF EXISTS `glpi_devicesoundcards`;
CREATE TABLE `glpi_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_displaypreferences

DROP TABLE IF EXISTS `glpi_displaypreferences`;
CREATE TABLE `glpi_displaypreferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`,`num`),
  KEY `rank` (`rank`),
  KEY `num` (`num`),
  KEY `itemtype` (`itemtype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_displaypreferences` VALUES ('32','Computer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('34','Computer','45','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('33','Computer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('31','Computer','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('30','Computer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('86','DocumentType','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('49','Monitor','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('50','Monitor','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('51','Monitor','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('52','Monitor','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('44','Printer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('38','NetworkEquipment','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('39','NetworkEquipment','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('45','Printer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('46','Printer','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('63','Software','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('62','Software','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('61','Software','23','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('83','CartridgeItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('82','CartridgeItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('57','Peripheral','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('56','Peripheral','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('55','Peripheral','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('29','Computer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('35','Computer','3','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('36','Computer','19','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('37','Computer','17','9','0');
INSERT INTO `glpi_displaypreferences` VALUES ('40','NetworkEquipment','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('41','NetworkEquipment','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('42','NetworkEquipment','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('43','NetworkEquipment','19','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('47','Printer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('48','Printer','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('53','Monitor','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('54','Monitor','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('58','Peripheral','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('59','Peripheral','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('60','Peripheral','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('64','Contact','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('65','Contact','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('66','Contact','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('67','Contact','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('68','Contact','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('69','Supplier','9','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('70','Supplier','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('71','Supplier','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('72','Supplier','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('73','Supplier','10','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('74','Supplier','6','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('75','Contract','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('76','Contract','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('77','Contract','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('78','Contract','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('79','Contract','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('80','Contract','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('84','CartridgeItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('85','CartridgeItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('88','DocumentType','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('89','DocumentType','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('90','DocumentType','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('91','Document','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('92','Document','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('93','Document','7','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('94','Document','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('95','Document','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('96','User','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('98','User','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('99','User','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('100','User','3','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('101','ConsumableItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('102','ConsumableItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('103','ConsumableItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('104','ConsumableItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('105','NetworkEquipment','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('106','Printer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('107','Monitor','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('108','Peripheral','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('109','User','8','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('110','Phone','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('111','Phone','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('112','Phone','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('113','Phone','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('114','Phone','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('115','Phone','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('116','Phone','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('117','Group','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('118','AllAssets','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('119','ReservationItem','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('120','ReservationItem','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('125','Budget','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('122','Software','72','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('123','Software','163','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('124','Budget','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('126','Budget','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('127','Budget','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('128','Crontask','8','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('129','Crontask','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('130','Crontask','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('131','Crontask','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('132','RequestType','14','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('133','RequestType','15','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('134','NotificationTemplate','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('135','NotificationTemplate','16','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('136','Notification','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('137','Notification','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('138','Notification','2','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('139','Notification','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('140','Notification','80','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('141','Notification','86','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('142','MailCollector','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('143','MailCollector','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('144','AuthLDAP','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('145','AuthLDAP','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('146','AuthMail','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('147','AuthMail','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('210','IPNetwork','14','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('209','WifiNetwork','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('150','Profile','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('151','Profile','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('152','Profile','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('153','Transfer','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('154','TicketValidation','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('155','TicketValidation','2','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('156','TicketValidation','8','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('157','TicketValidation','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('158','TicketValidation','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('159','TicketValidation','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('160','NotImportedEmail','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('161','NotImportedEmail','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('162','NotImportedEmail','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('163','NotImportedEmail','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('164','NotImportedEmail','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('165','NotImportedEmail','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('166','RuleRightParameter','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('167','Ticket','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('168','Ticket','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('169','Ticket','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('170','Ticket','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('171','Ticket','4','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('172','Ticket','5','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('173','Ticket','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('174','Calendar','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('175','Holiday','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('176','Holiday','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('177','Holiday','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('178','SLA','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('179','Ticket','18','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('180','AuthLdap','30','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('181','AuthMail','6','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('208','FQDN','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('183','FieldUnicity','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('184','FieldUnicity','80','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('185','FieldUnicity','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('186','FieldUnicity','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('187','FieldUnicity','86','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('188','FieldUnicity','30','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('189','Problem','21','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('190','Problem','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('191','Problem','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('192','Problem','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('193','Problem','3','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('194','Problem','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('195','Problem','18','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('196','Vlan','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('197','TicketRecurrent','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('198','TicketRecurrent','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('199','TicketRecurrent','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('200','TicketRecurrent','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('201','TicketRecurrent','14','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('202','Reminder','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('203','Reminder','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('204','Reminder','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('205','Reminder','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('206','Reminder','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('207','Reminder','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('211','IPNetwork','10','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('212','IPNetwork','11','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('213','IPNetwork','12','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('214','IPNetwork','13','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('215','NetworkName','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('216','NetworkName','13','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('217','RSSFeed','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('218','RSSFeed','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('219','RSSFeed','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('220','RSSFeed','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('221','RSSFeed','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('222','RSSFeed','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('223','Blacklist','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('224','Blacklist','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('225','ReservationItem','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('226','QueueMail','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('227','QueueMail','7','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('228','QueueMail','20','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('229','QueueMail','21','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('230','QueueMail','22','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('231','QueueMail','15','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('232','Change','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('233','Change','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('234','Change','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('235','Change','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('236','Change','18','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('237','Project','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('238','Project','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('239','Project','12','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('240','Project','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('241','Project','15','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('242','Project','21','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('243','ProjectState','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('244','ProjectState','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('245','ProjectTask','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('246','ProjectTask','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('247','ProjectTask','14','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('248','ProjectTask','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('249','ProjectTask','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('250','ProjectTask','8','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('251','ProjectTask','13','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('252','CartridgeItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('253','ConsumableItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('254','ReservationItem','9','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('255','SoftwareLicense','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('256','SoftwareLicense','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('257','SoftwareLicense','10','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('258','SoftwareLicense','162','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('259','SoftwareLicense','5','5','0');

### Dump table glpi_documentcategories

DROP TABLE IF EXISTS `glpi_documentcategories`;
CREATE TABLE `glpi_documentcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `unicity` (`documentcategories_id`,`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_documents

DROP TABLE IF EXISTS `glpi_documents`;
CREATE TABLE `glpi_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'for display and transfert',
  `filepath` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'file storage path',
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `sha1sum` char(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_blacklisted` tinyint(1) NOT NULL DEFAULT '0',
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `users_id` (`users_id`),
  KEY `documentcategories_id` (`documentcategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `sha1sum` (`sha1sum`),
  KEY `tag` (`tag`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_documents_items

DROP TABLE IF EXISTS `glpi_documents_items`;
CREATE TABLE `glpi_documents_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `documents_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`documents_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`,`entities_id`,`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_documenttypes

DROP TABLE IF EXISTS `glpi_documenttypes`;
CREATE TABLE `glpi_documenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ext` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_uploadable` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ext`),
  KEY `name` (`name`),
  KEY `is_uploadable` (`is_uploadable`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documenttypes` VALUES ('1','JPEG','jpg','jpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('2','PNG','png','png-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('3','GIF','gif','gif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('4','BMP','bmp','bmp-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('5','Photoshop','psd','psd-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('6','TIFF','tif','tif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('7','AIFF','aiff','aiff-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('8','Windows Media','asf','asf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('9','Windows Media','avi','avi-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('44','C source','c','c-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('27','RealAudio','rm','rm-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('16','Midi','mid','mid-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('17','QuickTime','mov','mov-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('18','MP3','mp3','mp3-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('19','MPEG','mpg','mpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('20','Ogg Vorbis','ogg','ogg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('24','QuickTime','qt','qt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('10','BZip','bz2','bz2-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('25','RealAudio','ra','ra-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('26','RealAudio','ram','ram-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('11','Word','doc','doc-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('12','DjVu','djvu','','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('42','MNG','mng','','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('13','PostScript','eps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('14','GZ','gz','gz-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('37','WAV','wav','wav-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('15','HTML','html','html-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('34','Flash','swf','swf-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('21','PDF','pdf','pdf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('22','PowerPoint','ppt','ppt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('23','PostScript','ps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('40','Windows Media','wmv','wmv-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('28','RTF','rtf','rtf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('29','StarOffice','sdd','sdd-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('30','StarOffice','sdw','sdw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('31','Stuffit','sit','sit-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('43','Adobe Illustrator','ai','ai-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('32','OpenOffice Impress','sxi','sxi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('33','OpenOffice','sxw','sxw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('46','DVI','dvi','dvi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('35','TGZ','tgz','tgz-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('36','texte','txt','txt-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('49','RedHat/Mandrake/SuSE','rpm','rpm-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('38','Excel','xls','xls-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('39','XML','xml','xml-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('41','Zip','zip','zip-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('45','Debian','deb','deb-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('47','C header','h','h-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('48','Pascal','pas','pas-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('50','OpenOffice Calc','sxc','sxc-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('51','LaTeX','tex','tex-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('52','GIMP multi-layer','xcf','xcf-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('53','JPEG','jpeg','jpg-dist.png','','1','2005-03-07 22:23:17',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('54','Oasis Open Office Writer','odt','odt-dist.png','','1','2006-01-21 17:41:13',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('55','Oasis Open Office Calc','ods','ods-dist.png','','1','2006-01-21 17:41:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('56','Oasis Open Office Impress','odp','odp-dist.png','','1','2006-01-21 17:42:54',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('57','Oasis Open Office Impress Template','otp','odp-dist.png','','1','2006-01-21 17:43:58',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('58','Oasis Open Office Writer Template','ott','odt-dist.png','','1','2006-01-21 17:44:41',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('59','Oasis Open Office Calc Template','ots','ods-dist.png','','1','2006-01-21 17:45:30',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('60','Oasis Open Office Math','odf','odf-dist.png','','1','2006-01-21 17:48:05',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('61','Oasis Open Office Draw','odg','odg-dist.png','','1','2006-01-21 17:48:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('62','Oasis Open Office Draw Template','otg','odg-dist.png','','1','2006-01-21 17:49:46',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('63','Oasis Open Office Base','odb','odb-dist.png','','1','2006-01-21 18:03:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('64','Oasis Open Office HTML','oth','oth-dist.png','','1','2006-01-21 18:05:27',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('65','Oasis Open Office Writer Master','odm','odm-dist.png','','1','2006-01-21 18:06:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('66','Oasis Open Office Chart','odc','','','1','2006-01-21 18:07:48',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('67','Oasis Open Office Image','odi','','','1','2006-01-21 18:08:18',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('68','Word XML','docx','doc-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('69','Excel XML','xlsx','xls-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('70','PowerPoint XML','pptx','ppt-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('71','Comma-Separated Values','csv','csv-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('72','Scalable Vector Graphics','svg','svg-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);

### Dump table glpi_domains

DROP TABLE IF EXISTS `glpi_domains`;
CREATE TABLE `glpi_domains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_dropdowntranslations

DROP TABLE IF EXISTS `glpi_dropdowntranslations`;
CREATE TABLE `glpi_dropdowntranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`language`,`field`),
  KEY `typeid` (`itemtype`,`items_id`),
  KEY `language` (`language`),
  KEY `field` (`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities

DROP TABLE IF EXISTS `glpi_entities`;
CREATE TABLE `glpi_entities` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notification_subject_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_dn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `mail_domain` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_ldapfilter` text COLLATE utf8_unicode_ci,
  `mailing_signature` text COLLATE utf8_unicode_ci,
  `cartridges_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `consumables_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `use_licenses_alert` int(11) NOT NULL DEFAULT '-2',
  `send_licenses_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_contracts_alert` int(11) NOT NULL DEFAULT '-2',
  `send_contracts_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_infocoms_alert` int(11) NOT NULL DEFAULT '-2',
  `send_infocoms_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_reservations_alert` int(11) NOT NULL DEFAULT '-2',
  `autoclose_delay` int(11) NOT NULL DEFAULT '-2',
  `notclosed_delay` int(11) NOT NULL DEFAULT '-2',
  `calendars_id` int(11) NOT NULL DEFAULT '-2',
  `auto_assign_mode` int(11) NOT NULL DEFAULT '-2',
  `tickettype` int(11) NOT NULL DEFAULT '-2',
  `max_closedate` datetime DEFAULT NULL,
  `inquest_config` int(11) NOT NULL DEFAULT '-2',
  `inquest_rate` int(11) NOT NULL DEFAULT '0',
  `inquest_delay` int(11) NOT NULL DEFAULT '-10',
  `inquest_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autofill_warranty_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_use_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_buy_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_delivery_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_order_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '-2',
  `entities_id_software` int(11) NOT NULL DEFAULT '-2',
  `default_contract_alert` int(11) NOT NULL DEFAULT '-2',
  `default_infocom_alert` int(11) NOT NULL DEFAULT '-2',
  `default_cartridges_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `default_consumables_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `delay_send_emails` int(11) NOT NULL DEFAULT '-2',
  `is_notif_enable_default` int(11) NOT NULL DEFAULT '-2',
  `inquest_duration` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `autofill_decommission_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`name`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_entities` VALUES ('0','Root entity','-1','Root entity',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','-10','1',NULL,'1','0','0',NULL,'0','0','0','0','0','1','-10','0','0','10','10','0','1','0',NULL,NULL,'0');

### Dump table glpi_entities_knowbaseitems

DROP TABLE IF EXISTS `glpi_entities_knowbaseitems`;
CREATE TABLE `glpi_entities_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_reminders

DROP TABLE IF EXISTS `glpi_entities_reminders`;
CREATE TABLE `glpi_entities_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_rssfeeds

DROP TABLE IF EXISTS `glpi_entities_rssfeeds`;
CREATE TABLE `glpi_entities_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_events

DROP TABLE IF EXISTS `glpi_events`;
CREATE TABLE `glpi_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `service` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `level` (`level`),
  KEY `item` (`type`,`items_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_events` VALUES ('1','-1','system','2017-02-05 03:25:01','login','3','glpi logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('2','-1','system','2017-02-05 03:26:25','login','3','glpi logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('3','-1','system','2017-02-05 03:30:53','login','3','glpi logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('4','2','users','2017-02-05 03:32:14','setup','5','glpi updated item');
INSERT INTO `glpi_events` VALUES ('5','-1','system','2017-02-05 03:52:33','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('6','-1','system','2017-02-05 05:55:35','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('7','-1','system','2017-02-05 06:30:44','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('8','-1','system','2017-02-05 12:43:06','login','3','dong logged in from IP 192.168.2.197');
INSERT INTO `glpi_events` VALUES ('9','1','ITILCategory','2017-02-05 12:44:00','setup','4','dong added item Hardware');
INSERT INTO `glpi_events` VALUES ('10','2','ITILCategory','2017-02-05 12:44:15','setup','4','dong added item Computer');
INSERT INTO `glpi_events` VALUES ('11','3','ITILCategory','2017-02-05 12:44:30','setup','4','dong added item Monitor');
INSERT INTO `glpi_events` VALUES ('12','4','ITILCategory','2017-02-05 12:44:36','setup','4','dong added item Mouse');
INSERT INTO `glpi_events` VALUES ('13','5','ITILCategory','2017-02-05 12:44:45','setup','4','dong added item Keyboard');
INSERT INTO `glpi_events` VALUES ('14','6','ITILCategory','2017-02-05 12:46:26','setup','4','dong added item Line AC (สายไฟ)');
INSERT INTO `glpi_events` VALUES ('15','7','ITILCategory','2017-02-05 12:46:54','setup','4','dong added item Line VGA (สาย VGA)');
INSERT INTO `glpi_events` VALUES ('16','8','ITILCategory','2017-02-05 12:47:28','setup','4','dong added item Network');
INSERT INTO `glpi_events` VALUES ('17','9','ITILCategory','2017-02-05 12:47:35','setup','4','dong added item LAN');
INSERT INTO `glpi_events` VALUES ('18','10','ITILCategory','2017-02-05 12:47:45','setup','4','dong added item WIFI');
INSERT INTO `glpi_events` VALUES ('19','11','ITILCategory','2017-02-05 12:48:04','setup','4','dong added item ACCESS POINT');
INSERT INTO `glpi_events` VALUES ('20','12','ITILCategory','2017-02-05 12:48:12','setup','4','dong added item Router');
INSERT INTO `glpi_events` VALUES ('21','13','ITILCategory','2017-02-05 12:48:18','setup','4','dong added item Switch');
INSERT INTO `glpi_events` VALUES ('22','14','ITILCategory','2017-02-05 12:48:30','setup','4','dong added item Mikrotik');
INSERT INTO `glpi_events` VALUES ('23','15','ITILCategory','2017-02-05 12:48:37','setup','4','dong added item Hub');
INSERT INTO `glpi_events` VALUES ('24','16','ITILCategory','2017-02-05 12:49:00','setup','4','dong added item Ruckus');
INSERT INTO `glpi_events` VALUES ('25','17','ITILCategory','2017-02-05 12:49:07','setup','4','dong added item IBSG');
INSERT INTO `glpi_events` VALUES ('26','18','ITILCategory','2017-02-05 12:49:25','setup','4','dong added item Authen Newsoft');
INSERT INTO `glpi_events` VALUES ('27','19','ITILCategory','2017-02-05 12:49:49','setup','4','dong added item WAN');
INSERT INTO `glpi_events` VALUES ('28','20','ITILCategory','2017-02-05 12:50:22','setup','4','dong added item Access control limark');
INSERT INTO `glpi_events` VALUES ('29','21','ITILCategory','2017-02-05 12:50:47','setup','4','dong added item Fiber');
INSERT INTO `glpi_events` VALUES ('30','22','ITILCategory','2017-02-05 12:50:55','setup','4','dong added item UPS');
INSERT INTO `glpi_events` VALUES ('31','23','ITILCategory','2017-02-05 12:51:33','setup','4','dong added item Printer');
INSERT INTO `glpi_events` VALUES ('32','24','ITILCategory','2017-02-05 12:52:04','setup','4','dong added item Software');
INSERT INTO `glpi_events` VALUES ('33','25','ITILCategory','2017-02-05 12:52:55','setup','4','dong added item Newsoft');
INSERT INTO `glpi_events` VALUES ('34','26','ITILCategory','2017-02-05 12:53:06','setup','4','dong added item Antivirus');
INSERT INTO `glpi_events` VALUES ('35','27','ITILCategory','2017-02-05 12:53:14','setup','4','dong added item MS OFFICE');
INSERT INTO `glpi_events` VALUES ('36','28','ITILCategory','2017-02-05 12:54:12','setup','4','dong added item Speaker');
INSERT INTO `glpi_events` VALUES ('37','29','ITILCategory','2017-02-05 12:54:45','setup','4','dong added item HR @PAYROLL');
INSERT INTO `glpi_events` VALUES ('38','30','ITILCategory','2017-02-05 12:55:16','setup','4','dong added item Time attendance');
INSERT INTO `glpi_events` VALUES ('39','31','ITILCategory','2017-02-05 12:55:48','setup','4','dong added item Finger Scan');
INSERT INTO `glpi_events` VALUES ('40','32','ITILCategory','2017-02-05 12:56:21','setup','4','dong added item Key Card Onity');
INSERT INTO `glpi_events` VALUES ('41','33','ITILCategory','2017-02-05 12:56:30','setup','4','dong added item Fromas');
INSERT INTO `glpi_events` VALUES ('42','34','ITILCategory','2017-02-05 13:01:49','setup','4','dong added item AccSys');
INSERT INTO `glpi_events` VALUES ('43','35','ITILCategory','2017-02-05 13:01:56','setup','4','dong added item AP');
INSERT INTO `glpi_events` VALUES ('44','36','ITILCategory','2017-02-05 13:02:08','setup','4','dong added item AR');
INSERT INTO `glpi_events` VALUES ('45','37','ITILCategory','2017-02-05 13:02:32','setup','4','dong added item Daily Income');
INSERT INTO `glpi_events` VALUES ('46','38','ITILCategory','2017-02-05 13:02:49','setup','4','dong added item GeneralLedger');
INSERT INTO `glpi_events` VALUES ('47','39','ITILCategory','2017-02-05 13:02:58','setup','4','dong added item InventoryControls');
INSERT INTO `glpi_events` VALUES ('48','40','ITILCategory','2017-02-05 13:03:08','setup','4','dong added item Purchasing');
INSERT INTO `glpi_events` VALUES ('49','41','ITILCategory','2017-02-05 13:03:16','setup','4','dong added item SubStoreControls');
INSERT INTO `glpi_events` VALUES ('50','42','ITILCategory','2017-02-05 13:03:33','setup','4','dong added item CAMS');
INSERT INTO `glpi_events` VALUES ('51','43','ITILCategory','2017-02-05 13:03:46','setup','4','dong added item Comcash');
INSERT INTO `glpi_events` VALUES ('52','44','ITILCategory','2017-02-05 13:06:01','setup','4','dong added item WD TV');
INSERT INTO `glpi_events` VALUES ('53','45','ITILCategory','2017-02-05 13:06:22','setup','4','dong added item CCTV');
INSERT INTO `glpi_events` VALUES ('54','46','ITILCategory','2017-02-05 13:06:39','setup','4','dong added item Camera');
INSERT INTO `glpi_events` VALUES ('55','47','ITILCategory','2017-02-05 13:06:44','setup','4','dong added item DVR');
INSERT INTO `glpi_events` VALUES ('56','48','ITILCategory','2017-02-05 13:07:28','setup','4','dong added item Line signal');
INSERT INTO `glpi_events` VALUES ('57','49','ITILCategory','2017-02-05 13:07:34','setup','4','dong added item Adapter');
INSERT INTO `glpi_events` VALUES ('58','50','ITILCategory','2017-02-05 13:08:21','setup','4','dong added item hard disk');
INSERT INTO `glpi_events` VALUES ('59','51','ITILCategory','2017-02-05 13:08:34','setup','4','dong added item Ram');
INSERT INTO `glpi_events` VALUES ('60','52','ITILCategory','2017-02-05 13:08:47','setup','4','dong added item Notebook');
INSERT INTO `glpi_events` VALUES ('61','53','ITILCategory','2017-02-05 13:09:20','setup','4','dong added item Accessory');
INSERT INTO `glpi_events` VALUES ('62','54','ITILCategory','2017-02-05 13:09:42','setup','4','dong added item Line USB ');
INSERT INTO `glpi_events` VALUES ('63','55','ITILCategory','2017-02-05 13:10:03','setup','4','dong added item Flash drive');
INSERT INTO `glpi_events` VALUES ('64','56','ITILCategory','2017-02-05 13:10:21','setup','4','dong added item Line HDMI ');
INSERT INTO `glpi_events` VALUES ('65','57','ITILCategory','2017-02-05 13:10:47','setup','4','dong added item DVD RW');
INSERT INTO `glpi_events` VALUES ('66','58','ITILCategory','2017-02-05 13:11:01','setup','4','dong added item Power Supply');
INSERT INTO `glpi_events` VALUES ('67','59','ITILCategory','2017-02-05 13:11:36','setup','4','dong added item Smartphone');
INSERT INTO `glpi_events` VALUES ('68','60','ITILCategory','2017-02-05 13:12:39','setup','4','dong added item Lan Card');
INSERT INTO `glpi_events` VALUES ('69','61','ITILCategory','2017-02-05 13:13:43','setup','4','dong added item Server');
INSERT INTO `glpi_events` VALUES ('70','62','ITILCategory','2017-02-05 13:13:58','setup','4','dong added item SUKA');
INSERT INTO `glpi_events` VALUES ('71','63','ITILCategory','2017-02-05 13:14:05','setup','4','dong added item KML');
INSERT INTO `glpi_events` VALUES ('72','64','ITILCategory','2017-02-05 13:14:15','setup','4','dong added item IBSG');
INSERT INTO `glpi_events` VALUES ('73','65','ITILCategory','2017-02-05 13:14:24','setup','4','dong added item Authen Newsoft');
INSERT INTO `glpi_events` VALUES ('74','66','ITILCategory','2017-02-05 13:14:39','setup','4','dong added item MG');
INSERT INTO `glpi_events` VALUES ('75','67','ITILCategory','2017-02-05 13:15:35','setup','4','dong added item CAM SUKA');
INSERT INTO `glpi_events` VALUES ('76','68','ITILCategory','2017-02-05 13:15:42','setup','4','dong added item CAM KML');
INSERT INTO `glpi_events` VALUES ('77','69','ITILCategory','2017-02-05 13:17:26','setup','4','dong added item Printer');
INSERT INTO `glpi_events` VALUES ('78','70','ITILCategory','2017-02-05 13:17:41','setup','4','dong added item TMU220');
INSERT INTO `glpi_events` VALUES ('79','71','ITILCategory','2017-02-05 13:17:59','setup','4','dong added item EPSON210/220');
INSERT INTO `glpi_events` VALUES ('80','72','ITILCategory','2017-02-05 13:18:57','setup','4','dong added item Konica');
INSERT INTO `glpi_events` VALUES ('81','73','ITILCategory','2017-02-05 13:19:51','setup','4','dong added item Scan Passport');
INSERT INTO `glpi_events` VALUES ('82','-1','system','2017-02-06 01:40:56','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('83','-1','system','2017-02-06 03:01:10','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('84','5','users','2017-02-06 04:15:33','setup','5','dong updated item');
INSERT INTO `glpi_events` VALUES ('85','3','users','2017-02-06 04:15:50','setup','5','dong updated item');
INSERT INTO `glpi_events` VALUES ('86','4','users','2017-02-06 04:16:03','setup','5','dong updated item');
INSERT INTO `glpi_events` VALUES ('87','6','users','2017-02-06 04:19:25','setup','4','dong added item sutham');
INSERT INTO `glpi_events` VALUES ('88','-1','system','2017-02-06 04:22:35','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('89','1','ticket','2017-02-06 04:23:59','tracking','4','sutham added item 1');
INSERT INTO `glpi_events` VALUES ('90','1','ticket','2017-02-06 04:26:09','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('91','2','ticket','2017-02-06 04:29:52','tracking','4','sutham added item 2');
INSERT INTO `glpi_events` VALUES ('92','2','ticket','2017-02-06 04:30:51','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('93','3','ticket','2017-02-06 04:33:07','tracking','4','sutham added item 3');
INSERT INTO `glpi_events` VALUES ('94','3','ticket','2017-02-06 04:33:47','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('95','4','ticket','2017-02-06 04:35:02','tracking','4','sutham added item 4');
INSERT INTO `glpi_events` VALUES ('96','4','ticket','2017-02-06 04:35:26','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('97','5','ticket','2017-02-06 04:37:37','tracking','4','sutham added item 5');
INSERT INTO `glpi_events` VALUES ('98','5','ticket','2017-02-06 04:38:10','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('99','6','ticket','2017-02-06 04:39:39','tracking','4','sutham added item 6');
INSERT INTO `glpi_events` VALUES ('100','6','ticket','2017-02-06 04:41:28','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('101','7','ticket','2017-02-06 04:42:39','tracking','4','sutham added item 7');
INSERT INTO `glpi_events` VALUES ('102','7','ticket','2017-02-06 04:45:25','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('103','-1','system','2017-02-06 04:46:08','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('104','7','ticket','2017-02-06 04:48:49','tracking','4','dong updated item');
INSERT INTO `glpi_events` VALUES ('105','-1','system','2017-02-06 04:49:00','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('106','7','ticket','2017-02-06 04:49:27','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('107','8','ticket','2017-02-06 04:49:59','tracking','4','sutham added item 8');
INSERT INTO `glpi_events` VALUES ('108','8','ticket','2017-02-06 04:50:37','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('109','9','ticket','2017-02-06 04:51:34','tracking','4','sutham added item 9');
INSERT INTO `glpi_events` VALUES ('110','9','ticket','2017-02-06 04:52:07','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('111','10','ticket','2017-02-06 04:53:34','tracking','4','sutham added item 10');
INSERT INTO `glpi_events` VALUES ('112','10','ticket','2017-02-06 04:53:55','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('113','11','ticket','2017-02-06 05:10:42','tracking','4','sutham added item 11');
INSERT INTO `glpi_events` VALUES ('114','11','ticket','2017-02-06 05:11:05','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('115','12','ticket','2017-02-06 05:12:17','tracking','4','sutham added item 12');
INSERT INTO `glpi_events` VALUES ('116','12','ticket','2017-02-06 05:13:11','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('117','13','ticket','2017-02-06 05:14:14','tracking','4','sutham added item 13');
INSERT INTO `glpi_events` VALUES ('118','13','ticket','2017-02-06 05:14:56','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('119','14','ticket','2017-02-06 05:16:05','tracking','4','sutham added item 14');
INSERT INTO `glpi_events` VALUES ('120','14','ticket','2017-02-06 05:16:27','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('121','15','ticket','2017-02-06 05:17:24','tracking','4','sutham added item 15');
INSERT INTO `glpi_events` VALUES ('122','15','ticket','2017-02-06 05:19:02','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('123','16','ticket','2017-02-06 05:23:50','tracking','4','sutham added item 16');
INSERT INTO `glpi_events` VALUES ('124','16','ticket','2017-02-06 05:24:12','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('125','-1','system','2017-02-07 04:51:44','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('126','-1','system','2017-02-07 06:23:37','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('127','-1','system','2017-02-08 00:59:50','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('128','17','ticket','2017-02-08 01:10:22','tracking','4','sutham added item 17');
INSERT INTO `glpi_events` VALUES ('129','17','ticket','2017-02-08 01:11:06','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('130','18','ticket','2017-02-08 01:11:58','tracking','4','sutham added item 18');
INSERT INTO `glpi_events` VALUES ('131','18','ticket','2017-02-08 01:12:34','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('132','19','ticket','2017-02-08 01:13:42','tracking','4','sutham added item 19');
INSERT INTO `glpi_events` VALUES ('133','19','ticket','2017-02-08 01:14:09','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('134','20','ticket','2017-02-08 01:15:15','tracking','4','sutham added item 20');
INSERT INTO `glpi_events` VALUES ('135','20','ticket','2017-02-08 01:15:56','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('136','-1','system','2017-02-08 01:16:43','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('137','23','ITILCategory','2017-02-08 01:17:17','setup','4','dong purged item');
INSERT INTO `glpi_events` VALUES ('138','18','ITILCategory','2017-02-08 01:17:36','setup','4','dong purged item');
INSERT INTO `glpi_events` VALUES ('139','74','ITILCategory','2017-02-08 01:18:57','setup','4','dong added item Adobe');
INSERT INTO `glpi_events` VALUES ('140','-1','system','2017-02-08 01:19:08','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('141','-1','system','2017-02-08 01:20:30','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('142','21','ticket','2017-02-08 01:21:29','tracking','4','sutham added item 21');
INSERT INTO `glpi_events` VALUES ('143','21','ticket','2017-02-08 01:22:32','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('144','22','ticket','2017-02-08 01:23:29','tracking','4','sutham added item 22');
INSERT INTO `glpi_events` VALUES ('145','22','ticket','2017-02-08 01:23:47','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('146','23','ticket','2017-02-08 01:25:00','tracking','4','sutham added item 23');
INSERT INTO `glpi_events` VALUES ('147','23','ticket','2017-02-08 01:25:18','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('148','24','ticket','2017-02-08 01:26:18','tracking','4','sutham added item 24');
INSERT INTO `glpi_events` VALUES ('149','24','ticket','2017-02-08 01:26:46','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('150','25','ticket','2017-02-08 01:27:42','tracking','4','sutham added item 25');
INSERT INTO `glpi_events` VALUES ('151','25','ticket','2017-02-08 01:28:04','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('152','-1','system','2017-02-08 01:28:53','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('153','75','ITILCategory','2017-02-08 01:29:12','setup','4','dong added item Orther');
INSERT INTO `glpi_events` VALUES ('154','-1','system','2017-02-08 01:29:19','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('155','26','ticket','2017-02-08 01:30:36','tracking','4','sutham added item 26');
INSERT INTO `glpi_events` VALUES ('156','26','ticket','2017-02-08 01:30:52','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('157','27','ticket','2017-02-08 01:31:27','tracking','4','sutham added item 27');
INSERT INTO `glpi_events` VALUES ('158','27','ticket','2017-02-08 01:31:52','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('159','28','ticket','2017-02-08 01:33:32','tracking','4','sutham added item 28');
INSERT INTO `glpi_events` VALUES ('160','28','ticket','2017-02-08 01:33:55','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('161','29','ticket','2017-02-08 01:35:04','tracking','4','sutham added item 29');
INSERT INTO `glpi_events` VALUES ('162','29','ticket','2017-02-08 01:35:33','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('163','30','ticket','2017-02-08 01:36:29','tracking','4','sutham added item 30');
INSERT INTO `glpi_events` VALUES ('164','30','ticket','2017-02-08 01:36:49','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('165','31','ticket','2017-02-08 01:37:49','tracking','4','sutham added item 31');
INSERT INTO `glpi_events` VALUES ('166','31','ticket','2017-02-08 01:38:29','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('167','32','ticket','2017-02-08 01:39:44','tracking','4','sutham added item 32');
INSERT INTO `glpi_events` VALUES ('168','32','ticket','2017-02-08 01:40:27','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('169','33','ticket','2017-02-08 01:41:10','tracking','4','sutham added item 33');
INSERT INTO `glpi_events` VALUES ('170','33','ticket','2017-02-08 01:41:33','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('171','34','ticket','2017-02-08 01:42:20','tracking','4','sutham added item 34');
INSERT INTO `glpi_events` VALUES ('172','34','ticket','2017-02-08 01:42:44','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('173','35','ticket','2017-02-08 01:43:56','tracking','4','sutham added item 35');
INSERT INTO `glpi_events` VALUES ('174','35','ticket','2017-02-08 01:44:33','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('175','36','ticket','2017-02-08 01:45:10','tracking','4','sutham added item 36');
INSERT INTO `glpi_events` VALUES ('176','36','ticket','2017-02-08 01:46:08','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('177','37','ticket','2017-02-08 01:50:39','tracking','4','sutham added item 37');
INSERT INTO `glpi_events` VALUES ('178','37','ticket','2017-02-08 01:51:43','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('179','38','ticket','2017-02-08 01:52:23','tracking','4','sutham added item 38');
INSERT INTO `glpi_events` VALUES ('180','38','ticket','2017-02-08 01:52:39','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('181','39','ticket','2017-02-08 01:53:22','tracking','4','sutham added item 39');
INSERT INTO `glpi_events` VALUES ('182','39','ticket','2017-02-08 01:53:41','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('183','40','ticket','2017-02-08 01:54:26','tracking','4','sutham added item 40');
INSERT INTO `glpi_events` VALUES ('184','40','ticket','2017-02-08 01:54:55','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('185','41','ticket','2017-02-08 01:56:26','tracking','4','sutham added item 41');
INSERT INTO `glpi_events` VALUES ('186','41','ticket','2017-02-08 01:56:51','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('187','42','ticket','2017-02-08 01:57:48','tracking','4','sutham added item 42');
INSERT INTO `glpi_events` VALUES ('188','42','ticket','2017-02-08 01:58:04','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('189','43','ticket','2017-02-08 01:59:18','tracking','4','sutham added item 43');
INSERT INTO `glpi_events` VALUES ('190','43','ticket','2017-02-08 02:00:05','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('191','44','ticket','2017-02-08 02:00:59','tracking','4','sutham added item 44');
INSERT INTO `glpi_events` VALUES ('192','44','ticket','2017-02-08 02:01:51','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('193','45','ticket','2017-02-08 02:02:43','tracking','4','sutham added item 45');
INSERT INTO `glpi_events` VALUES ('194','45','ticket','2017-02-08 02:03:18','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('195','46','ticket','2017-02-08 02:03:55','tracking','4','sutham added item 46');
INSERT INTO `glpi_events` VALUES ('196','46','ticket','2017-02-08 02:04:19','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('197','47','ticket','2017-02-08 02:05:31','tracking','4','sutham added item 47');
INSERT INTO `glpi_events` VALUES ('198','47','ticket','2017-02-08 02:07:19','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('199','48','ticket','2017-02-08 02:08:23','tracking','4','sutham added item 48');
INSERT INTO `glpi_events` VALUES ('200','48','ticket','2017-02-08 02:08:49','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('201','49','ticket','2017-02-08 02:21:52','tracking','4','sutham added item 49');
INSERT INTO `glpi_events` VALUES ('202','49','ticket','2017-02-08 02:22:07','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('203','50','ticket','2017-02-08 02:22:40','tracking','4','sutham added item 50');
INSERT INTO `glpi_events` VALUES ('204','50','ticket','2017-02-08 02:23:20','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('205','51','ticket','2017-02-08 02:24:09','tracking','4','sutham added item 51');
INSERT INTO `glpi_events` VALUES ('206','51','ticket','2017-02-08 02:24:29','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('207','52','ticket','2017-02-08 02:25:25','tracking','4','sutham added item 52');
INSERT INTO `glpi_events` VALUES ('208','52','ticket','2017-02-08 02:25:54','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('209','53','ticket','2017-02-08 02:26:43','tracking','4','sutham added item 53');
INSERT INTO `glpi_events` VALUES ('210','53','ticket','2017-02-08 02:27:17','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('211','54','ticket','2017-02-08 02:28:06','tracking','4','sutham added item 54');
INSERT INTO `glpi_events` VALUES ('212','54','ticket','2017-02-08 02:28:45','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('213','55','ticket','2017-02-08 02:30:28','tracking','4','sutham added item 55');
INSERT INTO `glpi_events` VALUES ('214','55','ticket','2017-02-08 02:31:08','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('215','56','ticket','2017-02-08 02:31:58','tracking','4','sutham added item 56');
INSERT INTO `glpi_events` VALUES ('216','56','ticket','2017-02-08 02:32:38','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('217','57','ticket','2017-02-08 02:33:22','tracking','4','sutham added item 57');
INSERT INTO `glpi_events` VALUES ('218','57','ticket','2017-02-08 02:33:42','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('219','58','ticket','2017-02-08 02:34:45','tracking','4','sutham added item 58');
INSERT INTO `glpi_events` VALUES ('220','58','ticket','2017-02-08 02:35:18','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('221','59','ticket','2017-02-08 02:36:07','tracking','4','sutham added item 59');
INSERT INTO `glpi_events` VALUES ('222','59','ticket','2017-02-08 02:36:48','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('223','60','ticket','2017-02-08 02:37:21','tracking','4','sutham added item 60');
INSERT INTO `glpi_events` VALUES ('224','60','ticket','2017-02-08 02:37:46','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('225','61','ticket','2017-02-08 02:38:28','tracking','4','sutham added item 61');
INSERT INTO `glpi_events` VALUES ('226','61','ticket','2017-02-08 02:38:44','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('227','62','ticket','2017-02-08 02:39:14','tracking','4','sutham added item 62');
INSERT INTO `glpi_events` VALUES ('228','62','ticket','2017-02-08 02:39:36','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('229','63','ticket','2017-02-08 02:40:28','tracking','4','sutham added item 63');
INSERT INTO `glpi_events` VALUES ('230','63','ticket','2017-02-08 02:41:25','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('231','64','ticket','2017-02-08 02:42:13','tracking','4','sutham added item 64');
INSERT INTO `glpi_events` VALUES ('232','64','ticket','2017-02-08 02:42:39','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('233','65','ticket','2017-02-08 02:43:38','tracking','4','sutham added item 65');
INSERT INTO `glpi_events` VALUES ('234','65','ticket','2017-02-08 02:43:57','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('235','66','ticket','2017-02-08 02:44:46','tracking','4','sutham added item 66');
INSERT INTO `glpi_events` VALUES ('236','66','ticket','2017-02-08 02:45:31','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('237','67','ticket','2017-02-08 02:46:18','tracking','4','sutham added item 67');
INSERT INTO `glpi_events` VALUES ('238','67','ticket','2017-02-08 02:46:41','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('239','68','ticket','2017-02-08 02:47:28','tracking','4','sutham added item 68');
INSERT INTO `glpi_events` VALUES ('240','68','ticket','2017-02-08 02:47:49','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('241','69','ticket','2017-02-08 02:48:45','tracking','4','sutham added item 69');
INSERT INTO `glpi_events` VALUES ('242','69','ticket','2017-02-08 02:49:01','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('243','70','ticket','2017-02-08 02:49:46','tracking','4','sutham added item 70');
INSERT INTO `glpi_events` VALUES ('244','70','ticket','2017-02-08 02:50:02','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('245','71','ticket','2017-02-08 02:51:20','tracking','4','sutham added item 71');
INSERT INTO `glpi_events` VALUES ('246','71','ticket','2017-02-08 02:51:31','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('247','72','ticket','2017-02-08 02:52:14','tracking','4','sutham added item 72');
INSERT INTO `glpi_events` VALUES ('248','72','ticket','2017-02-08 02:52:25','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('249','73','ticket','2017-02-08 02:53:23','tracking','4','sutham added item 73');
INSERT INTO `glpi_events` VALUES ('250','73','ticket','2017-02-08 02:53:45','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('251','74','ticket','2017-02-08 02:54:34','tracking','4','sutham added item 74');
INSERT INTO `glpi_events` VALUES ('252','74','ticket','2017-02-08 02:55:03','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('253','75','ticket','2017-02-08 02:56:13','tracking','4','sutham added item 75');
INSERT INTO `glpi_events` VALUES ('254','75','ticket','2017-02-08 02:56:35','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('255','76','ticket','2017-02-08 02:57:11','tracking','4','sutham added item 76');
INSERT INTO `glpi_events` VALUES ('256','76','ticket','2017-02-08 02:57:39','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('257','77','ticket','2017-02-08 02:58:25','tracking','4','sutham added item 77');
INSERT INTO `glpi_events` VALUES ('258','77','ticket','2017-02-08 02:59:15','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('259','78','ticket','2017-02-08 03:00:26','tracking','4','sutham added item 78');
INSERT INTO `glpi_events` VALUES ('260','78','ticket','2017-02-08 03:00:44','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('261','79','ticket','2017-02-08 03:02:01','tracking','4','sutham added item 79');
INSERT INTO `glpi_events` VALUES ('262','79','ticket','2017-02-08 03:03:17','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('263','80','ticket','2017-02-08 03:04:09','tracking','4','sutham added item 80');
INSERT INTO `glpi_events` VALUES ('264','80','ticket','2017-02-08 03:04:31','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('265','81','ticket','2017-02-08 03:05:51','tracking','4','sutham added item 81');
INSERT INTO `glpi_events` VALUES ('266','81','ticket','2017-02-08 03:06:20','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('267','82','ticket','2017-02-08 03:07:55','tracking','4','sutham added item 82');
INSERT INTO `glpi_events` VALUES ('268','82','ticket','2017-02-08 03:08:18','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('269','83','ticket','2017-02-08 03:09:02','tracking','4','sutham added item 83');
INSERT INTO `glpi_events` VALUES ('270','83','ticket','2017-02-08 03:09:41','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('271','84','ticket','2017-02-08 03:10:26','tracking','4','sutham added item 84');
INSERT INTO `glpi_events` VALUES ('272','84','ticket','2017-02-08 03:10:41','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('273','85','ticket','2017-02-08 03:11:36','tracking','4','sutham added item 85');
INSERT INTO `glpi_events` VALUES ('274','85','ticket','2017-02-08 03:11:49','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('275','86','ticket','2017-02-08 03:12:32','tracking','4','sutham added item 86');
INSERT INTO `glpi_events` VALUES ('276','86','ticket','2017-02-08 03:13:00','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('277','87','ticket','2017-02-08 03:13:33','tracking','4','sutham added item 87');
INSERT INTO `glpi_events` VALUES ('278','87','ticket','2017-02-08 03:13:58','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('279','88','ticket','2017-02-08 03:15:07','tracking','4','sutham added item 88');
INSERT INTO `glpi_events` VALUES ('280','88','ticket','2017-02-08 03:15:31','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('281','89','ticket','2017-02-08 03:16:13','tracking','4','sutham added item 89');
INSERT INTO `glpi_events` VALUES ('282','89','ticket','2017-02-08 03:16:46','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('283','90','ticket','2017-02-08 03:17:24','tracking','4','sutham added item 90');
INSERT INTO `glpi_events` VALUES ('284','90','ticket','2017-02-08 03:17:56','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('285','91','ticket','2017-02-08 03:18:48','tracking','4','sutham added item 91');
INSERT INTO `glpi_events` VALUES ('286','91','ticket','2017-02-08 03:19:32','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('287','-1','system','2017-02-08 03:20:40','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('288','76','ITILCategory','2017-02-08 03:20:51','setup','4','dong added item VPN');
INSERT INTO `glpi_events` VALUES ('289','77','ITILCategory','2017-02-08 03:20:57','setup','4','dong added item REMOTE DESKTOP');
INSERT INTO `glpi_events` VALUES ('290','78','ITILCategory','2017-02-08 03:21:06','setup','4','dong added item MAIL');
INSERT INTO `glpi_events` VALUES ('291','-1','system','2017-02-08 03:21:19','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('292','92','ticket','2017-02-08 03:21:45','tracking','4','sutham added item 92');
INSERT INTO `glpi_events` VALUES ('293','92','ticket','2017-02-08 03:22:33','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('294','93','ticket','2017-02-08 03:23:40','tracking','4','sutham added item 93');
INSERT INTO `glpi_events` VALUES ('295','93','ticket','2017-02-08 03:23:53','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('296','94','ticket','2017-02-08 03:24:27','tracking','4','sutham added item 94');
INSERT INTO `glpi_events` VALUES ('297','94','ticket','2017-02-08 03:24:56','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('298','95','ticket','2017-02-08 03:25:44','tracking','4','sutham added item 95');
INSERT INTO `glpi_events` VALUES ('299','95','ticket','2017-02-08 03:26:08','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('300','96','ticket','2017-02-08 03:27:17','tracking','4','sutham added item 96');
INSERT INTO `glpi_events` VALUES ('301','96','ticket','2017-02-08 03:28:16','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('302','97','ticket','2017-02-08 03:29:03','tracking','4','sutham added item 97');
INSERT INTO `glpi_events` VALUES ('303','97','ticket','2017-02-08 03:29:48','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('304','98','ticket','2017-02-08 03:30:29','tracking','4','sutham added item 98');
INSERT INTO `glpi_events` VALUES ('305','98','ticket','2017-02-08 03:30:50','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('306','99','ticket','2017-02-08 03:31:27','tracking','4','sutham added item 99');
INSERT INTO `glpi_events` VALUES ('307','99','ticket','2017-02-08 03:33:23','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('308','100','ticket','2017-02-08 03:34:46','tracking','4','sutham added item 100');
INSERT INTO `glpi_events` VALUES ('309','100','ticket','2017-02-08 03:35:42','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('310','101','ticket','2017-02-08 03:57:06','tracking','4','sutham added item 101');
INSERT INTO `glpi_events` VALUES ('311','101','ticket','2017-02-08 03:57:18','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('312','102','ticket','2017-02-08 03:58:19','tracking','4','sutham added item 102');
INSERT INTO `glpi_events` VALUES ('313','102','ticket','2017-02-08 03:58:54','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('314','103','ticket','2017-02-08 03:59:35','tracking','4','sutham added item 103');
INSERT INTO `glpi_events` VALUES ('315','103','ticket','2017-02-08 04:00:14','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('316','104','ticket','2017-02-08 04:00:52','tracking','4','sutham added item 104');
INSERT INTO `glpi_events` VALUES ('317','104','ticket','2017-02-08 04:01:19','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('318','105','ticket','2017-02-08 04:02:01','tracking','4','sutham added item 105');
INSERT INTO `glpi_events` VALUES ('319','105','ticket','2017-02-08 04:02:12','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('320','106','ticket','2017-02-08 04:03:22','tracking','4','sutham added item 106');
INSERT INTO `glpi_events` VALUES ('321','106','ticket','2017-02-08 04:04:02','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('322','107','ticket','2017-02-08 04:05:14','tracking','4','sutham added item 107');
INSERT INTO `glpi_events` VALUES ('323','107','ticket','2017-02-08 04:05:22','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('324','108','ticket','2017-02-08 04:06:02','tracking','4','sutham added item 108');
INSERT INTO `glpi_events` VALUES ('325','108','ticket','2017-02-08 04:06:15','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('326','109','ticket','2017-02-08 04:06:53','tracking','4','sutham added item 109');
INSERT INTO `glpi_events` VALUES ('327','109','ticket','2017-02-08 04:07:15','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('328','110','ticket','2017-02-08 04:07:51','tracking','4','sutham added item 110');
INSERT INTO `glpi_events` VALUES ('329','110','ticket','2017-02-08 04:08:12','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('330','111','ticket','2017-02-08 04:08:44','tracking','4','sutham added item 111');
INSERT INTO `glpi_events` VALUES ('331','111','ticket','2017-02-08 04:08:53','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('332','112','ticket','2017-02-08 04:09:42','tracking','4','sutham added item 112');
INSERT INTO `glpi_events` VALUES ('333','112','ticket','2017-02-08 04:09:50','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('334','113','ticket','2017-02-08 04:10:40','tracking','4','sutham added item 113');
INSERT INTO `glpi_events` VALUES ('335','113','ticket','2017-02-08 04:11:00','tracking','4','sutham added followup');
INSERT INTO `glpi_events` VALUES ('336','113','ticket','2017-02-08 04:11:31','tracking','4','sutham added followup');
INSERT INTO `glpi_events` VALUES ('337','113','ticket','2017-02-08 04:13:43','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('338','114','ticket','2017-02-08 04:15:38','tracking','4','sutham added item 114');
INSERT INTO `glpi_events` VALUES ('339','114','ticket','2017-02-08 04:15:49','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('340','115','ticket','2017-02-08 04:17:46','tracking','4','sutham added item 115');
INSERT INTO `glpi_events` VALUES ('341','115','ticket','2017-02-08 04:18:00','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('342','116','ticket','2017-02-08 04:18:32','tracking','4','sutham added item 116');
INSERT INTO `glpi_events` VALUES ('343','116','ticket','2017-02-08 04:18:39','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('344','117','ticket','2017-02-08 04:19:21','tracking','4','sutham added item 117');
INSERT INTO `glpi_events` VALUES ('345','117','ticket','2017-02-08 04:20:13','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('346','118','ticket','2017-02-08 04:21:04','tracking','4','sutham added item 118');
INSERT INTO `glpi_events` VALUES ('347','118','ticket','2017-02-08 04:21:54','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('348','119','ticket','2017-02-08 04:23:09','tracking','4','sutham added item 119');
INSERT INTO `glpi_events` VALUES ('349','119','ticket','2017-02-08 04:23:23','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('350','120','ticket','2017-02-08 04:24:36','tracking','4','sutham added item 120');
INSERT INTO `glpi_events` VALUES ('351','120','ticket','2017-02-08 04:24:50','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('352','121','ticket','2017-02-08 04:25:39','tracking','4','sutham added item 121');
INSERT INTO `glpi_events` VALUES ('353','121','ticket','2017-02-08 04:26:06','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('354','122','ticket','2017-02-08 04:27:06','tracking','4','sutham added item 122');
INSERT INTO `glpi_events` VALUES ('355','122','ticket','2017-02-08 04:27:25','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('356','123','ticket','2017-02-08 04:28:08','tracking','4','sutham added item 123');
INSERT INTO `glpi_events` VALUES ('357','123','ticket','2017-02-08 04:28:17','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('358','124','ticket','2017-02-08 04:29:17','tracking','4','sutham added item 124');
INSERT INTO `glpi_events` VALUES ('359','124','ticket','2017-02-08 04:29:24','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('360','125','ticket','2017-02-08 04:30:09','tracking','4','sutham added item 125');
INSERT INTO `glpi_events` VALUES ('361','125','ticket','2017-02-08 04:30:52','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('362','126','ticket','2017-02-08 04:31:25','tracking','4','sutham added item 126');
INSERT INTO `glpi_events` VALUES ('363','126','ticket','2017-02-08 04:31:47','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('364','127','ticket','2017-02-08 04:32:46','tracking','4','sutham added item 127');
INSERT INTO `glpi_events` VALUES ('365','127','ticket','2017-02-08 04:32:57','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('366','128','ticket','2017-02-08 04:33:25','tracking','4','sutham added item 128');
INSERT INTO `glpi_events` VALUES ('367','128','ticket','2017-02-08 04:33:41','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('368','129','ticket','2017-02-08 04:34:16','tracking','4','sutham added item 129');
INSERT INTO `glpi_events` VALUES ('369','129','ticket','2017-02-08 04:34:35','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('370','130','ticket','2017-02-08 04:35:12','tracking','4','sutham added item 130');
INSERT INTO `glpi_events` VALUES ('371','130','ticket','2017-02-08 04:35:35','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('372','131','ticket','2017-02-08 04:36:08','tracking','4','sutham added item 131');
INSERT INTO `glpi_events` VALUES ('373','131','ticket','2017-02-08 04:36:25','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('374','132','ticket','2017-02-08 04:36:58','tracking','4','sutham added item 132');
INSERT INTO `glpi_events` VALUES ('375','132','ticket','2017-02-08 04:37:27','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('376','133','ticket','2017-02-08 04:37:57','tracking','4','sutham added item 133');
INSERT INTO `glpi_events` VALUES ('377','133','ticket','2017-02-08 04:38:49','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('378','134','ticket','2017-02-08 04:39:59','tracking','4','sutham added item 134');
INSERT INTO `glpi_events` VALUES ('379','134','ticket','2017-02-08 04:40:20','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('380','135','ticket','2017-02-08 04:41:18','tracking','4','sutham added item 135');
INSERT INTO `glpi_events` VALUES ('381','135','ticket','2017-02-08 04:41:37','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('382','136','ticket','2017-02-08 04:42:08','tracking','4','sutham added item 136');
INSERT INTO `glpi_events` VALUES ('383','136','ticket','2017-02-08 04:42:31','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('384','137','ticket','2017-02-08 04:43:02','tracking','4','sutham added item 137');
INSERT INTO `glpi_events` VALUES ('385','137','ticket','2017-02-08 04:43:25','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('386','138','ticket','2017-02-08 04:44:10','tracking','4','sutham added item 138');
INSERT INTO `glpi_events` VALUES ('387','138','ticket','2017-02-08 04:44:46','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('388','139','ticket','2017-02-08 04:45:33','tracking','4','sutham added item 139');
INSERT INTO `glpi_events` VALUES ('389','139','ticket','2017-02-08 04:45:56','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('390','140','ticket','2017-02-08 04:46:27','tracking','4','sutham added item 140');
INSERT INTO `glpi_events` VALUES ('391','140','ticket','2017-02-08 04:47:51','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('392','141','ticket','2017-02-08 04:49:48','tracking','4','sutham added item 141');
INSERT INTO `glpi_events` VALUES ('393','141','ticket','2017-02-08 04:49:55','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('394','142','ticket','2017-02-08 04:50:26','tracking','4','sutham added item 142');
INSERT INTO `glpi_events` VALUES ('395','142','ticket','2017-02-08 04:51:13','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('396','143','ticket','2017-02-08 04:51:53','tracking','4','sutham added item 143');
INSERT INTO `glpi_events` VALUES ('397','143','ticket','2017-02-08 04:52:42','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('398','144','ticket','2017-02-08 04:53:25','tracking','4','sutham added item 144');
INSERT INTO `glpi_events` VALUES ('399','144','ticket','2017-02-08 04:54:12','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('400','145','ticket','2017-02-08 04:54:53','tracking','4','sutham added item 145');
INSERT INTO `glpi_events` VALUES ('401','145','ticket','2017-02-08 04:55:40','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('402','146','ticket','2017-02-08 04:56:44','tracking','4','sutham added item 146');
INSERT INTO `glpi_events` VALUES ('403','146','ticket','2017-02-08 04:57:01','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('404','147','ticket','2017-02-08 04:57:40','tracking','4','sutham added item 147');
INSERT INTO `glpi_events` VALUES ('405','147','ticket','2017-02-08 04:58:25','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('406','148','ticket','2017-02-08 04:59:11','tracking','4','sutham added item 148');
INSERT INTO `glpi_events` VALUES ('407','148','ticket','2017-02-08 04:59:41','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('408','149','ticket','2017-02-08 05:00:29','tracking','4','sutham added item 149');
INSERT INTO `glpi_events` VALUES ('409','149','ticket','2017-02-08 05:00:56','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('410','-1','system','2017-02-08 05:05:15','login','3','dong logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('411','150','ticket','2017-02-08 05:39:26','tracking','4','dong added item 150');
INSERT INTO `glpi_events` VALUES ('412','151','ticket','2017-02-08 05:40:10','tracking','4','dong added item 151');
INSERT INTO `glpi_events` VALUES ('413','152','ticket','2017-02-08 05:41:08','tracking','4','dong added item 152');
INSERT INTO `glpi_events` VALUES ('414','152','ticket','2017-02-08 05:41:46','tracking','4','dong updated item');
INSERT INTO `glpi_events` VALUES ('415','151','ticket','2017-02-08 05:42:01','tracking','4','dong updated item');
INSERT INTO `glpi_events` VALUES ('416','150','ticket','2017-02-08 05:42:13','tracking','4','dong updated item');
INSERT INTO `glpi_events` VALUES ('417','-1','system','2017-02-08 05:42:41','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('418','-1','system','2017-02-08 12:23:41','login','3','dong logged in from IP 192.168.2.197');
INSERT INTO `glpi_events` VALUES ('419','-1','system','2017-02-10 09:08:12','login','3','Failed login for sutham from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('420','-1','system','2017-02-10 09:08:20','login','3','sutham logged in from IP 192.168.2.1');
INSERT INTO `glpi_events` VALUES ('421','150','ticket','2017-02-10 09:08:43','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('422','153','ticket','2017-02-10 09:10:09','tracking','4','sutham added item 153');
INSERT INTO `glpi_events` VALUES ('423','154','ticket','2017-02-10 09:11:06','tracking','4','sutham added item 154');
INSERT INTO `glpi_events` VALUES ('424','153','ticket','2017-02-10 09:11:29','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('425','154','ticket','2017-02-10 09:11:40','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('426','155','ticket','2017-02-10 09:14:16','tracking','4','sutham added item 155');
INSERT INTO `glpi_events` VALUES ('427','155','ticket','2017-02-10 09:14:45','tracking','4','sutham updated item');
INSERT INTO `glpi_events` VALUES ('428','-1','system','2017-02-10 09:20:04','login','3','dong logged in from IP 192.168.2.1');

### Dump table glpi_fieldblacklists

DROP TABLE IF EXISTS `glpi_fieldblacklists`;
CREATE TABLE `glpi_fieldblacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_fieldunicities

DROP TABLE IF EXISTS `glpi_fieldunicities`;
CREATE TABLE `glpi_fieldunicities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `fields` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `action_refuse` tinyint(1) NOT NULL DEFAULT '0',
  `action_notify` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Stores field unicity criterias';


### Dump table glpi_filesystems

DROP TABLE IF EXISTS `glpi_filesystems`;
CREATE TABLE `glpi_filesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_filesystems` VALUES ('1','ext',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('2','ext2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('3','ext3',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('4','ext4',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('5','FAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('6','FAT32',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('7','VFAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('8','HFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('9','HPFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('10','HTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('11','JFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('12','JFS2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('13','NFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('14','NTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('15','ReiserFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('16','SMBFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('17','UDF',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('18','UFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('19','XFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('20','ZFS',NULL,NULL,NULL);

### Dump table glpi_fqdns

DROP TABLE IF EXISTS `glpi_fqdns`;
CREATE TABLE `glpi_fqdns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `fqdn` (`fqdn`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups

DROP TABLE IF EXISTS `glpi_groups`;
CREATE TABLE `glpi_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `ldap_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_value` text COLLATE utf8_unicode_ci,
  `ldap_group_dn` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_requester` tinyint(1) NOT NULL DEFAULT '1',
  `is_assign` tinyint(1) NOT NULL DEFAULT '1',
  `is_notify` tinyint(1) NOT NULL DEFAULT '1',
  `is_itemgroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_usergroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_manager` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  `is_task` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `ldap_field` (`ldap_field`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `ldap_value` (`ldap_value`(200)),
  KEY `ldap_group_dn` (`ldap_group_dn`(200)),
  KEY `groups_id` (`groups_id`),
  KEY `is_requester` (`is_requester`),
  KEY `is_assign` (`is_assign`),
  KEY `is_notify` (`is_notify`),
  KEY `is_itemgroup` (`is_itemgroup`),
  KEY `is_usergroup` (`is_usergroup`),
  KEY `is_manager` (`is_manager`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_knowbaseitems

DROP TABLE IF EXISTS `glpi_groups_knowbaseitems`;
CREATE TABLE `glpi_groups_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_problems

DROP TABLE IF EXISTS `glpi_groups_problems`;
CREATE TABLE `glpi_groups_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_reminders

DROP TABLE IF EXISTS `glpi_groups_reminders`;
CREATE TABLE `glpi_groups_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_rssfeeds

DROP TABLE IF EXISTS `glpi_groups_rssfeeds`;
CREATE TABLE `glpi_groups_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_tickets

DROP TABLE IF EXISTS `glpi_groups_tickets`;
CREATE TABLE `glpi_groups_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_users

DROP TABLE IF EXISTS `glpi_groups_users`;
CREATE TABLE `glpi_groups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `is_manager` tinyint(1) NOT NULL DEFAULT '0',
  `is_userdelegate` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`groups_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_manager` (`is_manager`),
  KEY `is_userdelegate` (`is_userdelegate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_holidays

DROP TABLE IF EXISTS `glpi_holidays`;
CREATE TABLE `glpi_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_perpetual` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `is_perpetual` (`is_perpetual`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_infocoms

DROP TABLE IF EXISTS `glpi_infocoms`;
CREATE TABLE `glpi_infocoms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `buy_date` date DEFAULT NULL,
  `use_date` date DEFAULT NULL,
  `warranty_duration` int(11) NOT NULL DEFAULT '0',
  `warranty_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivery_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `immo_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `warranty_value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `sink_time` int(11) NOT NULL DEFAULT '0',
  `sink_type` int(11) NOT NULL DEFAULT '0',
  `sink_coeff` float NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `bill` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `order_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `inventory_date` date DEFAULT NULL,
  `warranty_date` date DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `decommission_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`),
  KEY `buy_date` (`buy_date`),
  KEY `alert` (`alert`),
  KEY `budgets_id` (`budgets_id`),
  KEY `suppliers_id` (`suppliers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_interfacetypes

DROP TABLE IF EXISTS `glpi_interfacetypes`;
CREATE TABLE `glpi_interfacetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_interfacetypes` VALUES ('1','IDE',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('2','SATA',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('3','SCSI',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('4','USB',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('5','AGP','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('6','PCI','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('7','PCIe','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('8','PCI-X','',NULL,NULL);

### Dump table glpi_ipaddresses

DROP TABLE IF EXISTS `glpi_ipaddresses`;
CREATE TABLE `glpi_ipaddresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `binary_0` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_1` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_2` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_3` int(10) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `mainitems_id` int(11) NOT NULL DEFAULT '0',
  `mainitemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `textual` (`name`),
  KEY `binary` (`binary_0`,`binary_1`,`binary_2`,`binary_3`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `mainitem` (`mainitemtype`,`mainitems_id`,`is_deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipaddresses_ipnetworks

DROP TABLE IF EXISTS `glpi_ipaddresses_ipnetworks`;
CREATE TABLE `glpi_ipaddresses_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddresses_id` int(11) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ipaddresses_id`,`ipnetworks_id`),
  KEY `ipnetworks_id` (`ipnetworks_id`),
  KEY `ipaddresses_id` (`ipaddresses_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipnetworks

DROP TABLE IF EXISTS `glpi_ipnetworks`;
CREATE TABLE `glpi_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `addressable` tinyint(1) NOT NULL DEFAULT '0',
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_0` int(10) unsigned NOT NULL DEFAULT '0',
  `address_1` int(10) unsigned NOT NULL DEFAULT '0',
  `address_2` int(10) unsigned NOT NULL DEFAULT '0',
  `address_3` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `netmask_0` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_1` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_2` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_3` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gateway_0` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_1` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_2` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_3` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `network_definition` (`entities_id`,`address`,`netmask`),
  KEY `address` (`address_0`,`address_1`,`address_2`,`address_3`),
  KEY `netmask` (`netmask_0`,`netmask_1`,`netmask_2`,`netmask_3`),
  KEY `gateway` (`gateway_0`,`gateway_1`,`gateway_2`,`gateway_3`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipnetworks_vlans

DROP TABLE IF EXISTS `glpi_ipnetworks_vlans`;
CREATE TABLE `glpi_ipnetworks_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `link` (`ipnetworks_id`,`vlans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecases

DROP TABLE IF EXISTS `glpi_items_devicecases`;
CREATE TABLE `glpi_items_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecases_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecases_id` (`devicecases_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecontrols

DROP TABLE IF EXISTS `glpi_items_devicecontrols`;
CREATE TABLE `glpi_items_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecontrols_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecontrols_id` (`devicecontrols_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicedrives

DROP TABLE IF EXISTS `glpi_items_devicedrives`;
CREATE TABLE `glpi_items_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicedrives_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicedrives_id` (`devicedrives_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicegraphiccards

DROP TABLE IF EXISTS `glpi_items_devicegraphiccards`;
CREATE TABLE `glpi_items_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicegraphiccards_id` int(11) NOT NULL DEFAULT '0',
  `memory` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicegraphiccards_id` (`devicegraphiccards_id`),
  KEY `specificity` (`memory`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_deviceharddrives

DROP TABLE IF EXISTS `glpi_items_deviceharddrives`;
CREATE TABLE `glpi_items_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceharddrives_id` int(11) NOT NULL DEFAULT '0',
  `capacity` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceharddrives_id` (`deviceharddrives_id`),
  KEY `specificity` (`capacity`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicememories

DROP TABLE IF EXISTS `glpi_items_devicememories`;
CREATE TABLE `glpi_items_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicememories_id` int(11) NOT NULL DEFAULT '0',
  `size` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicememories_id` (`devicememories_id`),
  KEY `specificity` (`size`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicemotherboards

DROP TABLE IF EXISTS `glpi_items_devicemotherboards`;
CREATE TABLE `glpi_items_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicemotherboards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicemotherboards_id` (`devicemotherboards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicenetworkcards

DROP TABLE IF EXISTS `glpi_items_devicenetworkcards`;
CREATE TABLE `glpi_items_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicenetworkcards_id` (`devicenetworkcards_id`),
  KEY `specificity` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicepcis

DROP TABLE IF EXISTS `glpi_items_devicepcis`;
CREATE TABLE `glpi_items_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepcis_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepcis_id` (`devicepcis_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicepowersupplies

DROP TABLE IF EXISTS `glpi_items_devicepowersupplies`;
CREATE TABLE `glpi_items_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepowersupplies_id` (`devicepowersupplies_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_deviceprocessors

DROP TABLE IF EXISTS `glpi_items_deviceprocessors`;
CREATE TABLE `glpi_items_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceprocessors_id` int(11) NOT NULL DEFAULT '0',
  `frequency` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `nbcores` int(11) DEFAULT NULL,
  `nbthreads` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceprocessors_id` (`deviceprocessors_id`),
  KEY `specificity` (`frequency`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `nbcores` (`nbcores`),
  KEY `nbthreads` (`nbthreads`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicesoundcards

DROP TABLE IF EXISTS `glpi_items_devicesoundcards`;
CREATE TABLE `glpi_items_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicesoundcards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicesoundcards_id` (`devicesoundcards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_problems

DROP TABLE IF EXISTS `glpi_items_problems`;
CREATE TABLE `glpi_items_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_projects

DROP TABLE IF EXISTS `glpi_items_projects`;
CREATE TABLE `glpi_items_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_tickets

DROP TABLE IF EXISTS `glpi_items_tickets`;
CREATE TABLE `glpi_items_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_itilcategories

DROP TABLE IF EXISTS `glpi_itilcategories`;
CREATE TABLE `glpi_itilcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_helpdeskvisible` tinyint(1) NOT NULL DEFAULT '1',
  `tickettemplates_id_incident` int(11) NOT NULL DEFAULT '0',
  `tickettemplates_id_demand` int(11) NOT NULL DEFAULT '0',
  `is_incident` int(11) NOT NULL DEFAULT '1',
  `is_request` int(11) NOT NULL DEFAULT '1',
  `is_problem` int(11) NOT NULL DEFAULT '1',
  `is_change` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `users_id` (`users_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `tickettemplates_id_incident` (`tickettemplates_id_incident`),
  KEY `tickettemplates_id_demand` (`tickettemplates_id_demand`),
  KEY `is_incident` (`is_incident`),
  KEY `is_request` (`is_request`),
  KEY `is_problem` (`is_problem`),
  KEY `is_change` (`is_change`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_itilcategories` VALUES ('1','0','0','0','Hardware','Hardware','','1','0','0','0',NULL,'{\"1\":\"1\",\"2\":\"2\",\"57\":\"57\",\"31\":\"31\",\"50\":\"50\",\"5\":\"5\",\"60\":\"60\",\"6\":\"6\",\"7\":\"7\",\"3\":\"3\",\"4\":\"4\",\"52\":\"52\",\"58\":\"58\",\"51\":\"51\",\"28\":\"28\",\"22\":\"22\"}','1','0','0','1','1','1','1','2017-02-05 12:44:00','2017-02-05 12:44:00');
INSERT INTO `glpi_itilcategories` VALUES ('2','0','0','1','Computer','Hardware > Computer','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:44:15','2017-02-05 12:44:15');
INSERT INTO `glpi_itilcategories` VALUES ('3','0','0','1','Monitor','Hardware > Monitor','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:44:30','2017-02-05 12:44:30');
INSERT INTO `glpi_itilcategories` VALUES ('4','0','0','1','Mouse','Hardware > Mouse','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:44:36','2017-02-05 12:44:36');
INSERT INTO `glpi_itilcategories` VALUES ('5','0','0','1','Keyboard','Hardware > Keyboard','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:44:45','2017-02-05 12:44:45');
INSERT INTO `glpi_itilcategories` VALUES ('6','0','0','1','Line AC (สายไฟ)','Hardware > Line AC (สายไฟ)','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:46:26','2017-02-05 12:46:26');
INSERT INTO `glpi_itilcategories` VALUES ('7','0','0','1','Line VGA (สาย VGA)','Hardware > Line VGA (สาย VGA)','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:46:54','2017-02-05 12:46:54');
INSERT INTO `glpi_itilcategories` VALUES ('8','0','0','0','Network','Network','','1','0','0','0',NULL,'{\"8\":\"8\",\"20\":\"20\",\"11\":\"11\",\"21\":\"21\",\"15\":\"15\",\"17\":\"17\",\"9\":\"9\",\"14\":\"14\",\"12\":\"12\",\"16\":\"16\",\"13\":\"13\",\"19\":\"19\",\"10\":\"10\"}','1','0','0','1','1','1','1','2017-02-05 12:47:28','2017-02-05 12:47:28');
INSERT INTO `glpi_itilcategories` VALUES ('9','0','0','8','LAN','Network > LAN','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:47:35','2017-02-05 12:47:35');
INSERT INTO `glpi_itilcategories` VALUES ('10','0','0','8','WIFI','Network > WIFI','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:47:45','2017-02-05 12:47:45');
INSERT INTO `glpi_itilcategories` VALUES ('11','0','0','8','ACCESS POINT','Network > ACCESS POINT','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:48:04','2017-02-05 12:48:04');
INSERT INTO `glpi_itilcategories` VALUES ('12','0','0','8','Router','Network > Router','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:48:12','2017-02-05 12:48:12');
INSERT INTO `glpi_itilcategories` VALUES ('13','0','0','8','Switch','Network > Switch','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:48:18','2017-02-05 12:48:18');
INSERT INTO `glpi_itilcategories` VALUES ('14','0','0','8','Mikrotik','Network > Mikrotik','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:48:30','2017-02-05 12:48:30');
INSERT INTO `glpi_itilcategories` VALUES ('15','0','0','8','Hub','Network > Hub','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:48:37','2017-02-05 12:48:37');
INSERT INTO `glpi_itilcategories` VALUES ('16','0','0','8','Ruckus','Network > Ruckus','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:49:00','2017-02-05 12:49:00');
INSERT INTO `glpi_itilcategories` VALUES ('17','0','0','8','IBSG','Network > IBSG','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:49:07','2017-02-05 12:49:07');
INSERT INTO `glpi_itilcategories` VALUES ('19','0','0','8','WAN','Network > WAN','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:49:49','2017-02-05 12:49:49');
INSERT INTO `glpi_itilcategories` VALUES ('20','0','0','8','Access control limark','Network > Access control limark','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:50:22','2017-02-05 12:50:22');
INSERT INTO `glpi_itilcategories` VALUES ('21','0','0','8','Fiber','Network > Fiber','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:50:47','2017-02-05 12:50:47');
INSERT INTO `glpi_itilcategories` VALUES ('22','0','0','1','UPS','Hardware > UPS','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:50:55','2017-02-05 12:50:55');
INSERT INTO `glpi_itilcategories` VALUES ('75','0','0','0','Orther','Orther','','1','0','0','0',NULL,'{\"75\":\"75\"}','1','0','0','1','1','1','1','2017-02-08 01:29:12','2017-02-08 01:29:12');
INSERT INTO `glpi_itilcategories` VALUES ('24','0','0','0','Software','Software','','1','0','0','0',NULL,'{\"24\":\"24\",\"74\":\"74\",\"26\":\"26\",\"29\":\"29\",\"27\":\"27\",\"25\":\"25\",\"30\":\"30\",\"32\":\"32\",\"33\":\"33\",\"34\":\"34\",\"42\":\"42\",\"43\":\"43\",\"35\":\"35\",\"36\":\"36\",\"37\":\"37\",\"38\":\"38\",\"39\":\"39\",\"40\":\"40\",\"41\":\"41\"}','1','0','0','1','1','1','1','2017-02-05 12:52:04','2017-02-05 12:52:04');
INSERT INTO `glpi_itilcategories` VALUES ('25','0','0','24','Newsoft','Software > Newsoft','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:52:55','2017-02-05 12:52:55');
INSERT INTO `glpi_itilcategories` VALUES ('26','0','0','24','Antivirus','Software > Antivirus','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:53:06','2017-02-05 12:53:06');
INSERT INTO `glpi_itilcategories` VALUES ('27','0','0','24','MS OFFICE','Software > MS OFFICE','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:53:14','2017-02-05 12:53:14');
INSERT INTO `glpi_itilcategories` VALUES ('28','0','0','1','Speaker','Hardware > Speaker','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:54:12','2017-02-05 12:54:12');
INSERT INTO `glpi_itilcategories` VALUES ('29','0','0','24','HR @PAYROLL','Software > HR @PAYROLL','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:54:45','2017-02-05 12:54:45');
INSERT INTO `glpi_itilcategories` VALUES ('30','0','0','24','Time attendance','Software > Time attendance','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:55:16','2017-02-05 12:55:16');
INSERT INTO `glpi_itilcategories` VALUES ('31','0','0','1','Finger Scan','Hardware > Finger Scan','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:55:48','2017-02-05 12:55:48');
INSERT INTO `glpi_itilcategories` VALUES ('32','0','0','25','Key Card Onity','Software > Newsoft > Key Card Onity','','3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:56:21','2017-02-05 12:56:21');
INSERT INTO `glpi_itilcategories` VALUES ('33','0','0','25','Fromas','Software > Newsoft > Fromas','','3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 12:56:30','2017-02-05 12:56:30');
INSERT INTO `glpi_itilcategories` VALUES ('34','0','0','25','AccSys','Software > Newsoft > AccSys','','3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:01:49','2017-02-05 13:01:49');
INSERT INTO `glpi_itilcategories` VALUES ('35','0','0','34','AP','Software > Newsoft > AccSys > AP','','4','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:01:56','2017-02-05 13:01:56');
INSERT INTO `glpi_itilcategories` VALUES ('36','0','0','34','AR','Software > Newsoft > AccSys > AR','','4','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:02:08','2017-02-05 13:02:08');
INSERT INTO `glpi_itilcategories` VALUES ('37','0','0','34','Daily Income','Software > Newsoft > AccSys > Daily Income','','4','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:02:32','2017-02-05 13:02:32');
INSERT INTO `glpi_itilcategories` VALUES ('38','0','0','34','GeneralLedger','Software > Newsoft > AccSys > GeneralLedger','','4','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:02:49','2017-02-05 13:02:49');
INSERT INTO `glpi_itilcategories` VALUES ('39','0','0','34','InventoryControls','Software > Newsoft > AccSys > InventoryControls','','4','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:02:58','2017-02-05 13:02:58');
INSERT INTO `glpi_itilcategories` VALUES ('40','0','0','34','Purchasing','Software > Newsoft > AccSys > Purchasing','','4','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:03:08','2017-02-05 13:03:08');
INSERT INTO `glpi_itilcategories` VALUES ('41','0','0','34','SubStoreControls','Software > Newsoft > AccSys > SubStoreControls','','4','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:03:16','2017-02-05 13:03:16');
INSERT INTO `glpi_itilcategories` VALUES ('42','0','0','25','CAMS','Software > Newsoft > CAMS','','3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:03:33','2017-02-05 13:03:33');
INSERT INTO `glpi_itilcategories` VALUES ('43','0','0','25','Comcash','Software > Newsoft > Comcash','','3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:03:46','2017-02-05 13:03:46');
INSERT INTO `glpi_itilcategories` VALUES ('44','0','0','0','WD TV','WD TV','','1','0','0','0',NULL,'{\"44\":\"44\"}','1','0','0','1','1','1','1','2017-02-05 13:06:01','2017-02-05 13:06:01');
INSERT INTO `glpi_itilcategories` VALUES ('45','0','0','0','CCTV','CCTV','','1','0','0','0',NULL,'{\"45\":\"45\",\"49\":\"49\",\"46\":\"46\",\"47\":\"47\",\"48\":\"48\"}','1','0','0','1','1','1','1','2017-02-05 13:06:22','2017-02-05 13:06:22');
INSERT INTO `glpi_itilcategories` VALUES ('46','0','0','45','Camera','CCTV > Camera','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:06:39','2017-02-05 13:06:39');
INSERT INTO `glpi_itilcategories` VALUES ('47','0','0','45','DVR','CCTV > DVR','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:06:44','2017-02-05 13:06:44');
INSERT INTO `glpi_itilcategories` VALUES ('48','0','0','45','Line signal','CCTV > Line signal','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:07:28','2017-02-05 13:07:28');
INSERT INTO `glpi_itilcategories` VALUES ('49','0','0','45','Adapter','CCTV > Adapter','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:07:34','2017-02-05 13:07:34');
INSERT INTO `glpi_itilcategories` VALUES ('50','0','0','1','hard disk','Hardware > hard disk','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:08:21','2017-02-05 13:08:21');
INSERT INTO `glpi_itilcategories` VALUES ('51','0','0','1','Ram','Hardware > Ram','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:08:34','2017-02-05 13:08:34');
INSERT INTO `glpi_itilcategories` VALUES ('52','0','0','1','Notebook','Hardware > Notebook','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:08:47','2017-02-05 13:08:47');
INSERT INTO `glpi_itilcategories` VALUES ('53','0','0','0','Accessory','Accessory','','1','0','0','0',NULL,'{\"53\":\"53\",\"55\":\"55\",\"56\":\"56\",\"54\":\"54\"}','1','0','0','1','1','1','1','2017-02-05 13:09:20','2017-02-05 13:09:20');
INSERT INTO `glpi_itilcategories` VALUES ('54','0','0','53','Line USB','Accessory > Line USB','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:09:42','2017-02-05 13:09:42');
INSERT INTO `glpi_itilcategories` VALUES ('55','0','0','53','Flash drive','Accessory > Flash drive','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:10:03','2017-02-05 13:10:03');
INSERT INTO `glpi_itilcategories` VALUES ('56','0','0','53','Line HDMI','Accessory > Line HDMI','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:10:21','2017-02-05 13:10:21');
INSERT INTO `glpi_itilcategories` VALUES ('57','0','0','1','DVD RW','Hardware > DVD RW','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:10:47','2017-02-05 13:10:47');
INSERT INTO `glpi_itilcategories` VALUES ('58','0','0','1','Power Supply','Hardware > Power Supply','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:11:01','2017-02-05 13:11:01');
INSERT INTO `glpi_itilcategories` VALUES ('59','0','0','0','Smartphone','Smartphone','','1','0','0','0',NULL,'{\"59\":\"59\"}','1','0','0','1','1','1','1','2017-02-05 13:11:36','2017-02-05 13:11:36');
INSERT INTO `glpi_itilcategories` VALUES ('60','0','0','1','Lan Card','Hardware > Lan Card','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:12:39','2017-02-05 13:12:39');
INSERT INTO `glpi_itilcategories` VALUES ('61','0','0','0','Server','Server','','1','0','0','0',NULL,'{\"61\":\"61\",\"65\":\"65\",\"68\":\"68\",\"67\":\"67\",\"64\":\"64\",\"63\":\"63\",\"66\":\"66\",\"62\":\"62\"}','1','0','0','1','1','1','1','2017-02-05 13:13:43','2017-02-05 13:13:43');
INSERT INTO `glpi_itilcategories` VALUES ('62','0','0','61','SUKA','Server > SUKA','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:13:58','2017-02-05 13:13:58');
INSERT INTO `glpi_itilcategories` VALUES ('63','0','0','61','KML','Server > KML','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:14:05','2017-02-05 13:14:05');
INSERT INTO `glpi_itilcategories` VALUES ('64','0','0','61','IBSG','Server > IBSG','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:14:15','2017-02-05 13:14:15');
INSERT INTO `glpi_itilcategories` VALUES ('65','0','0','61','Authen Newsoft','Server > Authen Newsoft','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:14:24','2017-02-05 13:14:24');
INSERT INTO `glpi_itilcategories` VALUES ('66','0','0','61','MG','Server > MG','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:14:39','2017-02-05 13:14:39');
INSERT INTO `glpi_itilcategories` VALUES ('67','0','0','61','CAM SUKA','Server > CAM SUKA','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:15:35','2017-02-05 13:15:35');
INSERT INTO `glpi_itilcategories` VALUES ('68','0','0','61','CAM KML','Server > CAM KML','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:15:42','2017-02-05 13:15:42');
INSERT INTO `glpi_itilcategories` VALUES ('69','0','0','0','Printer','Printer','','1','0','0','0',NULL,'{\"69\":\"69\",\"71\":\"71\",\"72\":\"72\",\"70\":\"70\"}','1','0','0','1','1','1','1','2017-02-05 13:17:26','2017-02-05 13:17:26');
INSERT INTO `glpi_itilcategories` VALUES ('70','0','0','69','TMU220','Printer > TMU220','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:17:41','2017-02-05 13:17:41');
INSERT INTO `glpi_itilcategories` VALUES ('71','0','0','69','EPSON210/220','Printer > EPSON210/220','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:17:59','2017-02-05 13:17:59');
INSERT INTO `glpi_itilcategories` VALUES ('72','0','0','69','Konica','Printer > Konica','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-05 13:18:57','2017-02-05 13:18:57');
INSERT INTO `glpi_itilcategories` VALUES ('73','0','0','0','Scan Passport','Scan Passport','','1','0','0','0',NULL,'{\"73\":\"73\"}','1','0','0','1','1','1','1','2017-02-05 13:19:51','2017-02-05 13:19:51');
INSERT INTO `glpi_itilcategories` VALUES ('74','0','0','24','Adobe','Software > Adobe','','2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-02-08 01:18:57','2017-02-08 01:18:57');
INSERT INTO `glpi_itilcategories` VALUES ('76','0','0','0','VPN','VPN','','1','0','0','0',NULL,'{\"76\":\"76\"}','1','0','0','1','1','1','1','2017-02-08 03:20:51','2017-02-08 03:20:51');
INSERT INTO `glpi_itilcategories` VALUES ('77','0','0','0','REMOTE DESKTOP','REMOTE DESKTOP','','1','0','0','0',NULL,'{\"77\":\"77\"}','1','0','0','1','1','1','1','2017-02-08 03:20:57','2017-02-08 03:20:57');
INSERT INTO `glpi_itilcategories` VALUES ('78','0','0','0','MAIL','MAIL','','1','0','0','0',NULL,'{\"78\":\"78\"}','1','0','0','1','1','1','1','2017-02-08 03:21:06','2017-02-08 03:21:06');

### Dump table glpi_knowbaseitemcategories

DROP TABLE IF EXISTS `glpi_knowbaseitemcategories`;
CREATE TABLE `glpi_knowbaseitemcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`knowbaseitemcategories_id`,`name`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems

DROP TABLE IF EXISTS `glpi_knowbaseitems`;
CREATE TABLE `glpi_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `is_faq` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `is_faq` (`is_faq`),
  KEY `date_mod` (`date_mod`),
  FULLTEXT KEY `fulltext` (`name`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_profiles

DROP TABLE IF EXISTS `glpi_knowbaseitems_profiles`;
CREATE TABLE `glpi_knowbaseitems_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_users

DROP TABLE IF EXISTS `glpi_knowbaseitems_users`;
CREATE TABLE `glpi_knowbaseitems_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitemtranslations

DROP TABLE IF EXISTS `glpi_knowbaseitemtranslations`;
CREATE TABLE `glpi_knowbaseitemtranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`knowbaseitems_id`,`language`),
  FULLTEXT KEY `fulltext` (`name`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links

DROP TABLE IF EXISTS `glpi_links`;
CREATE TABLE `glpi_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `open_window` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links_itemtypes

DROP TABLE IF EXISTS `glpi_links_itemtypes`;
CREATE TABLE `glpi_links_itemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `links_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`links_id`),
  KEY `links_id` (`links_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_locations

DROP TABLE IF EXISTS `glpi_locations`;
CREATE TABLE `glpi_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `building` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `altitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`locations_id`,`name`),
  KEY `locations_id` (`locations_id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_logs

DROP TABLE IF EXISTS `glpi_logs`;
CREATE TABLE `glpi_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype_link` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `linked_action` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php HISTORY_* constant',
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `id_search_option` int(11) NOT NULL DEFAULT '0' COMMENT 'see search.constant.php for value',
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `itemtype_link` (`itemtype_link`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_logs` VALUES ('1','User','2','','0','dong (2)','2017-02-05 03:32:14','1','glpi','dong');
INSERT INTO `glpi_logs` VALUES ('2','User','2','','0','dong (2)','2017-02-05 03:32:14','9','','itsunwing');
INSERT INTO `glpi_logs` VALUES ('3','User','2','UserEmail','17','dong (2)','2017-02-05 03:32:14','0','','suthamtg@gmail.com (1)');
INSERT INTO `glpi_logs` VALUES ('4','UserEmail','1','0','20','dong (2)','2017-02-05 03:32:14','0','','');
INSERT INTO `glpi_logs` VALUES ('5','ITILCategory','1','0','20','dong (2)','2017-02-05 12:44:00','0','','');
INSERT INTO `glpi_logs` VALUES ('6','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:44:15','0','','Computer');
INSERT INTO `glpi_logs` VALUES ('7','ITILCategory','2','0','20','dong (2)','2017-02-05 12:44:15','0','','');
INSERT INTO `glpi_logs` VALUES ('8','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:44:30','0','','Monitor');
INSERT INTO `glpi_logs` VALUES ('9','ITILCategory','3','0','20','dong (2)','2017-02-05 12:44:30','0','','');
INSERT INTO `glpi_logs` VALUES ('10','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:44:36','0','','Mouse');
INSERT INTO `glpi_logs` VALUES ('11','ITILCategory','4','0','20','dong (2)','2017-02-05 12:44:36','0','','');
INSERT INTO `glpi_logs` VALUES ('12','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:44:45','0','','Keyboard');
INSERT INTO `glpi_logs` VALUES ('13','ITILCategory','5','0','20','dong (2)','2017-02-05 12:44:45','0','','');
INSERT INTO `glpi_logs` VALUES ('14','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:46:26','0','','Line AC (สายไฟ)');
INSERT INTO `glpi_logs` VALUES ('15','ITILCategory','6','0','20','dong (2)','2017-02-05 12:46:26','0','','');
INSERT INTO `glpi_logs` VALUES ('16','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:46:54','0','','Line VGA (สาย VGA)');
INSERT INTO `glpi_logs` VALUES ('17','ITILCategory','7','0','20','dong (2)','2017-02-05 12:46:54','0','','');
INSERT INTO `glpi_logs` VALUES ('18','ITILCategory','8','0','20','dong (2)','2017-02-05 12:47:28','0','','');
INSERT INTO `glpi_logs` VALUES ('19','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:47:35','0','','LAN');
INSERT INTO `glpi_logs` VALUES ('20','ITILCategory','9','0','20','dong (2)','2017-02-05 12:47:35','0','','');
INSERT INTO `glpi_logs` VALUES ('21','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:47:45','0','','WIFI');
INSERT INTO `glpi_logs` VALUES ('22','ITILCategory','10','0','20','dong (2)','2017-02-05 12:47:45','0','','');
INSERT INTO `glpi_logs` VALUES ('23','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:48:04','0','','ACCESS POINT');
INSERT INTO `glpi_logs` VALUES ('24','ITILCategory','11','0','20','dong (2)','2017-02-05 12:48:04','0','','');
INSERT INTO `glpi_logs` VALUES ('25','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:48:12','0','','Router');
INSERT INTO `glpi_logs` VALUES ('26','ITILCategory','12','0','20','dong (2)','2017-02-05 12:48:12','0','','');
INSERT INTO `glpi_logs` VALUES ('27','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:48:18','0','','Switch');
INSERT INTO `glpi_logs` VALUES ('28','ITILCategory','13','0','20','dong (2)','2017-02-05 12:48:18','0','','');
INSERT INTO `glpi_logs` VALUES ('29','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:48:30','0','','Mikrotik');
INSERT INTO `glpi_logs` VALUES ('30','ITILCategory','14','0','20','dong (2)','2017-02-05 12:48:30','0','','');
INSERT INTO `glpi_logs` VALUES ('31','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:48:37','0','','Hub');
INSERT INTO `glpi_logs` VALUES ('32','ITILCategory','15','0','20','dong (2)','2017-02-05 12:48:37','0','','');
INSERT INTO `glpi_logs` VALUES ('33','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:49:00','0','','Ruckus');
INSERT INTO `glpi_logs` VALUES ('34','ITILCategory','16','0','20','dong (2)','2017-02-05 12:49:00','0','','');
INSERT INTO `glpi_logs` VALUES ('35','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:49:07','0','','IBSG');
INSERT INTO `glpi_logs` VALUES ('36','ITILCategory','17','0','20','dong (2)','2017-02-05 12:49:07','0','','');
INSERT INTO `glpi_logs` VALUES ('37','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:49:25','0','','Authen Newsoft');
INSERT INTO `glpi_logs` VALUES ('274','ITILCategory','8','ITILCategory','19','dong (2)','2017-02-08 01:17:36','0','Authen Newsoft','');
INSERT INTO `glpi_logs` VALUES ('39','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:49:49','0','','WAN');
INSERT INTO `glpi_logs` VALUES ('40','ITILCategory','19','0','20','dong (2)','2017-02-05 12:49:49','0','','');
INSERT INTO `glpi_logs` VALUES ('41','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:50:22','0','','Access control limark');
INSERT INTO `glpi_logs` VALUES ('42','ITILCategory','20','0','20','dong (2)','2017-02-05 12:50:22','0','','');
INSERT INTO `glpi_logs` VALUES ('43','ITILCategory','8','ITILCategory','17','dong (2)','2017-02-05 12:50:47','0','','Fiber');
INSERT INTO `glpi_logs` VALUES ('44','ITILCategory','21','0','20','dong (2)','2017-02-05 12:50:47','0','','');
INSERT INTO `glpi_logs` VALUES ('45','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:50:55','0','','UPS');
INSERT INTO `glpi_logs` VALUES ('46','ITILCategory','22','0','20','dong (2)','2017-02-05 12:50:55','0','','');
INSERT INTO `glpi_logs` VALUES ('47','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:51:33','0','','Printer');
INSERT INTO `glpi_logs` VALUES ('273','ITILCategory','1','ITILCategory','19','dong (2)','2017-02-08 01:17:17','0','Printer','');
INSERT INTO `glpi_logs` VALUES ('49','ITILCategory','24','0','20','dong (2)','2017-02-05 12:52:04','0','','');
INSERT INTO `glpi_logs` VALUES ('50','ITILCategory','24','ITILCategory','17','dong (2)','2017-02-05 12:52:55','0','','Newsoft');
INSERT INTO `glpi_logs` VALUES ('51','ITILCategory','25','0','20','dong (2)','2017-02-05 12:52:55','0','','');
INSERT INTO `glpi_logs` VALUES ('52','ITILCategory','24','ITILCategory','17','dong (2)','2017-02-05 12:53:06','0','','Antivirus');
INSERT INTO `glpi_logs` VALUES ('53','ITILCategory','26','0','20','dong (2)','2017-02-05 12:53:06','0','','');
INSERT INTO `glpi_logs` VALUES ('54','ITILCategory','24','ITILCategory','17','dong (2)','2017-02-05 12:53:14','0','','MS OFFICE');
INSERT INTO `glpi_logs` VALUES ('55','ITILCategory','27','0','20','dong (2)','2017-02-05 12:53:14','0','','');
INSERT INTO `glpi_logs` VALUES ('56','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:54:12','0','','Speaker');
INSERT INTO `glpi_logs` VALUES ('57','ITILCategory','28','0','20','dong (2)','2017-02-05 12:54:12','0','','');
INSERT INTO `glpi_logs` VALUES ('58','ITILCategory','24','ITILCategory','17','dong (2)','2017-02-05 12:54:45','0','','HR @PAYROLL');
INSERT INTO `glpi_logs` VALUES ('59','ITILCategory','29','0','20','dong (2)','2017-02-05 12:54:45','0','','');
INSERT INTO `glpi_logs` VALUES ('60','ITILCategory','24','ITILCategory','17','dong (2)','2017-02-05 12:55:16','0','','Time attendance');
INSERT INTO `glpi_logs` VALUES ('61','ITILCategory','30','0','20','dong (2)','2017-02-05 12:55:16','0','','');
INSERT INTO `glpi_logs` VALUES ('62','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 12:55:48','0','','Finger Scan');
INSERT INTO `glpi_logs` VALUES ('63','ITILCategory','31','0','20','dong (2)','2017-02-05 12:55:48','0','','');
INSERT INTO `glpi_logs` VALUES ('64','ITILCategory','25','ITILCategory','17','dong (2)','2017-02-05 12:56:21','0','','Key Card Onity');
INSERT INTO `glpi_logs` VALUES ('65','ITILCategory','32','0','20','dong (2)','2017-02-05 12:56:21','0','','');
INSERT INTO `glpi_logs` VALUES ('66','ITILCategory','25','ITILCategory','17','dong (2)','2017-02-05 12:56:30','0','','Fromas');
INSERT INTO `glpi_logs` VALUES ('67','ITILCategory','33','0','20','dong (2)','2017-02-05 12:56:30','0','','');
INSERT INTO `glpi_logs` VALUES ('68','ITILCategory','25','ITILCategory','17','dong (2)','2017-02-05 13:01:49','0','','AccSys');
INSERT INTO `glpi_logs` VALUES ('69','ITILCategory','34','0','20','dong (2)','2017-02-05 13:01:49','0','','');
INSERT INTO `glpi_logs` VALUES ('70','ITILCategory','34','ITILCategory','17','dong (2)','2017-02-05 13:01:56','0','','AP');
INSERT INTO `glpi_logs` VALUES ('71','ITILCategory','35','0','20','dong (2)','2017-02-05 13:01:56','0','','');
INSERT INTO `glpi_logs` VALUES ('72','ITILCategory','34','ITILCategory','17','dong (2)','2017-02-05 13:02:08','0','','AR');
INSERT INTO `glpi_logs` VALUES ('73','ITILCategory','36','0','20','dong (2)','2017-02-05 13:02:08','0','','');
INSERT INTO `glpi_logs` VALUES ('74','ITILCategory','34','ITILCategory','17','dong (2)','2017-02-05 13:02:32','0','','Daily Income');
INSERT INTO `glpi_logs` VALUES ('75','ITILCategory','37','0','20','dong (2)','2017-02-05 13:02:32','0','','');
INSERT INTO `glpi_logs` VALUES ('76','ITILCategory','34','ITILCategory','17','dong (2)','2017-02-05 13:02:49','0','','GeneralLedger');
INSERT INTO `glpi_logs` VALUES ('77','ITILCategory','38','0','20','dong (2)','2017-02-05 13:02:49','0','','');
INSERT INTO `glpi_logs` VALUES ('78','ITILCategory','34','ITILCategory','17','dong (2)','2017-02-05 13:02:58','0','','InventoryControls');
INSERT INTO `glpi_logs` VALUES ('79','ITILCategory','39','0','20','dong (2)','2017-02-05 13:02:58','0','','');
INSERT INTO `glpi_logs` VALUES ('80','ITILCategory','34','ITILCategory','17','dong (2)','2017-02-05 13:03:08','0','','Purchasing');
INSERT INTO `glpi_logs` VALUES ('81','ITILCategory','40','0','20','dong (2)','2017-02-05 13:03:08','0','','');
INSERT INTO `glpi_logs` VALUES ('82','ITILCategory','34','ITILCategory','17','dong (2)','2017-02-05 13:03:16','0','','SubStoreControls');
INSERT INTO `glpi_logs` VALUES ('83','ITILCategory','41','0','20','dong (2)','2017-02-05 13:03:16','0','','');
INSERT INTO `glpi_logs` VALUES ('84','ITILCategory','25','ITILCategory','17','dong (2)','2017-02-05 13:03:33','0','','CAMS');
INSERT INTO `glpi_logs` VALUES ('85','ITILCategory','42','0','20','dong (2)','2017-02-05 13:03:33','0','','');
INSERT INTO `glpi_logs` VALUES ('86','ITILCategory','25','ITILCategory','17','dong (2)','2017-02-05 13:03:46','0','','Comcash');
INSERT INTO `glpi_logs` VALUES ('87','ITILCategory','43','0','20','dong (2)','2017-02-05 13:03:46','0','','');
INSERT INTO `glpi_logs` VALUES ('88','ITILCategory','44','0','20','dong (2)','2017-02-05 13:06:01','0','','');
INSERT INTO `glpi_logs` VALUES ('89','ITILCategory','45','0','20','dong (2)','2017-02-05 13:06:22','0','','');
INSERT INTO `glpi_logs` VALUES ('90','ITILCategory','45','ITILCategory','17','dong (2)','2017-02-05 13:06:39','0','','Camera');
INSERT INTO `glpi_logs` VALUES ('91','ITILCategory','46','0','20','dong (2)','2017-02-05 13:06:39','0','','');
INSERT INTO `glpi_logs` VALUES ('92','ITILCategory','45','ITILCategory','17','dong (2)','2017-02-05 13:06:44','0','','DVR');
INSERT INTO `glpi_logs` VALUES ('93','ITILCategory','47','0','20','dong (2)','2017-02-05 13:06:44','0','','');
INSERT INTO `glpi_logs` VALUES ('94','ITILCategory','45','ITILCategory','17','dong (2)','2017-02-05 13:07:28','0','','Line signal');
INSERT INTO `glpi_logs` VALUES ('95','ITILCategory','48','0','20','dong (2)','2017-02-05 13:07:28','0','','');
INSERT INTO `glpi_logs` VALUES ('96','ITILCategory','45','ITILCategory','17','dong (2)','2017-02-05 13:07:34','0','','Adapter');
INSERT INTO `glpi_logs` VALUES ('97','ITILCategory','49','0','20','dong (2)','2017-02-05 13:07:34','0','','');
INSERT INTO `glpi_logs` VALUES ('98','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 13:08:21','0','','hard disk');
INSERT INTO `glpi_logs` VALUES ('99','ITILCategory','50','0','20','dong (2)','2017-02-05 13:08:21','0','','');
INSERT INTO `glpi_logs` VALUES ('100','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 13:08:34','0','','Ram');
INSERT INTO `glpi_logs` VALUES ('101','ITILCategory','51','0','20','dong (2)','2017-02-05 13:08:34','0','','');
INSERT INTO `glpi_logs` VALUES ('102','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 13:08:47','0','','Notebook');
INSERT INTO `glpi_logs` VALUES ('103','ITILCategory','52','0','20','dong (2)','2017-02-05 13:08:47','0','','');
INSERT INTO `glpi_logs` VALUES ('104','ITILCategory','53','0','20','dong (2)','2017-02-05 13:09:20','0','','');
INSERT INTO `glpi_logs` VALUES ('105','ITILCategory','53','ITILCategory','17','dong (2)','2017-02-05 13:09:42','0','','Line USB');
INSERT INTO `glpi_logs` VALUES ('106','ITILCategory','54','0','20','dong (2)','2017-02-05 13:09:42','0','','');
INSERT INTO `glpi_logs` VALUES ('107','ITILCategory','53','ITILCategory','17','dong (2)','2017-02-05 13:10:03','0','','Flash drive');
INSERT INTO `glpi_logs` VALUES ('108','ITILCategory','55','0','20','dong (2)','2017-02-05 13:10:03','0','','');
INSERT INTO `glpi_logs` VALUES ('109','ITILCategory','53','ITILCategory','17','dong (2)','2017-02-05 13:10:21','0','','Line HDMI');
INSERT INTO `glpi_logs` VALUES ('110','ITILCategory','56','0','20','dong (2)','2017-02-05 13:10:21','0','','');
INSERT INTO `glpi_logs` VALUES ('111','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 13:10:47','0','','DVD RW');
INSERT INTO `glpi_logs` VALUES ('112','ITILCategory','57','0','20','dong (2)','2017-02-05 13:10:47','0','','');
INSERT INTO `glpi_logs` VALUES ('113','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 13:11:01','0','','Power Supply');
INSERT INTO `glpi_logs` VALUES ('114','ITILCategory','58','0','20','dong (2)','2017-02-05 13:11:01','0','','');
INSERT INTO `glpi_logs` VALUES ('115','ITILCategory','59','0','20','dong (2)','2017-02-05 13:11:36','0','','');
INSERT INTO `glpi_logs` VALUES ('116','ITILCategory','1','ITILCategory','17','dong (2)','2017-02-05 13:12:39','0','','Lan Card');
INSERT INTO `glpi_logs` VALUES ('117','ITILCategory','60','0','20','dong (2)','2017-02-05 13:12:39','0','','');
INSERT INTO `glpi_logs` VALUES ('118','ITILCategory','61','0','20','dong (2)','2017-02-05 13:13:43','0','','');
INSERT INTO `glpi_logs` VALUES ('119','ITILCategory','61','ITILCategory','17','dong (2)','2017-02-05 13:13:58','0','','SUKA');
INSERT INTO `glpi_logs` VALUES ('120','ITILCategory','62','0','20','dong (2)','2017-02-05 13:13:58','0','','');
INSERT INTO `glpi_logs` VALUES ('121','ITILCategory','61','ITILCategory','17','dong (2)','2017-02-05 13:14:05','0','','KML');
INSERT INTO `glpi_logs` VALUES ('122','ITILCategory','63','0','20','dong (2)','2017-02-05 13:14:05','0','','');
INSERT INTO `glpi_logs` VALUES ('123','ITILCategory','61','ITILCategory','17','dong (2)','2017-02-05 13:14:15','0','','IBSG');
INSERT INTO `glpi_logs` VALUES ('124','ITILCategory','64','0','20','dong (2)','2017-02-05 13:14:15','0','','');
INSERT INTO `glpi_logs` VALUES ('125','ITILCategory','61','ITILCategory','17','dong (2)','2017-02-05 13:14:24','0','','Authen Newsoft');
INSERT INTO `glpi_logs` VALUES ('126','ITILCategory','65','0','20','dong (2)','2017-02-05 13:14:24','0','','');
INSERT INTO `glpi_logs` VALUES ('127','ITILCategory','61','ITILCategory','17','dong (2)','2017-02-05 13:14:39','0','','MG');
INSERT INTO `glpi_logs` VALUES ('128','ITILCategory','66','0','20','dong (2)','2017-02-05 13:14:39','0','','');
INSERT INTO `glpi_logs` VALUES ('129','ITILCategory','61','ITILCategory','17','dong (2)','2017-02-05 13:15:35','0','','CAM SUKA');
INSERT INTO `glpi_logs` VALUES ('130','ITILCategory','67','0','20','dong (2)','2017-02-05 13:15:35','0','','');
INSERT INTO `glpi_logs` VALUES ('131','ITILCategory','61','ITILCategory','17','dong (2)','2017-02-05 13:15:42','0','','CAM KML');
INSERT INTO `glpi_logs` VALUES ('132','ITILCategory','68','0','20','dong (2)','2017-02-05 13:15:42','0','','');
INSERT INTO `glpi_logs` VALUES ('133','ITILCategory','69','0','20','dong (2)','2017-02-05 13:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('134','ITILCategory','69','ITILCategory','17','dong (2)','2017-02-05 13:17:41','0','','TMU220');
INSERT INTO `glpi_logs` VALUES ('135','ITILCategory','70','0','20','dong (2)','2017-02-05 13:17:41','0','','');
INSERT INTO `glpi_logs` VALUES ('136','ITILCategory','69','ITILCategory','17','dong (2)','2017-02-05 13:17:59','0','','EPSON210/220');
INSERT INTO `glpi_logs` VALUES ('137','ITILCategory','71','0','20','dong (2)','2017-02-05 13:17:59','0','','');
INSERT INTO `glpi_logs` VALUES ('138','ITILCategory','69','ITILCategory','17','dong (2)','2017-02-05 13:18:57','0','','Konica');
INSERT INTO `glpi_logs` VALUES ('139','ITILCategory','72','0','20','dong (2)','2017-02-05 13:18:57','0','','');
INSERT INTO `glpi_logs` VALUES ('140','ITILCategory','73','0','20','dong (2)','2017-02-05 13:19:51','0','','');
INSERT INTO `glpi_logs` VALUES ('141','User','6','UserEmail','17','dong (2)','2017-02-06 04:19:25','0','','itswrkb@oceanresortgroup.net (2)');
INSERT INTO `glpi_logs` VALUES ('142','UserEmail','2','0','20','dong (2)','2017-02-06 04:19:25','0','','');
INSERT INTO `glpi_logs` VALUES ('143','User','6','Profile','17','dong (2)','2017-02-06 04:19:25','0','','Technician (6)');
INSERT INTO `glpi_logs` VALUES ('144','User','6','0','20','dong (2)','2017-02-06 04:19:25','0','','');
INSERT INTO `glpi_logs` VALUES ('145','Ticket','1','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:23:59','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('146','Ticket','1','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:23:59','0','','');
INSERT INTO `glpi_logs` VALUES ('147','Ticket','1','','0','Manassrisuksai Sutham (6)','2017-02-06 04:26:09','24','','&lt;p&gt;Switch ใต้ตึกดับ ดำเนินการแก้ไขแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('148','Ticket','1','','0','Manassrisuksai Sutham (6)','2017-02-06 04:26:09','12','1','6');
INSERT INTO `glpi_logs` VALUES ('149','Ticket','1','','0','Manassrisuksai Sutham (6)','2017-02-06 04:26:09','16','','2017-02-06 04:26:09');
INSERT INTO `glpi_logs` VALUES ('150','Ticket','1','','0','Manassrisuksai Sutham (6)','2017-02-06 04:26:09','17','','2017-02-06 04:26:09');
INSERT INTO `glpi_logs` VALUES ('151','Ticket','2','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:29:52','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('152','Ticket','2','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:29:52','0','','');
INSERT INTO `glpi_logs` VALUES ('153','Ticket','2','','0','Manassrisuksai Sutham (6)','2017-02-06 04:30:51','24','','&lt;p&gt;เมนบอร์ดเสีย  ได้ดำเนินการเปลี่ยนคอมพิวเตอร์ให้ใหม่&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('154','Ticket','2','','0','Manassrisuksai Sutham (6)','2017-02-06 04:30:51','12','1','6');
INSERT INTO `glpi_logs` VALUES ('155','Ticket','2','','0','Manassrisuksai Sutham (6)','2017-02-06 04:30:51','16','','2017-02-06 04:30:51');
INSERT INTO `glpi_logs` VALUES ('156','Ticket','2','','0','Manassrisuksai Sutham (6)','2017-02-06 04:30:51','17','','2017-02-06 04:30:51');
INSERT INTO `glpi_logs` VALUES ('157','Ticket','3','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:33:07','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('158','Ticket','3','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:33:07','0','','');
INSERT INTO `glpi_logs` VALUES ('159','Ticket','3','','0','Manassrisuksai Sutham (6)','2017-02-06 04:33:47','24','','&lt;p&gt;ปรับเวลาเป็น 7 วัน ใน Authen&lt;/p&gt;rn&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('160','Ticket','3','','0','Manassrisuksai Sutham (6)','2017-02-06 04:33:47','12','1','6');
INSERT INTO `glpi_logs` VALUES ('161','Ticket','3','','0','Manassrisuksai Sutham (6)','2017-02-06 04:33:47','16','','2017-02-06 04:33:47');
INSERT INTO `glpi_logs` VALUES ('162','Ticket','3','','0','Manassrisuksai Sutham (6)','2017-02-06 04:33:47','17','','2017-02-06 04:33:47');
INSERT INTO `glpi_logs` VALUES ('163','Ticket','4','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:35:02','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('164','Ticket','4','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:35:02','0','','');
INSERT INTO `glpi_logs` VALUES ('165','Ticket','4','','0','Manassrisuksai Sutham (6)','2017-02-06 04:35:26','24','','&lt;p&gt;เปลี่ยน UPS Accounting Room&lt;/p&gt;rn&lt;p&gt;User ใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('166','Ticket','4','','0','Manassrisuksai Sutham (6)','2017-02-06 04:35:26','12','1','6');
INSERT INTO `glpi_logs` VALUES ('167','Ticket','4','','0','Manassrisuksai Sutham (6)','2017-02-06 04:35:26','16','','2017-02-06 04:35:26');
INSERT INTO `glpi_logs` VALUES ('168','Ticket','4','','0','Manassrisuksai Sutham (6)','2017-02-06 04:35:26','17','','2017-02-06 04:35:26');
INSERT INTO `glpi_logs` VALUES ('169','Ticket','5','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:37:37','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('170','Ticket','5','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:37:37','0','','');
INSERT INTO `glpi_logs` VALUES ('171','Ticket','5','','0','Manassrisuksai Sutham (6)','2017-02-06 04:38:10','24','','&lt;p&gt;สายปลั๊กไฟหลุด&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('172','Ticket','5','','0','Manassrisuksai Sutham (6)','2017-02-06 04:38:10','12','1','6');
INSERT INTO `glpi_logs` VALUES ('173','Ticket','5','','0','Manassrisuksai Sutham (6)','2017-02-06 04:38:10','16','','2017-02-06 04:38:10');
INSERT INTO `glpi_logs` VALUES ('174','Ticket','5','','0','Manassrisuksai Sutham (6)','2017-02-06 04:38:10','17','','2017-02-06 04:38:10');
INSERT INTO `glpi_logs` VALUES ('175','Ticket','6','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:39:39','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('176','Ticket','6','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:39:39','0','','');
INSERT INTO `glpi_logs` VALUES ('177','Ticket','6','','0','Manassrisuksai Sutham (6)','2017-02-06 04:41:28','24','','&lt;p&gt;ลงไดร์เวอร์ใหม่ User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('178','Ticket','6','','0','Manassrisuksai Sutham (6)','2017-02-06 04:41:28','12','1','6');
INSERT INTO `glpi_logs` VALUES ('179','Ticket','6','','0','Manassrisuksai Sutham (6)','2017-02-06 04:41:28','16','','2017-02-06 04:41:28');
INSERT INTO `glpi_logs` VALUES ('180','Ticket','6','','0','Manassrisuksai Sutham (6)','2017-02-06 04:41:28','17','','2017-02-06 04:41:28');
INSERT INTO `glpi_logs` VALUES ('181','Ticket','7','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:42:39','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('182','Ticket','7','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:42:39','0','','');
INSERT INTO `glpi_logs` VALUES ('183','Ticket','7','','0','Manassrisuksai Sutham (6)','2017-02-06 04:45:25','12','1','6');
INSERT INTO `glpi_logs` VALUES ('184','Ticket','7','','0','Manassrisuksai Sutham (6)','2017-02-06 04:45:25','16','','2017-02-06 04:45:25');
INSERT INTO `glpi_logs` VALUES ('185','Ticket','7','','0','Manassrisuksai Sutham (6)','2017-02-06 04:45:25','17','','2017-02-06 04:45:25');
INSERT INTO `glpi_logs` VALUES ('186','Ticket','7','','0','dong (2)','2017-02-06 04:48:49','12','6','1');
INSERT INTO `glpi_logs` VALUES ('187','Ticket','7','','0','dong (2)','2017-02-06 04:48:49','64','sutham (6)','dong (2)');
INSERT INTO `glpi_logs` VALUES ('188','Ticket','7','','0','dong (2)','2017-02-06 04:48:49','17','2017-02-06 04:45:25','NULL');
INSERT INTO `glpi_logs` VALUES ('189','Ticket','7','','0','dong (2)','2017-02-06 04:48:49','16','2017-02-06 04:45:25','NULL');
INSERT INTO `glpi_logs` VALUES ('190','Ticket','7','','0','Manassrisuksai Sutham (6)','2017-02-06 04:49:27','24','','&lt;p&gt;เบื้องต้นดำเนินากร Bypass ให้แขกใช้งานก่อนครับ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('191','Ticket','7','','0','Manassrisuksai Sutham (6)','2017-02-06 04:49:27','64','dong (2)','sutham (6)');
INSERT INTO `glpi_logs` VALUES ('192','Ticket','7','','0','Manassrisuksai Sutham (6)','2017-02-06 04:49:27','12','1','6');
INSERT INTO `glpi_logs` VALUES ('193','Ticket','7','','0','Manassrisuksai Sutham (6)','2017-02-06 04:49:27','16','','2017-02-06 04:49:27');
INSERT INTO `glpi_logs` VALUES ('194','Ticket','7','','0','Manassrisuksai Sutham (6)','2017-02-06 04:49:27','17','','2017-02-06 04:49:27');
INSERT INTO `glpi_logs` VALUES ('195','Ticket','8','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:49:59','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('196','Ticket','8','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:49:59','0','','');
INSERT INTO `glpi_logs` VALUES ('197','Ticket','8','','0','Manassrisuksai Sutham (6)','2017-02-06 04:50:37','24','','&lt;p&gt;ดำเนินการเปลี่ยนให้เรียบร้อยแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('198','Ticket','8','','0','Manassrisuksai Sutham (6)','2017-02-06 04:50:37','12','1','6');
INSERT INTO `glpi_logs` VALUES ('199','Ticket','8','','0','Manassrisuksai Sutham (6)','2017-02-06 04:50:37','16','','2017-02-06 04:50:37');
INSERT INTO `glpi_logs` VALUES ('200','Ticket','8','','0','Manassrisuksai Sutham (6)','2017-02-06 04:50:37','17','','2017-02-06 04:50:37');
INSERT INTO `glpi_logs` VALUES ('201','Ticket','9','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:51:34','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('202','Ticket','9','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:51:34','0','','');
INSERT INTO `glpi_logs` VALUES ('203','Ticket','9','','0','Manassrisuksai Sutham (6)','2017-02-06 04:52:07','24','','&lt;p&gt;เบื้องต้น Bypass ให้แขกใช้งานได้ก่อน&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('204','Ticket','9','','0','Manassrisuksai Sutham (6)','2017-02-06 04:52:07','12','1','6');
INSERT INTO `glpi_logs` VALUES ('205','Ticket','9','','0','Manassrisuksai Sutham (6)','2017-02-06 04:52:07','16','','2017-02-06 04:52:07');
INSERT INTO `glpi_logs` VALUES ('206','Ticket','9','','0','Manassrisuksai Sutham (6)','2017-02-06 04:52:07','17','','2017-02-06 04:52:07');
INSERT INTO `glpi_logs` VALUES ('207','Ticket','10','User','15','Manassrisuksai Sutham (6)','2017-02-06 04:53:34','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('208','Ticket','10','0','20','Manassrisuksai Sutham (6)','2017-02-06 04:53:34','0','','');
INSERT INTO `glpi_logs` VALUES ('209','Ticket','10','','0','Manassrisuksai Sutham (6)','2017-02-06 04:53:55','24','','&lt;p&gt;ลงโปรแกรมใหม่ User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('210','Ticket','10','','0','Manassrisuksai Sutham (6)','2017-02-06 04:53:55','12','1','6');
INSERT INTO `glpi_logs` VALUES ('211','Ticket','10','','0','Manassrisuksai Sutham (6)','2017-02-06 04:53:55','16','','2017-02-06 04:53:55');
INSERT INTO `glpi_logs` VALUES ('212','Ticket','10','','0','Manassrisuksai Sutham (6)','2017-02-06 04:53:55','17','','2017-02-06 04:53:55');
INSERT INTO `glpi_logs` VALUES ('213','Ticket','11','User','15','Manassrisuksai Sutham (6)','2017-02-06 05:10:42','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('214','Ticket','11','0','20','Manassrisuksai Sutham (6)','2017-02-06 05:10:42','0','','');
INSERT INTO `glpi_logs` VALUES ('215','Ticket','11','','0','Manassrisuksai Sutham (6)','2017-02-06 05:11:05','24','','&lt;p&gt;ลงโปรแกรม Fromas ใหม่ใช้งานได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('216','Ticket','11','','0','Manassrisuksai Sutham (6)','2017-02-06 05:11:05','12','1','6');
INSERT INTO `glpi_logs` VALUES ('217','Ticket','11','','0','Manassrisuksai Sutham (6)','2017-02-06 05:11:05','16','','2017-02-06 05:11:05');
INSERT INTO `glpi_logs` VALUES ('218','Ticket','11','','0','Manassrisuksai Sutham (6)','2017-02-06 05:11:05','17','','2017-02-06 05:11:05');
INSERT INTO `glpi_logs` VALUES ('219','Ticket','12','User','15','Manassrisuksai Sutham (6)','2017-02-06 05:12:17','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('220','Ticket','12','0','20','Manassrisuksai Sutham (6)','2017-02-06 05:12:17','0','','');
INSERT INTO `glpi_logs` VALUES ('221','Ticket','12','','0','Manassrisuksai Sutham (6)','2017-02-06 05:13:11','24','','&lt;p&gt;ลงวินโดวใหม่ ใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('222','Ticket','12','','0','Manassrisuksai Sutham (6)','2017-02-06 05:13:11','12','1','6');
INSERT INTO `glpi_logs` VALUES ('223','Ticket','12','','0','Manassrisuksai Sutham (6)','2017-02-06 05:13:11','16','','2017-02-06 05:13:11');
INSERT INTO `glpi_logs` VALUES ('224','Ticket','12','','0','Manassrisuksai Sutham (6)','2017-02-06 05:13:11','17','','2017-02-06 05:13:11');
INSERT INTO `glpi_logs` VALUES ('225','Ticket','13','User','15','Manassrisuksai Sutham (6)','2017-02-06 05:14:14','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('226','Ticket','13','0','20','Manassrisuksai Sutham (6)','2017-02-06 05:14:14','0','','');
INSERT INTO `glpi_logs` VALUES ('227','Ticket','13','','0','Manassrisuksai Sutham (6)','2017-02-06 05:14:56','24','','&lt;p&gt;Path หลุดได้ดำเนินการแก้ไขแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('228','Ticket','13','','0','Manassrisuksai Sutham (6)','2017-02-06 05:14:56','12','1','6');
INSERT INTO `glpi_logs` VALUES ('229','Ticket','13','','0','Manassrisuksai Sutham (6)','2017-02-06 05:14:56','16','','2017-02-06 05:14:56');
INSERT INTO `glpi_logs` VALUES ('230','Ticket','13','','0','Manassrisuksai Sutham (6)','2017-02-06 05:14:56','17','','2017-02-06 05:14:56');
INSERT INTO `glpi_logs` VALUES ('231','Ticket','14','User','15','Manassrisuksai Sutham (6)','2017-02-06 05:16:05','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('232','Ticket','14','0','20','Manassrisuksai Sutham (6)','2017-02-06 05:16:05','0','','');
INSERT INTO `glpi_logs` VALUES ('233','Ticket','14','','0','Manassrisuksai Sutham (6)','2017-02-06 05:16:27','24','','&lt;p&gt;สาย Lan หลวม ดำเนินการแก้ไขแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('234','Ticket','14','','0','Manassrisuksai Sutham (6)','2017-02-06 05:16:27','12','1','6');
INSERT INTO `glpi_logs` VALUES ('235','Ticket','14','','0','Manassrisuksai Sutham (6)','2017-02-06 05:16:27','16','','2017-02-06 05:16:27');
INSERT INTO `glpi_logs` VALUES ('236','Ticket','14','','0','Manassrisuksai Sutham (6)','2017-02-06 05:16:27','17','','2017-02-06 05:16:27');
INSERT INTO `glpi_logs` VALUES ('237','Ticket','15','User','15','Manassrisuksai Sutham (6)','2017-02-06 05:17:24','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('238','Ticket','15','0','20','Manassrisuksai Sutham (6)','2017-02-06 05:17:24','0','','');
INSERT INTO `glpi_logs` VALUES ('239','Ticket','15','','0','Manassrisuksai Sutham (6)','2017-02-06 05:19:02','24','','&lt;p&gt;ลงวินโดวใหม่ใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('240','Ticket','15','','0','Manassrisuksai Sutham (6)','2017-02-06 05:19:02','12','1','6');
INSERT INTO `glpi_logs` VALUES ('241','Ticket','15','','0','Manassrisuksai Sutham (6)','2017-02-06 05:19:02','16','','2017-02-06 05:19:02');
INSERT INTO `glpi_logs` VALUES ('242','Ticket','15','','0','Manassrisuksai Sutham (6)','2017-02-06 05:19:02','17','','2017-02-06 05:19:02');
INSERT INTO `glpi_logs` VALUES ('243','Ticket','16','User','15','Manassrisuksai Sutham (6)','2017-02-06 05:23:50','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('244','Ticket','16','0','20','Manassrisuksai Sutham (6)','2017-02-06 05:23:50','0','','');
INSERT INTO `glpi_logs` VALUES ('245','Ticket','16','','0','Manassrisuksai Sutham (6)','2017-02-06 05:24:12','24','','&lt;p&gt;Reboot Ap ใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('246','Ticket','16','','0','Manassrisuksai Sutham (6)','2017-02-06 05:24:12','12','1','6');
INSERT INTO `glpi_logs` VALUES ('247','Ticket','16','','0','Manassrisuksai Sutham (6)','2017-02-06 05:24:12','16','','2017-02-06 05:24:12');
INSERT INTO `glpi_logs` VALUES ('248','Ticket','16','','0','Manassrisuksai Sutham (6)','2017-02-06 05:24:12','17','','2017-02-06 05:24:12');
INSERT INTO `glpi_logs` VALUES ('249','Ticket','17','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:10:22','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('250','Ticket','17','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:10:22','0','','');
INSERT INTO `glpi_logs` VALUES ('251','Ticket','17','','0','Manassrisuksai Sutham (6)','2017-02-08 01:11:06','24','','&lt;p&gt;แนะนำวิธีการใช้งาน&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('252','Ticket','17','','0','Manassrisuksai Sutham (6)','2017-02-08 01:11:06','12','1','6');
INSERT INTO `glpi_logs` VALUES ('253','Ticket','17','','0','Manassrisuksai Sutham (6)','2017-02-08 01:11:06','16','','2017-02-08 01:11:06');
INSERT INTO `glpi_logs` VALUES ('254','Ticket','17','','0','Manassrisuksai Sutham (6)','2017-02-08 01:11:06','17','','2017-02-08 01:11:06');
INSERT INTO `glpi_logs` VALUES ('255','Ticket','18','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:11:58','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('256','Ticket','18','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:11:58','0','','');
INSERT INTO `glpi_logs` VALUES ('257','Ticket','18','','0','Manassrisuksai Sutham (6)','2017-02-08 01:12:34','24','','&lt;p&gt;ไฟ 220v เสีย&lt;/p&gt;rn&lt;p&gt;แจ้งช่างดำเนินการเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('258','Ticket','18','','0','Manassrisuksai Sutham (6)','2017-02-08 01:12:34','12','1','6');
INSERT INTO `glpi_logs` VALUES ('259','Ticket','18','','0','Manassrisuksai Sutham (6)','2017-02-08 01:12:34','16','','2017-02-08 01:12:34');
INSERT INTO `glpi_logs` VALUES ('260','Ticket','18','','0','Manassrisuksai Sutham (6)','2017-02-08 01:12:34','17','','2017-02-08 01:12:34');
INSERT INTO `glpi_logs` VALUES ('261','Ticket','19','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:13:42','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('262','Ticket','19','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:13:42','0','','');
INSERT INTO `glpi_logs` VALUES ('263','Ticket','19','','0','Manassrisuksai Sutham (6)','2017-02-08 01:14:09','24','','&lt;p&gt;ใส่การ์ด Lan ใหม่ ใช้งานได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('264','Ticket','19','','0','Manassrisuksai Sutham (6)','2017-02-08 01:14:09','12','1','6');
INSERT INTO `glpi_logs` VALUES ('265','Ticket','19','','0','Manassrisuksai Sutham (6)','2017-02-08 01:14:09','16','','2017-02-08 01:14:09');
INSERT INTO `glpi_logs` VALUES ('266','Ticket','19','','0','Manassrisuksai Sutham (6)','2017-02-08 01:14:09','17','','2017-02-08 01:14:09');
INSERT INTO `glpi_logs` VALUES ('267','Ticket','20','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:15:15','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('268','Ticket','20','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:15:15','0','','');
INSERT INTO `glpi_logs` VALUES ('269','Ticket','20','','0','Manassrisuksai Sutham (6)','2017-02-08 01:15:56','24','','&lt;p&gt;ดำเนินการ Bypass &lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('270','Ticket','20','','0','Manassrisuksai Sutham (6)','2017-02-08 01:15:56','12','1','6');
INSERT INTO `glpi_logs` VALUES ('271','Ticket','20','','0','Manassrisuksai Sutham (6)','2017-02-08 01:15:56','16','','2017-02-08 01:15:56');
INSERT INTO `glpi_logs` VALUES ('272','Ticket','20','','0','Manassrisuksai Sutham (6)','2017-02-08 01:15:56','17','','2017-02-08 01:15:56');
INSERT INTO `glpi_logs` VALUES ('275','ITILCategory','24','ITILCategory','17','dong (2)','2017-02-08 01:18:57','0','','Adobe');
INSERT INTO `glpi_logs` VALUES ('276','ITILCategory','74','0','20','dong (2)','2017-02-08 01:18:57','0','','');
INSERT INTO `glpi_logs` VALUES ('277','Ticket','21','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:21:29','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('278','Ticket','21','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:21:29','0','','');
INSERT INTO `glpi_logs` VALUES ('279','Ticket','21','','0','Manassrisuksai Sutham (6)','2017-02-08 01:22:32','24','','&lt;p&gt;ติดตั้งโปรแกรมใหม่&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('280','Ticket','21','','0','Manassrisuksai Sutham (6)','2017-02-08 01:22:32','12','1','6');
INSERT INTO `glpi_logs` VALUES ('281','Ticket','21','','0','Manassrisuksai Sutham (6)','2017-02-08 01:22:32','16','','2017-02-08 01:22:32');
INSERT INTO `glpi_logs` VALUES ('282','Ticket','21','','0','Manassrisuksai Sutham (6)','2017-02-08 01:22:32','17','','2017-02-08 01:22:32');
INSERT INTO `glpi_logs` VALUES ('283','Ticket','22','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:23:29','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('284','Ticket','22','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:23:29','0','','');
INSERT INTO `glpi_logs` VALUES ('285','Ticket','22','','0','Manassrisuksai Sutham (6)','2017-02-08 01:23:47','24','','&lt;p&gt;ลงโปรแกรมใหม่&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('286','Ticket','22','','0','Manassrisuksai Sutham (6)','2017-02-08 01:23:47','12','1','6');
INSERT INTO `glpi_logs` VALUES ('287','Ticket','22','','0','Manassrisuksai Sutham (6)','2017-02-08 01:23:47','16','','2017-02-08 01:23:47');
INSERT INTO `glpi_logs` VALUES ('288','Ticket','22','','0','Manassrisuksai Sutham (6)','2017-02-08 01:23:47','17','','2017-02-08 01:23:47');
INSERT INTO `glpi_logs` VALUES ('289','Ticket','23','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:25:00','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('290','Ticket','23','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:25:00','0','','');
INSERT INTO `glpi_logs` VALUES ('291','Ticket','23','','0','Manassrisuksai Sutham (6)','2017-02-08 01:25:18','24','','&lt;p&gt;สายไฟหลวม&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('292','Ticket','23','','0','Manassrisuksai Sutham (6)','2017-02-08 01:25:18','12','1','6');
INSERT INTO `glpi_logs` VALUES ('293','Ticket','23','','0','Manassrisuksai Sutham (6)','2017-02-08 01:25:18','16','','2017-02-08 01:25:18');
INSERT INTO `glpi_logs` VALUES ('294','Ticket','23','','0','Manassrisuksai Sutham (6)','2017-02-08 01:25:18','17','','2017-02-08 01:25:18');
INSERT INTO `glpi_logs` VALUES ('295','Ticket','24','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:26:18','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('296','Ticket','24','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:26:18','0','','');
INSERT INTO `glpi_logs` VALUES ('297','Ticket','24','','0','Manassrisuksai Sutham (6)','2017-02-08 01:26:46','24','','&lt;p&gt;เบื้องต้นได้อัพเดทโปรแกรมใหม่แล้วแต่ยังคงเกิดปัญหา&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('298','Ticket','24','','0','Manassrisuksai Sutham (6)','2017-02-08 01:26:46','12','1','6');
INSERT INTO `glpi_logs` VALUES ('299','Ticket','24','','0','Manassrisuksai Sutham (6)','2017-02-08 01:26:46','16','','2017-02-08 01:26:46');
INSERT INTO `glpi_logs` VALUES ('300','Ticket','24','','0','Manassrisuksai Sutham (6)','2017-02-08 01:26:46','17','','2017-02-08 01:26:46');
INSERT INTO `glpi_logs` VALUES ('301','Ticket','25','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:27:42','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('302','Ticket','25','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:27:42','0','','');
INSERT INTO `glpi_logs` VALUES ('303','Ticket','25','','0','Manassrisuksai Sutham (6)','2017-02-08 01:28:04','24','','&lt;p&gt;REBOOT DVR ใหม่ สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('304','Ticket','25','','0','Manassrisuksai Sutham (6)','2017-02-08 01:28:04','12','1','6');
INSERT INTO `glpi_logs` VALUES ('305','Ticket','25','','0','Manassrisuksai Sutham (6)','2017-02-08 01:28:04','16','','2017-02-08 01:28:04');
INSERT INTO `glpi_logs` VALUES ('306','Ticket','25','','0','Manassrisuksai Sutham (6)','2017-02-08 01:28:04','17','','2017-02-08 01:28:04');
INSERT INTO `glpi_logs` VALUES ('307','ITILCategory','75','0','20','dong (2)','2017-02-08 01:29:12','0','','');
INSERT INTO `glpi_logs` VALUES ('308','Ticket','26','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:30:36','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('309','Ticket','26','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:30:36','0','','');
INSERT INTO `glpi_logs` VALUES ('310','Ticket','26','','0','Manassrisuksai Sutham (6)','2017-02-08 01:30:52','24','','&lt;p&gt;สอนวิธีการใช้งาน&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;rn&lt;p&gt; &lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('311','Ticket','26','','0','Manassrisuksai Sutham (6)','2017-02-08 01:30:52','12','1','6');
INSERT INTO `glpi_logs` VALUES ('312','Ticket','26','','0','Manassrisuksai Sutham (6)','2017-02-08 01:30:52','16','','2017-02-08 01:30:52');
INSERT INTO `glpi_logs` VALUES ('313','Ticket','26','','0','Manassrisuksai Sutham (6)','2017-02-08 01:30:52','17','','2017-02-08 01:30:52');
INSERT INTO `glpi_logs` VALUES ('314','Ticket','27','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:31:27','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('315','Ticket','27','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:31:27','0','','');
INSERT INTO `glpi_logs` VALUES ('316','Ticket','27','','0','Manassrisuksai Sutham (6)','2017-02-08 01:31:52','24','','&lt;p&gt;ดำเนินการติดตั้งให้เรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;rn&lt;p&gt; &lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('317','Ticket','27','','0','Manassrisuksai Sutham (6)','2017-02-08 01:31:52','12','1','6');
INSERT INTO `glpi_logs` VALUES ('318','Ticket','27','','0','Manassrisuksai Sutham (6)','2017-02-08 01:31:52','16','','2017-02-08 01:31:52');
INSERT INTO `glpi_logs` VALUES ('319','Ticket','27','','0','Manassrisuksai Sutham (6)','2017-02-08 01:31:52','17','','2017-02-08 01:31:52');
INSERT INTO `glpi_logs` VALUES ('320','Ticket','28','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:33:32','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('321','Ticket','28','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:33:32','0','','');
INSERT INTO `glpi_logs` VALUES ('322','Ticket','28','','0','Manassrisuksai Sutham (6)','2017-02-08 01:33:55','24','','&lt;p&gt;เปลี่ยน Keyboard ใหม่&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('323','Ticket','28','','0','Manassrisuksai Sutham (6)','2017-02-08 01:33:55','12','1','6');
INSERT INTO `glpi_logs` VALUES ('324','Ticket','28','','0','Manassrisuksai Sutham (6)','2017-02-08 01:33:55','16','','2017-02-08 01:33:55');
INSERT INTO `glpi_logs` VALUES ('325','Ticket','28','','0','Manassrisuksai Sutham (6)','2017-02-08 01:33:55','17','','2017-02-08 01:33:55');
INSERT INTO `glpi_logs` VALUES ('326','Ticket','29','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:35:04','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('327','Ticket','29','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:35:04','0','','');
INSERT INTO `glpi_logs` VALUES ('328','Ticket','29','','0','Manassrisuksai Sutham (6)','2017-02-08 01:35:33','24','','&lt;p&gt;เปลั้ยน Lan Card ใหม่&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('329','Ticket','29','','0','Manassrisuksai Sutham (6)','2017-02-08 01:35:33','12','1','6');
INSERT INTO `glpi_logs` VALUES ('330','Ticket','29','','0','Manassrisuksai Sutham (6)','2017-02-08 01:35:33','16','','2017-02-08 01:35:33');
INSERT INTO `glpi_logs` VALUES ('331','Ticket','29','','0','Manassrisuksai Sutham (6)','2017-02-08 01:35:33','17','','2017-02-08 01:35:33');
INSERT INTO `glpi_logs` VALUES ('332','Ticket','30','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:36:29','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('333','Ticket','30','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:36:29','0','','');
INSERT INTO `glpi_logs` VALUES ('334','Ticket','30','','0','Manassrisuksai Sutham (6)','2017-02-08 01:36:49','24','','&lt;p&gt;ลงโปรแกรมใหม่ใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('335','Ticket','30','','0','Manassrisuksai Sutham (6)','2017-02-08 01:36:49','12','1','6');
INSERT INTO `glpi_logs` VALUES ('336','Ticket','30','','0','Manassrisuksai Sutham (6)','2017-02-08 01:36:49','16','','2017-02-08 01:36:49');
INSERT INTO `glpi_logs` VALUES ('337','Ticket','30','','0','Manassrisuksai Sutham (6)','2017-02-08 01:36:49','17','','2017-02-08 01:36:49');
INSERT INTO `glpi_logs` VALUES ('338','Ticket','31','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:37:49','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('339','Ticket','31','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:37:49','0','','');
INSERT INTO `glpi_logs` VALUES ('340','Ticket','31','','0','Manassrisuksai Sutham (6)','2017-02-08 01:38:29','24','','&lt;p&gt;ลงโปรแกรม Fromas ใหม่&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('341','Ticket','31','','0','Manassrisuksai Sutham (6)','2017-02-08 01:38:29','12','1','6');
INSERT INTO `glpi_logs` VALUES ('342','Ticket','31','','0','Manassrisuksai Sutham (6)','2017-02-08 01:38:29','16','','2017-02-08 01:38:29');
INSERT INTO `glpi_logs` VALUES ('343','Ticket','31','','0','Manassrisuksai Sutham (6)','2017-02-08 01:38:29','17','','2017-02-08 01:38:29');
INSERT INTO `glpi_logs` VALUES ('344','Ticket','32','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:39:44','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('345','Ticket','32','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:39:44','0','','');
INSERT INTO `glpi_logs` VALUES ('346','Ticket','32','','0','Manassrisuksai Sutham (6)','2017-02-08 01:40:27','24','','&lt;p&gt;ดำเนินการ Bypass ให้แกแล้วแต่ยังคงไม่สามารถใช้งานได้&lt;/p&gt;rn&lt;p&gt; OS  Macbook เสียต้องส่งศูนย์&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('347','Ticket','32','','0','Manassrisuksai Sutham (6)','2017-02-08 01:40:27','12','1','6');
INSERT INTO `glpi_logs` VALUES ('348','Ticket','32','','0','Manassrisuksai Sutham (6)','2017-02-08 01:40:27','16','','2017-02-08 01:40:27');
INSERT INTO `glpi_logs` VALUES ('349','Ticket','32','','0','Manassrisuksai Sutham (6)','2017-02-08 01:40:27','17','','2017-02-08 01:40:27');
INSERT INTO `glpi_logs` VALUES ('350','Ticket','33','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:41:10','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('351','Ticket','33','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:41:10','0','','');
INSERT INTO `glpi_logs` VALUES ('352','Ticket','33','','0','Manassrisuksai Sutham (6)','2017-02-08 01:41:33','24','','&lt;p&gt;ส่งเติมหมึกแล้ว&lt;/p&gt;rn&lt;p&gt;ดำเนินการการนำมาติดตั้งให้แล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('353','Ticket','33','','0','Manassrisuksai Sutham (6)','2017-02-08 01:41:33','12','1','6');
INSERT INTO `glpi_logs` VALUES ('354','Ticket','33','','0','Manassrisuksai Sutham (6)','2017-02-08 01:41:33','16','','2017-02-08 01:41:33');
INSERT INTO `glpi_logs` VALUES ('355','Ticket','33','','0','Manassrisuksai Sutham (6)','2017-02-08 01:41:33','17','','2017-02-08 01:41:33');
INSERT INTO `glpi_logs` VALUES ('356','Ticket','34','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:42:20','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('357','Ticket','34','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:42:20','0','','');
INSERT INTO `glpi_logs` VALUES ('358','Ticket','34','','0','Manassrisuksai Sutham (6)','2017-02-08 01:42:44','24','','&lt;p&gt;ทางนิวซอฟเข้ามาดำเนินการอัพเดทโปรแกรมใหม่&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('359','Ticket','34','','0','Manassrisuksai Sutham (6)','2017-02-08 01:42:44','12','1','6');
INSERT INTO `glpi_logs` VALUES ('360','Ticket','34','','0','Manassrisuksai Sutham (6)','2017-02-08 01:42:44','16','','2017-02-08 01:42:44');
INSERT INTO `glpi_logs` VALUES ('361','Ticket','34','','0','Manassrisuksai Sutham (6)','2017-02-08 01:42:44','17','','2017-02-08 01:42:44');
INSERT INTO `glpi_logs` VALUES ('362','Ticket','35','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:43:56','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('363','Ticket','35','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:43:56','0','','');
INSERT INTO `glpi_logs` VALUES ('364','Ticket','35','','0','Manassrisuksai Sutham (6)','2017-02-08 01:44:33','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้วครับ&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('365','Ticket','35','','0','Manassrisuksai Sutham (6)','2017-02-08 01:44:33','12','1','6');
INSERT INTO `glpi_logs` VALUES ('366','Ticket','35','','0','Manassrisuksai Sutham (6)','2017-02-08 01:44:33','16','','2017-02-08 01:44:33');
INSERT INTO `glpi_logs` VALUES ('367','Ticket','35','','0','Manassrisuksai Sutham (6)','2017-02-08 01:44:33','17','','2017-02-08 01:44:33');
INSERT INTO `glpi_logs` VALUES ('368','Ticket','36','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:45:10','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('369','Ticket','36','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:45:10','0','','');
INSERT INTO `glpi_logs` VALUES ('370','Ticket','36','','0','Manassrisuksai Sutham (6)','2017-02-08 01:46:08','24','','&lt;p&gt;ดำเนินการตรวจสอบแล้ว&lt;/p&gt;rn&lt;p&gt;สามารถดูออนไลน์ได้ปกติแต่ CHANNEL บางจุดยังมีปัญหา&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('371','Ticket','36','','0','Manassrisuksai Sutham (6)','2017-02-08 01:46:08','12','1','6');
INSERT INTO `glpi_logs` VALUES ('372','Ticket','36','','0','Manassrisuksai Sutham (6)','2017-02-08 01:46:08','16','','2017-02-08 01:46:08');
INSERT INTO `glpi_logs` VALUES ('373','Ticket','36','','0','Manassrisuksai Sutham (6)','2017-02-08 01:46:08','17','','2017-02-08 01:46:08');
INSERT INTO `glpi_logs` VALUES ('374','Ticket','37','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:50:39','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('375','Ticket','37','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:50:39','0','','');
INSERT INTO `glpi_logs` VALUES ('376','Ticket','37','','0','Manassrisuksai Sutham (6)','2017-02-08 01:51:43','24','','&lt;p&gt;setup already&lt;/p&gt;rn&lt;p&gt;user available.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('377','Ticket','37','','0','Manassrisuksai Sutham (6)','2017-02-08 01:51:43','12','1','6');
INSERT INTO `glpi_logs` VALUES ('378','Ticket','37','','0','Manassrisuksai Sutham (6)','2017-02-08 01:51:43','16','','2017-02-08 01:51:43');
INSERT INTO `glpi_logs` VALUES ('379','Ticket','37','','0','Manassrisuksai Sutham (6)','2017-02-08 01:51:43','17','','2017-02-08 01:51:43');
INSERT INTO `glpi_logs` VALUES ('380','Ticket','38','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:52:23','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('381','Ticket','38','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:52:23','0','','');
INSERT INTO `glpi_logs` VALUES ('382','Ticket','38','','0','Manassrisuksai Sutham (6)','2017-02-08 01:52:39','24','','&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('383','Ticket','38','','0','Manassrisuksai Sutham (6)','2017-02-08 01:52:39','12','1','6');
INSERT INTO `glpi_logs` VALUES ('384','Ticket','38','','0','Manassrisuksai Sutham (6)','2017-02-08 01:52:39','16','','2017-02-08 01:52:39');
INSERT INTO `glpi_logs` VALUES ('385','Ticket','38','','0','Manassrisuksai Sutham (6)','2017-02-08 01:52:39','17','','2017-02-08 01:52:39');
INSERT INTO `glpi_logs` VALUES ('386','Ticket','39','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:53:22','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('387','Ticket','39','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:53:22','0','','');
INSERT INTO `glpi_logs` VALUES ('388','Ticket','39','','0','Manassrisuksai Sutham (6)','2017-02-08 01:53:41','24','','&lt;p&gt;REBOOT DVR136&lt;/p&gt;rn&lt;p&gt;สามารถดูได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('389','Ticket','39','','0','Manassrisuksai Sutham (6)','2017-02-08 01:53:41','12','1','6');
INSERT INTO `glpi_logs` VALUES ('390','Ticket','39','','0','Manassrisuksai Sutham (6)','2017-02-08 01:53:41','16','','2017-02-08 01:53:41');
INSERT INTO `glpi_logs` VALUES ('391','Ticket','39','','0','Manassrisuksai Sutham (6)','2017-02-08 01:53:41','17','','2017-02-08 01:53:41');
INSERT INTO `glpi_logs` VALUES ('392','Ticket','40','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:54:26','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('393','Ticket','40','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:54:26','0','','');
INSERT INTO `glpi_logs` VALUES ('394','Ticket','40','','0','Manassrisuksai Sutham (6)','2017-02-08 01:54:55','24','','&lt;p&gt;Bypass iphone Guest&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('395','Ticket','40','','0','Manassrisuksai Sutham (6)','2017-02-08 01:54:55','12','1','6');
INSERT INTO `glpi_logs` VALUES ('396','Ticket','40','','0','Manassrisuksai Sutham (6)','2017-02-08 01:54:55','16','','2017-02-08 01:54:55');
INSERT INTO `glpi_logs` VALUES ('397','Ticket','40','','0','Manassrisuksai Sutham (6)','2017-02-08 01:54:55','17','','2017-02-08 01:54:55');
INSERT INTO `glpi_logs` VALUES ('398','Ticket','41','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:56:26','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('399','Ticket','41','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:56:26','0','','');
INSERT INTO `glpi_logs` VALUES ('400','Ticket','41','','0','Manassrisuksai Sutham (6)','2017-02-08 01:56:51','24','','&lt;p&gt;Bypass TV APPLE Already.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('401','Ticket','41','','0','Manassrisuksai Sutham (6)','2017-02-08 01:56:51','12','1','6');
INSERT INTO `glpi_logs` VALUES ('402','Ticket','41','','0','Manassrisuksai Sutham (6)','2017-02-08 01:56:51','16','','2017-02-08 01:56:51');
INSERT INTO `glpi_logs` VALUES ('403','Ticket','41','','0','Manassrisuksai Sutham (6)','2017-02-08 01:56:51','17','','2017-02-08 01:56:51');
INSERT INTO `glpi_logs` VALUES ('404','Ticket','42','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:57:48','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('405','Ticket','42','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:57:48','0','','');
INSERT INTO `glpi_logs` VALUES ('406','Ticket','42','','0','Manassrisuksai Sutham (6)','2017-02-08 01:58:04','24','','&lt;p&gt;Bypass iphone Guest&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('407','Ticket','42','','0','Manassrisuksai Sutham (6)','2017-02-08 01:58:04','12','1','6');
INSERT INTO `glpi_logs` VALUES ('408','Ticket','42','','0','Manassrisuksai Sutham (6)','2017-02-08 01:58:04','16','','2017-02-08 01:58:04');
INSERT INTO `glpi_logs` VALUES ('409','Ticket','42','','0','Manassrisuksai Sutham (6)','2017-02-08 01:58:04','17','','2017-02-08 01:58:04');
INSERT INTO `glpi_logs` VALUES ('410','Ticket','43','User','15','Manassrisuksai Sutham (6)','2017-02-08 01:59:18','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('411','Ticket','43','0','20','Manassrisuksai Sutham (6)','2017-02-08 01:59:18','0','','');
INSERT INTO `glpi_logs` VALUES ('412','Ticket','43','','0','Manassrisuksai Sutham (6)','2017-02-08 02:00:05','24','','&lt;p&gt;Mikrotik มีปัญหาให้ทางคุณแจ็ค AMATI restore ค่าคอนฟิกไปวันที่12 ช่วงที่พี่ตุ้งลงมาติดตั้ง&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('413','Ticket','43','','0','Manassrisuksai Sutham (6)','2017-02-08 02:00:05','12','1','6');
INSERT INTO `glpi_logs` VALUES ('414','Ticket','43','','0','Manassrisuksai Sutham (6)','2017-02-08 02:00:05','16','','2017-02-08 02:00:05');
INSERT INTO `glpi_logs` VALUES ('415','Ticket','43','','0','Manassrisuksai Sutham (6)','2017-02-08 02:00:05','17','','2017-02-08 02:00:05');
INSERT INTO `glpi_logs` VALUES ('416','Ticket','44','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:00:59','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('417','Ticket','44','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:00:59','0','','');
INSERT INTO `glpi_logs` VALUES ('418','Ticket','44','','0','Manassrisuksai Sutham (6)','2017-02-08 02:01:51','24','','&lt;p&gt;restore format factory Default DVR&lt;/p&gt;rn&lt;p&gt;ทำการเซ็ตค่าใหม่ยังไม่หาย&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('419','Ticket','44','','0','Manassrisuksai Sutham (6)','2017-02-08 02:01:51','12','1','6');
INSERT INTO `glpi_logs` VALUES ('420','Ticket','44','','0','Manassrisuksai Sutham (6)','2017-02-08 02:01:51','16','','2017-02-08 02:01:51');
INSERT INTO `glpi_logs` VALUES ('421','Ticket','44','','0','Manassrisuksai Sutham (6)','2017-02-08 02:01:51','17','','2017-02-08 02:01:51');
INSERT INTO `glpi_logs` VALUES ('422','Ticket','45','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:02:43','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('423','Ticket','45','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:02:43','0','','');
INSERT INTO `glpi_logs` VALUES ('424','Ticket','45','','0','Manassrisuksai Sutham (6)','2017-02-08 02:03:18','24','','&lt;p&gt;Mikrotik มีปัญหาให้ทางพี่แจ็ค Amati restore ไปวันที่12&lt;/p&gt;rn&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('425','Ticket','45','','0','Manassrisuksai Sutham (6)','2017-02-08 02:03:18','12','1','6');
INSERT INTO `glpi_logs` VALUES ('426','Ticket','45','','0','Manassrisuksai Sutham (6)','2017-02-08 02:03:18','16','','2017-02-08 02:03:18');
INSERT INTO `glpi_logs` VALUES ('427','Ticket','45','','0','Manassrisuksai Sutham (6)','2017-02-08 02:03:18','17','','2017-02-08 02:03:18');
INSERT INTO `glpi_logs` VALUES ('428','Ticket','46','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:03:55','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('429','Ticket','46','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:03:55','0','','');
INSERT INTO `glpi_logs` VALUES ('430','Ticket','46','','0','Manassrisuksai Sutham (6)','2017-02-08 02:04:19','24','','&lt;p&gt;Mikrotik มีปัญหาต้องให้ทางพี่แจ็ค Amati resort เป้นวันที่ 12&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('431','Ticket','46','','0','Manassrisuksai Sutham (6)','2017-02-08 02:04:19','12','1','6');
INSERT INTO `glpi_logs` VALUES ('432','Ticket','46','','0','Manassrisuksai Sutham (6)','2017-02-08 02:04:19','16','','2017-02-08 02:04:19');
INSERT INTO `glpi_logs` VALUES ('433','Ticket','46','','0','Manassrisuksai Sutham (6)','2017-02-08 02:04:19','17','','2017-02-08 02:04:19');
INSERT INTO `glpi_logs` VALUES ('434','Ticket','47','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:05:31','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('435','Ticket','47','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:05:31','0','','');
INSERT INTO `glpi_logs` VALUES ('436','Ticket','47','','0','Manassrisuksai Sutham (6)','2017-02-08 02:07:19','24','','&lt;p&gt;Mikrotik ค่า Config มีปัญหา ส่งผลให้ wifi ทั้งระบบล่ม &lt;/p&gt;rn&lt;p&gt;ซึ่งวันที่12 ได้ทำการ Backup ค่า Config ของทาง NEWSOFT ไว้ จึงสามารถแก้ไขปัญหาดังกล่าวได้ให้สามา');
INSERT INTO `glpi_logs` VALUES ('437','Ticket','47','','0','Manassrisuksai Sutham (6)','2017-02-08 02:07:19','12','1','6');
INSERT INTO `glpi_logs` VALUES ('438','Ticket','47','','0','Manassrisuksai Sutham (6)','2017-02-08 02:07:19','16','','2017-02-08 02:07:19');
INSERT INTO `glpi_logs` VALUES ('439','Ticket','47','','0','Manassrisuksai Sutham (6)','2017-02-08 02:07:19','17','','2017-02-08 02:07:19');
INSERT INTO `glpi_logs` VALUES ('440','Ticket','48','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:08:23','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('441','Ticket','48','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:08:23','0','','');
INSERT INTO `glpi_logs` VALUES ('442','Ticket','48','','0','Manassrisuksai Sutham (6)','2017-02-08 02:08:49','24','','&lt;p&gt;Restore Mikrotik&lt;/p&gt;rn&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('443','Ticket','48','','0','Manassrisuksai Sutham (6)','2017-02-08 02:08:49','12','1','6');
INSERT INTO `glpi_logs` VALUES ('444','Ticket','48','','0','Manassrisuksai Sutham (6)','2017-02-08 02:08:49','16','','2017-02-08 02:08:49');
INSERT INTO `glpi_logs` VALUES ('445','Ticket','48','','0','Manassrisuksai Sutham (6)','2017-02-08 02:08:49','17','','2017-02-08 02:08:49');
INSERT INTO `glpi_logs` VALUES ('446','Ticket','49','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:21:52','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('447','Ticket','49','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:21:52','0','','');
INSERT INTO `glpi_logs` VALUES ('448','Ticket','49','','0','Manassrisuksai Sutham (6)','2017-02-08 02:22:07','24','','&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('449','Ticket','49','','0','Manassrisuksai Sutham (6)','2017-02-08 02:22:07','12','1','6');
INSERT INTO `glpi_logs` VALUES ('450','Ticket','49','','0','Manassrisuksai Sutham (6)','2017-02-08 02:22:07','16','','2017-02-08 02:22:07');
INSERT INTO `glpi_logs` VALUES ('451','Ticket','49','','0','Manassrisuksai Sutham (6)','2017-02-08 02:22:07','17','','2017-02-08 02:22:07');
INSERT INTO `glpi_logs` VALUES ('452','Ticket','50','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:22:40','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('453','Ticket','50','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:22:40','0','','');
INSERT INTO `glpi_logs` VALUES ('454','Ticket','50','','0','Manassrisuksai Sutham (6)','2017-02-08 02:23:20','24','','&lt;p&gt;เปลี่ยน DVR126 เพื่อนทดสอบ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('455','Ticket','50','','0','Manassrisuksai Sutham (6)','2017-02-08 02:23:20','12','1','6');
INSERT INTO `glpi_logs` VALUES ('456','Ticket','50','','0','Manassrisuksai Sutham (6)','2017-02-08 02:23:20','16','','2017-02-08 02:23:20');
INSERT INTO `glpi_logs` VALUES ('457','Ticket','50','','0','Manassrisuksai Sutham (6)','2017-02-08 02:23:20','17','','2017-02-08 02:23:20');
INSERT INTO `glpi_logs` VALUES ('458','Ticket','51','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:24:09','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('459','Ticket','51','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:24:09','0','','');
INSERT INTO `glpi_logs` VALUES ('460','Ticket','51','','0','Manassrisuksai Sutham (6)','2017-02-08 02:24:29','24','','&lt;p&gt;ดำเนินการ Join Domain แล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('461','Ticket','51','','0','Manassrisuksai Sutham (6)','2017-02-08 02:24:29','12','1','6');
INSERT INTO `glpi_logs` VALUES ('462','Ticket','51','','0','Manassrisuksai Sutham (6)','2017-02-08 02:24:29','16','','2017-02-08 02:24:29');
INSERT INTO `glpi_logs` VALUES ('463','Ticket','51','','0','Manassrisuksai Sutham (6)','2017-02-08 02:24:29','17','','2017-02-08 02:24:29');
INSERT INTO `glpi_logs` VALUES ('464','Ticket','52','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:25:25','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('465','Ticket','52','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:25:25','0','','');
INSERT INTO `glpi_logs` VALUES ('466','Ticket','52','','0','Manassrisuksai Sutham (6)','2017-02-08 02:25:54','24','','&lt;p&gt;เปลี่ยน ใบมีดแล้วใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('467','Ticket','52','','0','Manassrisuksai Sutham (6)','2017-02-08 02:25:54','12','1','6');
INSERT INTO `glpi_logs` VALUES ('468','Ticket','52','','0','Manassrisuksai Sutham (6)','2017-02-08 02:25:54','16','','2017-02-08 02:25:54');
INSERT INTO `glpi_logs` VALUES ('469','Ticket','52','','0','Manassrisuksai Sutham (6)','2017-02-08 02:25:54','17','','2017-02-08 02:25:54');
INSERT INTO `glpi_logs` VALUES ('470','Ticket','53','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:26:43','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('471','Ticket','53','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:26:43','0','','');
INSERT INTO `glpi_logs` VALUES ('472','Ticket','53','','0','Manassrisuksai Sutham (6)','2017-02-08 02:27:17','24','','&lt;p&gt;Bypass smart phone&lt;/p&gt;rn&lt;p&gt;Guest available.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('473','Ticket','53','','0','Manassrisuksai Sutham (6)','2017-02-08 02:27:17','12','1','6');
INSERT INTO `glpi_logs` VALUES ('474','Ticket','53','','0','Manassrisuksai Sutham (6)','2017-02-08 02:27:17','16','','2017-02-08 02:27:17');
INSERT INTO `glpi_logs` VALUES ('475','Ticket','53','','0','Manassrisuksai Sutham (6)','2017-02-08 02:27:17','17','','2017-02-08 02:27:17');
INSERT INTO `glpi_logs` VALUES ('476','Ticket','54','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:28:06','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('477','Ticket','54','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:28:06','0','','');
INSERT INTO `glpi_logs` VALUES ('478','Ticket','54','','0','Manassrisuksai Sutham (6)','2017-02-08 02:28:45','24','','&lt;p&gt;ได้ปรึกษากับทางพี่เอสและแจ้งทาง Newsoft ให้แก้ไขแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('479','Ticket','54','','0','Manassrisuksai Sutham (6)','2017-02-08 02:28:45','12','1','6');
INSERT INTO `glpi_logs` VALUES ('480','Ticket','54','','0','Manassrisuksai Sutham (6)','2017-02-08 02:28:45','16','','2017-02-08 02:28:45');
INSERT INTO `glpi_logs` VALUES ('481','Ticket','54','','0','Manassrisuksai Sutham (6)','2017-02-08 02:28:45','17','','2017-02-08 02:28:45');
INSERT INTO `glpi_logs` VALUES ('482','Ticket','55','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:30:28','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('483','Ticket','55','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:30:28','0','','');
INSERT INTO `glpi_logs` VALUES ('484','Ticket','55','','0','Manassrisuksai Sutham (6)','2017-02-08 02:31:08','24','','&lt;p&gt;GROUP ที่ระบบสร้างเป็น signup&lt;/p&gt;rn&lt;p&gt;ย้ายกลุ่มใหม่เป็น Free ก็ยังไม่ได้&lt;/p&gt;rn&lt;p&gt;ลบ Account และสร้างใหม่ใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('485','Ticket','55','','0','Manassrisuksai Sutham (6)','2017-02-08 02:31:08','12','1','6');
INSERT INTO `glpi_logs` VALUES ('486','Ticket','55','','0','Manassrisuksai Sutham (6)','2017-02-08 02:31:08','16','','2017-02-08 02:31:08');
INSERT INTO `glpi_logs` VALUES ('487','Ticket','55','','0','Manassrisuksai Sutham (6)','2017-02-08 02:31:08','17','','2017-02-08 02:31:08');
INSERT INTO `glpi_logs` VALUES ('488','Ticket','56','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:31:58','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('489','Ticket','56','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:31:58','0','','');
INSERT INTO `glpi_logs` VALUES ('490','Ticket','56','','0','Manassrisuksai Sutham (6)','2017-02-08 02:32:38','24','','&lt;p&gt;แจ้งคุณ Art ให้ลงทะเบียนให้ใหม่ ใช้ระยะเวลา10นาที&lt;/p&gt;rn&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('491','Ticket','56','','0','Manassrisuksai Sutham (6)','2017-02-08 02:32:38','12','1','6');
INSERT INTO `glpi_logs` VALUES ('492','Ticket','56','','0','Manassrisuksai Sutham (6)','2017-02-08 02:32:38','16','','2017-02-08 02:32:38');
INSERT INTO `glpi_logs` VALUES ('493','Ticket','56','','0','Manassrisuksai Sutham (6)','2017-02-08 02:32:38','17','','2017-02-08 02:32:38');
INSERT INTO `glpi_logs` VALUES ('494','Ticket','57','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:33:22','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('495','Ticket','57','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:33:22','0','','');
INSERT INTO `glpi_logs` VALUES ('496','Ticket','57','','0','Manassrisuksai Sutham (6)','2017-02-08 02:33:42','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('497','Ticket','57','','0','Manassrisuksai Sutham (6)','2017-02-08 02:33:42','12','1','6');
INSERT INTO `glpi_logs` VALUES ('498','Ticket','57','','0','Manassrisuksai Sutham (6)','2017-02-08 02:33:42','16','','2017-02-08 02:33:42');
INSERT INTO `glpi_logs` VALUES ('499','Ticket','57','','0','Manassrisuksai Sutham (6)','2017-02-08 02:33:42','17','','2017-02-08 02:33:42');
INSERT INTO `glpi_logs` VALUES ('500','Ticket','58','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:34:45','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('501','Ticket','58','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:34:45','0','','');
INSERT INTO `glpi_logs` VALUES ('502','Ticket','58','','0','Manassrisuksai Sutham (6)','2017-02-08 02:35:18','24','','&lt;p&gt;ดำเนินการติดตั้ง bytemailware&lt;/p&gt;rn&lt;p&gt;ทำการสแกนเรียบร้อยแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('503','Ticket','58','','0','Manassrisuksai Sutham (6)','2017-02-08 02:35:18','12','1','6');
INSERT INTO `glpi_logs` VALUES ('504','Ticket','58','','0','Manassrisuksai Sutham (6)','2017-02-08 02:35:18','16','','2017-02-08 02:35:18');
INSERT INTO `glpi_logs` VALUES ('505','Ticket','58','','0','Manassrisuksai Sutham (6)','2017-02-08 02:35:18','17','','2017-02-08 02:35:18');
INSERT INTO `glpi_logs` VALUES ('506','Ticket','59','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:36:07','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('507','Ticket','59','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:36:07','0','','');
INSERT INTO `glpi_logs` VALUES ('508','Ticket','59','','0','Manassrisuksai Sutham (6)','2017-02-08 02:36:48','24','','&lt;p&gt;OS IPHONE แขกมีปัญหา Connect ไม่ได้&lt;/p&gt;rn&lt;p&gt;ต้องลองหลายรอบกว่าจะสามารถใช้งานได้&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('509','Ticket','59','','0','Manassrisuksai Sutham (6)','2017-02-08 02:36:48','12','1','6');
INSERT INTO `glpi_logs` VALUES ('510','Ticket','59','','0','Manassrisuksai Sutham (6)','2017-02-08 02:36:48','16','','2017-02-08 02:36:48');
INSERT INTO `glpi_logs` VALUES ('511','Ticket','59','','0','Manassrisuksai Sutham (6)','2017-02-08 02:36:48','17','','2017-02-08 02:36:48');
INSERT INTO `glpi_logs` VALUES ('512','Ticket','60','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:37:21','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('513','Ticket','60','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:37:21','0','','');
INSERT INTO `glpi_logs` VALUES ('514','Ticket','60','','0','Manassrisuksai Sutham (6)','2017-02-08 02:37:46','24','','&lt;p&gt;ดำเนินการเปลี่ยน HDD ใหม่แล้ว&lt;/p&gt;rn&lt;p&gt;รอผลการทดสอบ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('515','Ticket','60','','0','Manassrisuksai Sutham (6)','2017-02-08 02:37:46','12','1','6');
INSERT INTO `glpi_logs` VALUES ('516','Ticket','60','','0','Manassrisuksai Sutham (6)','2017-02-08 02:37:46','16','','2017-02-08 02:37:46');
INSERT INTO `glpi_logs` VALUES ('517','Ticket','60','','0','Manassrisuksai Sutham (6)','2017-02-08 02:37:46','17','','2017-02-08 02:37:46');
INSERT INTO `glpi_logs` VALUES ('518','Ticket','61','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:38:28','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('519','Ticket','61','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:38:28','0','','');
INSERT INTO `glpi_logs` VALUES ('520','Ticket','61','','0','Manassrisuksai Sutham (6)','2017-02-08 02:38:44','24','','&lt;p&gt;ดำเนินการตรวจเช็คแล้วสามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('521','Ticket','61','','0','Manassrisuksai Sutham (6)','2017-02-08 02:38:44','12','1','6');
INSERT INTO `glpi_logs` VALUES ('522','Ticket','61','','0','Manassrisuksai Sutham (6)','2017-02-08 02:38:44','16','','2017-02-08 02:38:44');
INSERT INTO `glpi_logs` VALUES ('523','Ticket','61','','0','Manassrisuksai Sutham (6)','2017-02-08 02:38:44','17','','2017-02-08 02:38:44');
INSERT INTO `glpi_logs` VALUES ('524','Ticket','62','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:39:14','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('525','Ticket','62','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:39:14','0','','');
INSERT INTO `glpi_logs` VALUES ('526','Ticket','62','','0','Manassrisuksai Sutham (6)','2017-02-08 02:39:36','24','','&lt;p&gt;รอดำเนินการเปลี่ยนเครื่องใหม่ &lt;/p&gt;rn&lt;p&gt;เบื้องต้นสลับใบมีดใช้งานไปก่อน&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('527','Ticket','62','','0','Manassrisuksai Sutham (6)','2017-02-08 02:39:36','12','1','6');
INSERT INTO `glpi_logs` VALUES ('528','Ticket','62','','0','Manassrisuksai Sutham (6)','2017-02-08 02:39:36','16','','2017-02-08 02:39:36');
INSERT INTO `glpi_logs` VALUES ('529','Ticket','62','','0','Manassrisuksai Sutham (6)','2017-02-08 02:39:36','17','','2017-02-08 02:39:36');
INSERT INTO `glpi_logs` VALUES ('530','Ticket','63','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:40:28','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('531','Ticket','63','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:40:28','0','','');
INSERT INTO `glpi_logs` VALUES ('532','Ticket','63','','0','Manassrisuksai Sutham (6)','2017-02-08 02:41:25','24','','&lt;p&gt;เป็นปัญหา Config ใน Server แจ้งทาง Art แก้ไขแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('533','Ticket','63','','0','Manassrisuksai Sutham (6)','2017-02-08 02:41:25','12','1','6');
INSERT INTO `glpi_logs` VALUES ('534','Ticket','63','','0','Manassrisuksai Sutham (6)','2017-02-08 02:41:25','16','','2017-02-08 02:41:25');
INSERT INTO `glpi_logs` VALUES ('535','Ticket','63','','0','Manassrisuksai Sutham (6)','2017-02-08 02:41:25','17','','2017-02-08 02:41:25');
INSERT INTO `glpi_logs` VALUES ('536','Ticket','64','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:42:13','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('537','Ticket','64','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:42:13','0','','');
INSERT INTO `glpi_logs` VALUES ('538','Ticket','64','','0','Manassrisuksai Sutham (6)','2017-02-08 02:42:39','24','','&lt;p&gt;upgrade conputer เพิ่ม Ram 2G&lt;/p&gt;rn&lt;p&gt;ลงโปรแกรม Comcash ใหม่&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('539','Ticket','64','','0','Manassrisuksai Sutham (6)','2017-02-08 02:42:39','12','1','6');
INSERT INTO `glpi_logs` VALUES ('540','Ticket','64','','0','Manassrisuksai Sutham (6)','2017-02-08 02:42:39','16','','2017-02-08 02:42:39');
INSERT INTO `glpi_logs` VALUES ('541','Ticket','64','','0','Manassrisuksai Sutham (6)','2017-02-08 02:42:39','17','','2017-02-08 02:42:39');
INSERT INTO `glpi_logs` VALUES ('542','Ticket','65','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:43:38','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('543','Ticket','65','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:43:38','0','','');
INSERT INTO `glpi_logs` VALUES ('544','Ticket','65','','0','Manassrisuksai Sutham (6)','2017-02-08 02:43:57','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('545','Ticket','65','','0','Manassrisuksai Sutham (6)','2017-02-08 02:43:57','12','1','6');
INSERT INTO `glpi_logs` VALUES ('546','Ticket','65','','0','Manassrisuksai Sutham (6)','2017-02-08 02:43:57','16','','2017-02-08 02:43:57');
INSERT INTO `glpi_logs` VALUES ('547','Ticket','65','','0','Manassrisuksai Sutham (6)','2017-02-08 02:43:57','17','','2017-02-08 02:43:57');
INSERT INTO `glpi_logs` VALUES ('548','Ticket','66','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:44:46','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('549','Ticket','66','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:44:46','0','','');
INSERT INTO `glpi_logs` VALUES ('550','Ticket','66','','0','Manassrisuksai Sutham (6)','2017-02-08 02:45:31','24','','&lt;p&gt;เป็นปัญหา Version Comcash ได้ประสานงานกับทาง Newsoft แก้ไขแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('551','Ticket','66','','0','Manassrisuksai Sutham (6)','2017-02-08 02:45:31','12','1','6');
INSERT INTO `glpi_logs` VALUES ('552','Ticket','66','','0','Manassrisuksai Sutham (6)','2017-02-08 02:45:31','16','','2017-02-08 02:45:31');
INSERT INTO `glpi_logs` VALUES ('553','Ticket','66','','0','Manassrisuksai Sutham (6)','2017-02-08 02:45:31','17','','2017-02-08 02:45:31');
INSERT INTO `glpi_logs` VALUES ('554','Ticket','67','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:46:18','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('555','Ticket','67','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:46:18','0','','');
INSERT INTO `glpi_logs` VALUES ('556','Ticket','67','','0','Manassrisuksai Sutham (6)','2017-02-08 02:46:41','24','','&lt;p&gt;ดำเนินการเปลี่ยนจอให้ใหม่แล้ว &lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('557','Ticket','67','','0','Manassrisuksai Sutham (6)','2017-02-08 02:46:41','12','1','6');
INSERT INTO `glpi_logs` VALUES ('558','Ticket','67','','0','Manassrisuksai Sutham (6)','2017-02-08 02:46:41','16','','2017-02-08 02:46:41');
INSERT INTO `glpi_logs` VALUES ('559','Ticket','67','','0','Manassrisuksai Sutham (6)','2017-02-08 02:46:41','17','','2017-02-08 02:46:41');
INSERT INTO `glpi_logs` VALUES ('560','Ticket','68','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:47:28','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('561','Ticket','68','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:47:28','0','','');
INSERT INTO `glpi_logs` VALUES ('562','Ticket','68','','0','Manassrisuksai Sutham (6)','2017-02-08 02:47:49','24','','&lt;p&gt;เปลี่ยนคอมใหม่&lt;/p&gt;rn&lt;p&gt;&lt;br /&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('563','Ticket','68','','0','Manassrisuksai Sutham (6)','2017-02-08 02:47:49','12','1','6');
INSERT INTO `glpi_logs` VALUES ('564','Ticket','68','','0','Manassrisuksai Sutham (6)','2017-02-08 02:47:49','16','','2017-02-08 02:47:49');
INSERT INTO `glpi_logs` VALUES ('565','Ticket','68','','0','Manassrisuksai Sutham (6)','2017-02-08 02:47:49','17','','2017-02-08 02:47:49');
INSERT INTO `glpi_logs` VALUES ('566','Ticket','69','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:48:45','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('567','Ticket','69','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:48:45','0','','');
INSERT INTO `glpi_logs` VALUES ('568','Ticket','69','','0','Manassrisuksai Sutham (6)','2017-02-08 02:49:01','24','','&lt;p&gt;ดำเนินการ ติดตั้ง Ram Server SWR,KML 32G&lt;/p&gt;rn&lt;p&gt; &lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('569','Ticket','69','','0','Manassrisuksai Sutham (6)','2017-02-08 02:49:01','12','1','6');
INSERT INTO `glpi_logs` VALUES ('570','Ticket','69','','0','Manassrisuksai Sutham (6)','2017-02-08 02:49:01','16','','2017-02-08 02:49:01');
INSERT INTO `glpi_logs` VALUES ('571','Ticket','69','','0','Manassrisuksai Sutham (6)','2017-02-08 02:49:01','17','','2017-02-08 02:49:01');
INSERT INTO `glpi_logs` VALUES ('572','Ticket','70','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:49:46','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('573','Ticket','70','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:49:46','0','','');
INSERT INTO `glpi_logs` VALUES ('574','Ticket','70','','0','Manassrisuksai Sutham (6)','2017-02-08 02:50:02','24','','&lt;p&gt;ดำเนินการแก้ไขเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;&lt;br /&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('575','Ticket','70','','0','Manassrisuksai Sutham (6)','2017-02-08 02:50:02','12','1','6');
INSERT INTO `glpi_logs` VALUES ('576','Ticket','70','','0','Manassrisuksai Sutham (6)','2017-02-08 02:50:02','16','','2017-02-08 13:49:00');
INSERT INTO `glpi_logs` VALUES ('577','Ticket','70','','0','Manassrisuksai Sutham (6)','2017-02-08 02:50:02','17','','2017-02-08 13:49:00');
INSERT INTO `glpi_logs` VALUES ('578','Ticket','71','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:51:20','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('579','Ticket','71','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:51:20','0','','');
INSERT INTO `glpi_logs` VALUES ('580','Ticket','71','','0','Manassrisuksai Sutham (6)','2017-02-08 02:51:31','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('581','Ticket','71','','0','Manassrisuksai Sutham (6)','2017-02-08 02:51:31','12','1','6');
INSERT INTO `glpi_logs` VALUES ('582','Ticket','71','','0','Manassrisuksai Sutham (6)','2017-02-08 02:51:31','16','','2017-02-08 02:51:31');
INSERT INTO `glpi_logs` VALUES ('583','Ticket','71','','0','Manassrisuksai Sutham (6)','2017-02-08 02:51:31','17','','2017-02-08 02:51:31');
INSERT INTO `glpi_logs` VALUES ('584','Ticket','72','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:52:14','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('585','Ticket','72','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:52:14','0','','');
INSERT INTO `glpi_logs` VALUES ('586','Ticket','72','','0','Manassrisuksai Sutham (6)','2017-02-08 02:52:25','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('587','Ticket','72','','0','Manassrisuksai Sutham (6)','2017-02-08 02:52:25','12','1','6');
INSERT INTO `glpi_logs` VALUES ('588','Ticket','72','','0','Manassrisuksai Sutham (6)','2017-02-08 02:52:25','16','','2017-02-08 02:52:25');
INSERT INTO `glpi_logs` VALUES ('589','Ticket','72','','0','Manassrisuksai Sutham (6)','2017-02-08 02:52:25','17','','2017-02-08 02:52:25');
INSERT INTO `glpi_logs` VALUES ('590','Ticket','73','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:53:23','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('591','Ticket','73','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:53:23','0','','');
INSERT INTO `glpi_logs` VALUES ('592','Ticket','73','','0','Manassrisuksai Sutham (6)','2017-02-08 02:53:45','24','','&lt;p&gt;Line Cable and Cord have a problem.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('593','Ticket','73','','0','Manassrisuksai Sutham (6)','2017-02-08 02:53:45','12','1','6');
INSERT INTO `glpi_logs` VALUES ('594','Ticket','73','','0','Manassrisuksai Sutham (6)','2017-02-08 02:53:45','16','','2017-02-08 02:53:45');
INSERT INTO `glpi_logs` VALUES ('595','Ticket','73','','0','Manassrisuksai Sutham (6)','2017-02-08 02:53:45','17','','2017-02-08 02:53:45');
INSERT INTO `glpi_logs` VALUES ('596','Ticket','74','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:54:34','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('597','Ticket','74','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:54:34','0','','');
INSERT INTO `glpi_logs` VALUES ('598','Ticket','74','','0','Manassrisuksai Sutham (6)','2017-02-08 02:55:03','24','','&lt;p&gt;ติดต่อสอบถามไปยัง Newsoft แล้วปัญหาดังกล่าวไม่หน้าจะเกี่ยวกับ Menu&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('599','Ticket','74','','0','Manassrisuksai Sutham (6)','2017-02-08 02:55:03','12','1','6');
INSERT INTO `glpi_logs` VALUES ('600','Ticket','74','','0','Manassrisuksai Sutham (6)','2017-02-08 02:55:03','16','','2017-02-08 02:55:03');
INSERT INTO `glpi_logs` VALUES ('601','Ticket','74','','0','Manassrisuksai Sutham (6)','2017-02-08 02:55:03','17','','2017-02-08 02:55:03');
INSERT INTO `glpi_logs` VALUES ('602','Ticket','75','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:56:13','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('603','Ticket','75','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:56:13','0','','');
INSERT INTO `glpi_logs` VALUES ('604','Ticket','75','','0','Manassrisuksai Sutham (6)','2017-02-08 02:56:35','24','','&lt;p&gt;ดำเนินการแก้ไขแล้วครับ&lt;/p&gt;rn&lt;p&gt;ลบและสร้าง Account ให้ใหม่&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('605','Ticket','75','','0','Manassrisuksai Sutham (6)','2017-02-08 02:56:35','12','1','6');
INSERT INTO `glpi_logs` VALUES ('606','Ticket','75','','0','Manassrisuksai Sutham (6)','2017-02-08 02:56:35','16','','2017-02-08 02:56:35');
INSERT INTO `glpi_logs` VALUES ('607','Ticket','75','','0','Manassrisuksai Sutham (6)','2017-02-08 02:56:35','17','','2017-02-08 02:56:35');
INSERT INTO `glpi_logs` VALUES ('608','Ticket','76','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:57:11','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('609','Ticket','76','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:57:11','0','','');
INSERT INTO `glpi_logs` VALUES ('610','Ticket','76','','0','Manassrisuksai Sutham (6)','2017-02-08 02:57:39','24','','&lt;p&gt;ดำเนินการแก้ไขแล้วครับ&lt;/p&gt;rn&lt;p&gt;ลบและสร้าง Account ใหม่&lt;/p&gt;rn&lt;p&gt;แขกสามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('611','Ticket','76','','0','Manassrisuksai Sutham (6)','2017-02-08 02:57:39','12','1','6');
INSERT INTO `glpi_logs` VALUES ('612','Ticket','76','','0','Manassrisuksai Sutham (6)','2017-02-08 02:57:39','16','','2017-02-08 02:57:39');
INSERT INTO `glpi_logs` VALUES ('613','Ticket','76','','0','Manassrisuksai Sutham (6)','2017-02-08 02:57:39','17','','2017-02-08 02:57:39');
INSERT INTO `glpi_logs` VALUES ('614','Ticket','77','User','15','Manassrisuksai Sutham (6)','2017-02-08 02:58:25','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('615','Ticket','77','0','20','Manassrisuksai Sutham (6)','2017-02-08 02:58:25','0','','');
INSERT INTO `glpi_logs` VALUES ('616','Ticket','77','','0','Manassrisuksai Sutham (6)','2017-02-08 02:59:15','24','','&lt;p&gt;CH1,2,3 เปลี่ยน DVR ใหม่ใช้งานได้ปกติ&lt;/p&gt;rn&lt;p&gt;ส่วน CH4 เดินสายไฟใหม่&lt;/p&gt;rn&lt;p&gt;ยังคงเหลือในส่วนของ CH5 บริเวรณสระ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('617','Ticket','77','','0','Manassrisuksai Sutham (6)','2017-02-08 02:59:15','12','1','6');
INSERT INTO `glpi_logs` VALUES ('618','Ticket','77','','0','Manassrisuksai Sutham (6)','2017-02-08 02:59:15','16','','2017-02-08 02:59:15');
INSERT INTO `glpi_logs` VALUES ('619','Ticket','77','','0','Manassrisuksai Sutham (6)','2017-02-08 02:59:15','17','','2017-02-08 02:59:15');
INSERT INTO `glpi_logs` VALUES ('620','Ticket','78','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:00:26','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('621','Ticket','78','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:00:26','0','','');
INSERT INTO `glpi_logs` VALUES ('622','Ticket','78','','0','Manassrisuksai Sutham (6)','2017-02-08 03:00:44','24','','&lt;p&gt;ทำการเก็บตัวอย่างมาวิเคราะห์&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('623','Ticket','78','','0','Manassrisuksai Sutham (6)','2017-02-08 03:00:44','12','1','6');
INSERT INTO `glpi_logs` VALUES ('624','Ticket','78','','0','Manassrisuksai Sutham (6)','2017-02-08 03:00:44','16','','2017-02-08 03:00:44');
INSERT INTO `glpi_logs` VALUES ('625','Ticket','78','','0','Manassrisuksai Sutham (6)','2017-02-08 03:00:44','17','','2017-02-08 03:00:44');
INSERT INTO `glpi_logs` VALUES ('626','Ticket','79','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:02:01','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('627','Ticket','79','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:02:01','0','','');
INSERT INTO `glpi_logs` VALUES ('628','Ticket','79','','0','Manassrisuksai Sutham (6)','2017-02-08 03:03:17','24','','&lt;p&gt;สอบถามไปยัง Newsoft แล้วพบว่า&lt;/p&gt;rn&lt;p&gt;เป็นปัญหาเรื่อง Version ของ Comcash&lt;/p&gt;rn&lt;p&gt;โดยของใหม่จะไม่นำ Memo Option food มา Summary&lt;/p&gt;rn&lt;p&gt');
INSERT INTO `glpi_logs` VALUES ('629','Ticket','79','','0','Manassrisuksai Sutham (6)','2017-02-08 03:03:17','12','1','6');
INSERT INTO `glpi_logs` VALUES ('630','Ticket','79','','0','Manassrisuksai Sutham (6)','2017-02-08 03:03:17','16','','2017-02-08 03:03:17');
INSERT INTO `glpi_logs` VALUES ('631','Ticket','79','','0','Manassrisuksai Sutham (6)','2017-02-08 03:03:17','17','','2017-02-08 03:03:17');
INSERT INTO `glpi_logs` VALUES ('632','Ticket','80','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:04:09','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('633','Ticket','80','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:04:09','0','','');
INSERT INTO `glpi_logs` VALUES ('634','Ticket','80','','0','Manassrisuksai Sutham (6)','2017-02-08 03:04:31','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว สายไฟหลวม&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('635','Ticket','80','','0','Manassrisuksai Sutham (6)','2017-02-08 03:04:31','12','1','6');
INSERT INTO `glpi_logs` VALUES ('636','Ticket','80','','0','Manassrisuksai Sutham (6)','2017-02-08 03:04:31','16','','2017-02-08 03:04:31');
INSERT INTO `glpi_logs` VALUES ('637','Ticket','80','','0','Manassrisuksai Sutham (6)','2017-02-08 03:04:31','17','','2017-02-08 03:04:31');
INSERT INTO `glpi_logs` VALUES ('638','Ticket','81','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:05:51','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('639','Ticket','81','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:05:51','0','','');
INSERT INTO `glpi_logs` VALUES ('640','Ticket','81','','0','Manassrisuksai Sutham (6)','2017-02-08 03:06:20','24','','&lt;p&gt;Create New Password &lt;/p&gt;rn&lt;p&gt;Guest available wifi.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('641','Ticket','81','','0','Manassrisuksai Sutham (6)','2017-02-08 03:06:20','12','1','6');
INSERT INTO `glpi_logs` VALUES ('642','Ticket','81','','0','Manassrisuksai Sutham (6)','2017-02-08 03:06:20','16','','2017-02-08 03:06:20');
INSERT INTO `glpi_logs` VALUES ('643','Ticket','81','','0','Manassrisuksai Sutham (6)','2017-02-08 03:06:20','17','','2017-02-08 03:06:20');
INSERT INTO `glpi_logs` VALUES ('644','Ticket','82','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:07:55','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('645','Ticket','82','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:07:55','0','','');
INSERT INTO `glpi_logs` VALUES ('646','Ticket','82','','0','Manassrisuksai Sutham (6)','2017-02-08 03:08:18','24','','&lt;p&gt;ช่างเข้ามาตรวจเช็คwifi และได้ทำการถอดสาย Lan มาเส้นออก&lt;/p&gt;rn&lt;p&gt;ได้ดำเนินการแก้ไขแล้วขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('647','Ticket','82','','0','Manassrisuksai Sutham (6)','2017-02-08 03:08:18','12','1','6');
INSERT INTO `glpi_logs` VALUES ('648','Ticket','82','','0','Manassrisuksai Sutham (6)','2017-02-08 03:08:18','16','','2017-02-08 03:08:18');
INSERT INTO `glpi_logs` VALUES ('649','Ticket','82','','0','Manassrisuksai Sutham (6)','2017-02-08 03:08:18','17','','2017-02-08 03:08:18');
INSERT INTO `glpi_logs` VALUES ('650','Ticket','83','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:09:02','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('651','Ticket','83','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:09:02','0','','');
INSERT INTO `glpi_logs` VALUES ('652','Ticket','83','','0','Manassrisuksai Sutham (6)','2017-02-08 03:09:41','24','','&lt;p&gt;ทาง Newsoft แจ้งว่า ROM PRINTER มีปัญหา&lt;/p&gt;rn&lt;p&gt;ต้องส่งไปอัพ ROM&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('653','Ticket','83','','0','Manassrisuksai Sutham (6)','2017-02-08 03:09:41','12','1','6');
INSERT INTO `glpi_logs` VALUES ('654','Ticket','83','','0','Manassrisuksai Sutham (6)','2017-02-08 03:09:41','16','','2017-02-08 03:09:41');
INSERT INTO `glpi_logs` VALUES ('655','Ticket','83','','0','Manassrisuksai Sutham (6)','2017-02-08 03:09:41','17','','2017-02-08 03:09:41');
INSERT INTO `glpi_logs` VALUES ('656','Ticket','84','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:10:26','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('657','Ticket','84','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:10:26','0','','');
INSERT INTO `glpi_logs` VALUES ('658','Ticket','84','','0','Manassrisuksai Sutham (6)','2017-02-08 03:10:41','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้วครับ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('659','Ticket','84','','0','Manassrisuksai Sutham (6)','2017-02-08 03:10:41','12','1','6');
INSERT INTO `glpi_logs` VALUES ('660','Ticket','84','','0','Manassrisuksai Sutham (6)','2017-02-08 03:10:41','16','','2017-02-08 03:10:41');
INSERT INTO `glpi_logs` VALUES ('661','Ticket','84','','0','Manassrisuksai Sutham (6)','2017-02-08 03:10:41','17','','2017-02-08 03:10:41');
INSERT INTO `glpi_logs` VALUES ('662','Ticket','85','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:11:36','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('663','Ticket','85','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:11:36','0','','');
INSERT INTO `glpi_logs` VALUES ('664','Ticket','85','','0','Manassrisuksai Sutham (6)','2017-02-08 03:11:49','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('665','Ticket','85','','0','Manassrisuksai Sutham (6)','2017-02-08 03:11:49','12','1','6');
INSERT INTO `glpi_logs` VALUES ('666','Ticket','85','','0','Manassrisuksai Sutham (6)','2017-02-08 03:11:49','16','','2017-02-08 03:11:49');
INSERT INTO `glpi_logs` VALUES ('667','Ticket','85','','0','Manassrisuksai Sutham (6)','2017-02-08 03:11:49','17','','2017-02-08 03:11:49');
INSERT INTO `glpi_logs` VALUES ('668','Ticket','86','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:12:32','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('669','Ticket','86','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:12:32','0','','');
INSERT INTO `glpi_logs` VALUES ('670','Ticket','86','','0','Manassrisuksai Sutham (6)','2017-02-08 03:13:00','24','','&lt;p&gt;Restart service&lt;/p&gt;rn&lt;p&gt;restart computer&lt;/p&gt;rn&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('671','Ticket','86','','0','Manassrisuksai Sutham (6)','2017-02-08 03:13:00','12','1','6');
INSERT INTO `glpi_logs` VALUES ('672','Ticket','86','','0','Manassrisuksai Sutham (6)','2017-02-08 03:13:00','16','','2017-02-08 03:13:00');
INSERT INTO `glpi_logs` VALUES ('673','Ticket','86','','0','Manassrisuksai Sutham (6)','2017-02-08 03:13:00','17','','2017-02-08 03:13:00');
INSERT INTO `glpi_logs` VALUES ('674','Ticket','87','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:13:33','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('675','Ticket','87','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:13:33','0','','');
INSERT INTO `glpi_logs` VALUES ('676','Ticket','87','','0','Manassrisuksai Sutham (6)','2017-02-08 03:13:58','24','','&lt;p&gt;Restart Service ใช้งานได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('677','Ticket','87','','0','Manassrisuksai Sutham (6)','2017-02-08 03:13:58','12','1','6');
INSERT INTO `glpi_logs` VALUES ('678','Ticket','87','','0','Manassrisuksai Sutham (6)','2017-02-08 03:13:58','16','','2017-02-08 03:13:58');
INSERT INTO `glpi_logs` VALUES ('679','Ticket','87','','0','Manassrisuksai Sutham (6)','2017-02-08 03:13:58','17','','2017-02-08 03:13:58');
INSERT INTO `glpi_logs` VALUES ('680','Ticket','88','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:15:07','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('681','Ticket','88','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:15:07','0','','');
INSERT INTO `glpi_logs` VALUES ('682','Ticket','88','','0','Manassrisuksai Sutham (6)','2017-02-08 03:15:31','24','','&lt;p&gt;เช็คเครื่องบันทึกและสาย&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('683','Ticket','88','','0','Manassrisuksai Sutham (6)','2017-02-08 03:15:31','12','1','6');
INSERT INTO `glpi_logs` VALUES ('684','Ticket','88','','0','Manassrisuksai Sutham (6)','2017-02-08 03:15:31','16','','2017-02-08 03:15:31');
INSERT INTO `glpi_logs` VALUES ('685','Ticket','88','','0','Manassrisuksai Sutham (6)','2017-02-08 03:15:31','17','','2017-02-08 03:15:31');
INSERT INTO `glpi_logs` VALUES ('686','Ticket','89','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:16:13','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('687','Ticket','89','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:16:13','0','','');
INSERT INTO `glpi_logs` VALUES ('688','Ticket','89','','0','Manassrisuksai Sutham (6)','2017-02-08 03:16:46','24','','&lt;p&gt;ค่าต่างๆยังคงเดิมยกเว้น เซ็ตค่า DHCP NETWORK 1DAY&lt;/p&gt;rn&lt;p&gt;และเอาในส่วนของ Restart server 1วันออก&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('689','Ticket','89','','0','Manassrisuksai Sutham (6)','2017-02-08 03:16:46','12','1','6');
INSERT INTO `glpi_logs` VALUES ('690','Ticket','89','','0','Manassrisuksai Sutham (6)','2017-02-08 03:16:46','16','','2017-02-08 03:16:46');
INSERT INTO `glpi_logs` VALUES ('691','Ticket','89','','0','Manassrisuksai Sutham (6)','2017-02-08 03:16:46','17','','2017-02-08 03:16:46');
INSERT INTO `glpi_logs` VALUES ('692','Ticket','90','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:17:24','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('693','Ticket','90','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:17:24','0','','');
INSERT INTO `glpi_logs` VALUES ('694','Ticket','90','','0','Manassrisuksai Sutham (6)','2017-02-08 03:17:56','24','','&lt;p&gt;ช่าง Amati เข้ามาตรวจเช็คสาย wifi ทำสาย LAN MINIMARKET หลุด&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('695','Ticket','90','','0','Manassrisuksai Sutham (6)','2017-02-08 03:17:56','12','1','6');
INSERT INTO `glpi_logs` VALUES ('696','Ticket','90','','0','Manassrisuksai Sutham (6)','2017-02-08 03:17:56','16','','2017-02-08 03:17:56');
INSERT INTO `glpi_logs` VALUES ('697','Ticket','90','','0','Manassrisuksai Sutham (6)','2017-02-08 03:17:56','17','','2017-02-08 03:17:56');
INSERT INTO `glpi_logs` VALUES ('698','Ticket','91','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:18:48','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('699','Ticket','91','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:18:48','0','','');
INSERT INTO `glpi_logs` VALUES ('700','Ticket','91','','0','Manassrisuksai Sutham (6)','2017-02-08 03:19:32','24','','&lt;p&gt;ดำเนินการสลับอุปกรณ์ Spare ไว้ก่อน&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('701','Ticket','91','','0','Manassrisuksai Sutham (6)','2017-02-08 03:19:32','12','1','6');
INSERT INTO `glpi_logs` VALUES ('702','Ticket','91','','0','Manassrisuksai Sutham (6)','2017-02-08 03:19:32','16','','2017-02-08 03:19:32');
INSERT INTO `glpi_logs` VALUES ('703','Ticket','91','','0','Manassrisuksai Sutham (6)','2017-02-08 03:19:32','17','','2017-02-08 03:19:32');
INSERT INTO `glpi_logs` VALUES ('704','ITILCategory','76','0','20','dong (2)','2017-02-08 03:20:51','0','','');
INSERT INTO `glpi_logs` VALUES ('705','ITILCategory','77','0','20','dong (2)','2017-02-08 03:20:57','0','','');
INSERT INTO `glpi_logs` VALUES ('706','ITILCategory','78','0','20','dong (2)','2017-02-08 03:21:06','0','','');
INSERT INTO `glpi_logs` VALUES ('707','Ticket','92','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:21:45','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('708','Ticket','92','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:21:45','0','','');
INSERT INTO `glpi_logs` VALUES ('709','Ticket','92','','0','Manassrisuksai Sutham (6)','2017-02-08 03:22:33','24','','&lt;p&gt;mail server full&lt;/p&gt;rn&lt;p&gt;clear old mail already.&lt;/p&gt;rn&lt;p&gt;user available.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('710','Ticket','92','','0','Manassrisuksai Sutham (6)','2017-02-08 03:22:33','12','1','6');
INSERT INTO `glpi_logs` VALUES ('711','Ticket','92','','0','Manassrisuksai Sutham (6)','2017-02-08 03:22:33','16','','2017-02-08 03:22:33');
INSERT INTO `glpi_logs` VALUES ('712','Ticket','92','','0','Manassrisuksai Sutham (6)','2017-02-08 03:22:33','17','','2017-02-08 03:22:33');
INSERT INTO `glpi_logs` VALUES ('713','Ticket','93','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:23:40','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('714','Ticket','93','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:23:40','0','','');
INSERT INTO `glpi_logs` VALUES ('715','Ticket','93','','0','Manassrisuksai Sutham (6)','2017-02-08 03:23:53','24','','&lt;p&gt;Restart เครื่องใหม่ใช้งานได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('716','Ticket','93','','0','Manassrisuksai Sutham (6)','2017-02-08 03:23:53','12','1','6');
INSERT INTO `glpi_logs` VALUES ('717','Ticket','93','','0','Manassrisuksai Sutham (6)','2017-02-08 03:23:53','16','','2017-02-08 03:23:53');
INSERT INTO `glpi_logs` VALUES ('718','Ticket','93','','0','Manassrisuksai Sutham (6)','2017-02-08 03:23:53','17','','2017-02-08 03:23:53');
INSERT INTO `glpi_logs` VALUES ('719','Ticket','94','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:24:27','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('720','Ticket','94','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:24:27','0','','');
INSERT INTO `glpi_logs` VALUES ('721','Ticket','94','','0','Manassrisuksai Sutham (6)','2017-02-08 03:24:56','24','','&lt;p&gt;Clear paper Jam&lt;/p&gt;rn&lt;p&gt;User Available.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('722','Ticket','94','','0','Manassrisuksai Sutham (6)','2017-02-08 03:24:56','12','1','6');
INSERT INTO `glpi_logs` VALUES ('723','Ticket','94','','0','Manassrisuksai Sutham (6)','2017-02-08 03:24:56','16','','2017-02-08 03:24:56');
INSERT INTO `glpi_logs` VALUES ('724','Ticket','94','','0','Manassrisuksai Sutham (6)','2017-02-08 03:24:56','17','','2017-02-08 03:24:56');
INSERT INTO `glpi_logs` VALUES ('725','Ticket','95','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:25:44','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('726','Ticket','95','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:25:44','0','','');
INSERT INTO `glpi_logs` VALUES ('727','Ticket','95','','0','Manassrisuksai Sutham (6)','2017-02-08 03:26:08','24','','&lt;p&gt;Test Wifi 5Login Sunwing&lt;br /&gt;Tell Khun Aoi Set 5 login 1 Password&lt;/p&gt;rn&lt;p&gt;Now available.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('728','Ticket','95','','0','Manassrisuksai Sutham (6)','2017-02-08 03:26:08','12','1','6');
INSERT INTO `glpi_logs` VALUES ('729','Ticket','95','','0','Manassrisuksai Sutham (6)','2017-02-08 03:26:08','16','','2017-02-08 03:26:08');
INSERT INTO `glpi_logs` VALUES ('730','Ticket','95','','0','Manassrisuksai Sutham (6)','2017-02-08 03:26:08','17','','2017-02-08 03:26:08');
INSERT INTO `glpi_logs` VALUES ('731','Ticket','96','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:27:17','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('732','Ticket','96','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:27:17','0','','');
INSERT INTO `glpi_logs` VALUES ('733','Ticket','96','','0','Manassrisuksai Sutham (6)','2017-02-08 03:28:16','24','','&lt;p&gt;engineer come to setup fiber.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('734','Ticket','96','','0','Manassrisuksai Sutham (6)','2017-02-08 03:28:16','12','1','6');
INSERT INTO `glpi_logs` VALUES ('735','Ticket','96','','0','Manassrisuksai Sutham (6)','2017-02-08 03:28:16','16','','2017-02-08 03:28:16');
INSERT INTO `glpi_logs` VALUES ('736','Ticket','96','','0','Manassrisuksai Sutham (6)','2017-02-08 03:28:16','17','','2017-02-08 03:28:16');
INSERT INTO `glpi_logs` VALUES ('737','Ticket','97','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:29:03','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('738','Ticket','97','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:29:03','0','','');
INSERT INTO `glpi_logs` VALUES ('739','Ticket','97','','0','Manassrisuksai Sutham (6)','2017-02-08 03:29:48','24','','&lt;p&gt;ลบ Excel version เก่าออก&lt;/p&gt;rn&lt;p&gt;และดำเนินการตั้ง Defalt App window10 เป็น excel&lt;/p&gt;rn&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('740','Ticket','97','','0','Manassrisuksai Sutham (6)','2017-02-08 03:29:48','12','1','6');
INSERT INTO `glpi_logs` VALUES ('741','Ticket','97','','0','Manassrisuksai Sutham (6)','2017-02-08 03:29:48','16','','2017-02-08 03:29:48');
INSERT INTO `glpi_logs` VALUES ('742','Ticket','97','','0','Manassrisuksai Sutham (6)','2017-02-08 03:29:48','17','','2017-02-08 03:29:48');
INSERT INTO `glpi_logs` VALUES ('743','Ticket','98','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:30:29','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('744','Ticket','98','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:30:29','0','','');
INSERT INTO `glpi_logs` VALUES ('745','Ticket','98','','0','Manassrisuksai Sutham (6)','2017-02-08 03:30:50','24','','&lt;p&gt;ช่างตรวจเช็คสาย ทำสาย wifi หลุด&lt;/p&gt;rn&lt;p&gt;ดำเนินการแก้ไขแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('746','Ticket','98','','0','Manassrisuksai Sutham (6)','2017-02-08 03:30:50','12','1','6');
INSERT INTO `glpi_logs` VALUES ('747','Ticket','98','','0','Manassrisuksai Sutham (6)','2017-02-08 03:30:50','16','','2017-02-08 03:30:50');
INSERT INTO `glpi_logs` VALUES ('748','Ticket','98','','0','Manassrisuksai Sutham (6)','2017-02-08 03:30:50','17','','2017-02-08 03:30:50');
INSERT INTO `glpi_logs` VALUES ('749','Ticket','99','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:31:27','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('750','Ticket','99','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:31:27','0','','');
INSERT INTO `glpi_logs` VALUES ('751','Ticket','99','','0','Manassrisuksai Sutham (6)','2017-02-08 03:33:23','24','','&lt;p&gt;CREATE NEW ACCOUNT&lt;/p&gt;rn&lt;p&gt;AUTHEN HAVE SOME PROBLEM CAN\'T Sync Data.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('752','Ticket','99','','0','Manassrisuksai Sutham (6)','2017-02-08 03:33:23','12','1','6');
INSERT INTO `glpi_logs` VALUES ('753','Ticket','99','','0','Manassrisuksai Sutham (6)','2017-02-08 03:33:23','16','','2017-02-08 03:33:23');
INSERT INTO `glpi_logs` VALUES ('754','Ticket','99','','0','Manassrisuksai Sutham (6)','2017-02-08 03:33:23','17','','2017-02-08 03:33:23');
INSERT INTO `glpi_logs` VALUES ('755','Ticket','100','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:34:46','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('756','Ticket','100','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:34:46','0','','');
INSERT INTO `glpi_logs` VALUES ('757','Ticket','100','','0','Manassrisuksai Sutham (6)','2017-02-08 03:35:42','24','','&lt;p&gt;mail ที่ส่งมาไม่ใช่ File PDF ต้องให้ Guest ส่งไฟล์ใหม่อีกครั้ง&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('758','Ticket','100','','0','Manassrisuksai Sutham (6)','2017-02-08 03:35:42','12','1','6');
INSERT INTO `glpi_logs` VALUES ('759','Ticket','100','','0','Manassrisuksai Sutham (6)','2017-02-08 03:35:42','16','','2017-02-08 03:35:42');
INSERT INTO `glpi_logs` VALUES ('760','Ticket','100','','0','Manassrisuksai Sutham (6)','2017-02-08 03:35:42','17','','2017-02-08 03:35:42');
INSERT INTO `glpi_logs` VALUES ('761','Ticket','101','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:57:06','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('762','Ticket','101','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:57:06','0','','');
INSERT INTO `glpi_logs` VALUES ('763','Ticket','101','','0','Manassrisuksai Sutham (6)','2017-02-08 03:57:18','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('764','Ticket','101','','0','Manassrisuksai Sutham (6)','2017-02-08 03:57:18','12','1','6');
INSERT INTO `glpi_logs` VALUES ('765','Ticket','101','','0','Manassrisuksai Sutham (6)','2017-02-08 03:57:18','16','','2017-02-08 03:57:18');
INSERT INTO `glpi_logs` VALUES ('766','Ticket','101','','0','Manassrisuksai Sutham (6)','2017-02-08 03:57:18','17','','2017-02-08 03:57:18');
INSERT INTO `glpi_logs` VALUES ('767','Ticket','102','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:58:19','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('768','Ticket','102','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:58:19','0','','');
INSERT INTO `glpi_logs` VALUES ('769','Ticket','102','','0','Manassrisuksai Sutham (6)','2017-02-08 03:58:54','24','','&lt;p&gt;ดึงฐานข้อมูลที่ได้ BACKUP ไว้มาใช้แทน&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('770','Ticket','102','','0','Manassrisuksai Sutham (6)','2017-02-08 03:58:54','12','1','6');
INSERT INTO `glpi_logs` VALUES ('771','Ticket','102','','0','Manassrisuksai Sutham (6)','2017-02-08 03:58:54','16','','2017-02-08 03:58:54');
INSERT INTO `glpi_logs` VALUES ('772','Ticket','102','','0','Manassrisuksai Sutham (6)','2017-02-08 03:58:54','17','','2017-02-08 03:58:54');
INSERT INTO `glpi_logs` VALUES ('773','Ticket','103','User','15','Manassrisuksai Sutham (6)','2017-02-08 03:59:35','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('774','Ticket','103','0','20','Manassrisuksai Sutham (6)','2017-02-08 03:59:35','0','','');
INSERT INTO `glpi_logs` VALUES ('775','Ticket','103','','0','Manassrisuksai Sutham (6)','2017-02-08 04:00:14','24','','&lt;p&gt;ช่าง AMATI ถอดสาย LAN ทิ้งไว้&lt;/p&gt;rn&lt;p&gt;ขณะนี้ แขกสามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('776','Ticket','103','','0','Manassrisuksai Sutham (6)','2017-02-08 04:00:14','12','1','6');
INSERT INTO `glpi_logs` VALUES ('777','Ticket','103','','0','Manassrisuksai Sutham (6)','2017-02-08 04:00:14','16','','2017-02-08 04:00:14');
INSERT INTO `glpi_logs` VALUES ('778','Ticket','103','','0','Manassrisuksai Sutham (6)','2017-02-08 04:00:14','17','','2017-02-08 04:00:14');
INSERT INTO `glpi_logs` VALUES ('779','Ticket','104','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:00:52','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('780','Ticket','104','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:00:52','0','','');
INSERT INTO `glpi_logs` VALUES ('781','Ticket','104','','0','Manassrisuksai Sutham (6)','2017-02-08 04:01:19','24','','&lt;p&gt;Reboot AP &lt;/p&gt;rn&lt;p&gt;Guest สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('782','Ticket','104','','0','Manassrisuksai Sutham (6)','2017-02-08 04:01:19','12','1','6');
INSERT INTO `glpi_logs` VALUES ('783','Ticket','104','','0','Manassrisuksai Sutham (6)','2017-02-08 04:01:19','16','','2017-02-08 04:01:19');
INSERT INTO `glpi_logs` VALUES ('784','Ticket','104','','0','Manassrisuksai Sutham (6)','2017-02-08 04:01:19','17','','2017-02-08 04:01:19');
INSERT INTO `glpi_logs` VALUES ('785','Ticket','105','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:02:01','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('786','Ticket','105','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:02:01','0','','');
INSERT INTO `glpi_logs` VALUES ('787','Ticket','105','','0','Manassrisuksai Sutham (6)','2017-02-08 04:02:12','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('788','Ticket','105','','0','Manassrisuksai Sutham (6)','2017-02-08 04:02:12','12','1','6');
INSERT INTO `glpi_logs` VALUES ('789','Ticket','105','','0','Manassrisuksai Sutham (6)','2017-02-08 04:02:12','16','','2017-02-08 04:02:12');
INSERT INTO `glpi_logs` VALUES ('790','Ticket','105','','0','Manassrisuksai Sutham (6)','2017-02-08 04:02:12','17','','2017-02-08 04:02:12');
INSERT INTO `glpi_logs` VALUES ('791','Ticket','106','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:03:22','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('792','Ticket','106','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:03:22','0','','');
INSERT INTO `glpi_logs` VALUES ('793','Ticket','106','','0','Manassrisuksai Sutham (6)','2017-02-08 04:04:02','24','','&lt;p&gt;Fix Already.&lt;/p&gt;rn&lt;p&gt;Guest available.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('794','Ticket','106','','0','Manassrisuksai Sutham (6)','2017-02-08 04:04:02','12','1','6');
INSERT INTO `glpi_logs` VALUES ('795','Ticket','106','','0','Manassrisuksai Sutham (6)','2017-02-08 04:04:02','16','','2017-02-08 04:04:02');
INSERT INTO `glpi_logs` VALUES ('796','Ticket','106','','0','Manassrisuksai Sutham (6)','2017-02-08 04:04:02','17','','2017-02-08 04:04:02');
INSERT INTO `glpi_logs` VALUES ('797','Ticket','107','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:05:14','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('798','Ticket','107','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:05:14','0','','');
INSERT INTO `glpi_logs` VALUES ('799','Ticket','107','','0','Manassrisuksai Sutham (6)','2017-02-08 04:05:22','24','','&lt;p&gt;HR @payroll ไม่แสดง วันที่8&lt;br /&gt;ย้ายฐานข้อมูลกลับปัจจุบัน&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('800','Ticket','107','','0','Manassrisuksai Sutham (6)','2017-02-08 04:05:22','12','1','6');
INSERT INTO `glpi_logs` VALUES ('801','Ticket','107','','0','Manassrisuksai Sutham (6)','2017-02-08 04:05:22','16','','2017-02-08 04:05:22');
INSERT INTO `glpi_logs` VALUES ('802','Ticket','107','','0','Manassrisuksai Sutham (6)','2017-02-08 04:05:22','17','','2017-02-08 04:05:22');
INSERT INTO `glpi_logs` VALUES ('803','Ticket','108','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:06:02','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('804','Ticket','108','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:06:02','0','','');
INSERT INTO `glpi_logs` VALUES ('805','Ticket','108','','0','Manassrisuksai Sutham (6)','2017-02-08 04:06:15','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('806','Ticket','108','','0','Manassrisuksai Sutham (6)','2017-02-08 04:06:15','12','1','6');
INSERT INTO `glpi_logs` VALUES ('807','Ticket','108','','0','Manassrisuksai Sutham (6)','2017-02-08 04:06:15','16','','2017-02-08 04:06:15');
INSERT INTO `glpi_logs` VALUES ('808','Ticket','108','','0','Manassrisuksai Sutham (6)','2017-02-08 04:06:15','17','','2017-02-08 04:06:15');
INSERT INTO `glpi_logs` VALUES ('809','Ticket','109','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:06:53','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('810','Ticket','109','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:06:53','0','','');
INSERT INTO `glpi_logs` VALUES ('811','Ticket','109','','0','Manassrisuksai Sutham (6)','2017-02-08 04:07:15','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว แต่ยังคงพบปัญหา Comcash ค้าง&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('812','Ticket','109','','0','Manassrisuksai Sutham (6)','2017-02-08 04:07:15','12','1','6');
INSERT INTO `glpi_logs` VALUES ('813','Ticket','109','','0','Manassrisuksai Sutham (6)','2017-02-08 04:07:15','16','','2017-02-08 04:07:15');
INSERT INTO `glpi_logs` VALUES ('814','Ticket','109','','0','Manassrisuksai Sutham (6)','2017-02-08 04:07:15','17','','2017-02-08 04:07:15');
INSERT INTO `glpi_logs` VALUES ('815','Ticket','110','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:07:51','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('816','Ticket','110','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:07:51','0','','');
INSERT INTO `glpi_logs` VALUES ('817','Ticket','110','','0','Manassrisuksai Sutham (6)','2017-02-08 04:08:12','24','','&lt;p&gt;แก้ปัญหา ภาษาต่างดาว &lt;/p&gt;rn&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('818','Ticket','110','','0','Manassrisuksai Sutham (6)','2017-02-08 04:08:12','12','1','6');
INSERT INTO `glpi_logs` VALUES ('819','Ticket','110','','0','Manassrisuksai Sutham (6)','2017-02-08 04:08:12','16','','2017-02-08 04:08:12');
INSERT INTO `glpi_logs` VALUES ('820','Ticket','110','','0','Manassrisuksai Sutham (6)','2017-02-08 04:08:12','17','','2017-02-08 04:08:12');
INSERT INTO `glpi_logs` VALUES ('821','Ticket','111','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:08:44','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('822','Ticket','111','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:08:44','0','','');
INSERT INTO `glpi_logs` VALUES ('823','Ticket','111','','0','Manassrisuksai Sutham (6)','2017-02-08 04:08:53','24','','&lt;p&gt;AIS FIBER ช่างเข้าดำเนินการติดตั้ง Router&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('824','Ticket','111','','0','Manassrisuksai Sutham (6)','2017-02-08 04:08:53','12','1','6');
INSERT INTO `glpi_logs` VALUES ('825','Ticket','111','','0','Manassrisuksai Sutham (6)','2017-02-08 04:08:53','16','','2017-02-08 04:08:53');
INSERT INTO `glpi_logs` VALUES ('826','Ticket','111','','0','Manassrisuksai Sutham (6)','2017-02-08 04:08:53','17','','2017-02-08 04:08:53');
INSERT INTO `glpi_logs` VALUES ('827','Ticket','112','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:09:42','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('828','Ticket','112','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:09:42','0','','');
INSERT INTO `glpi_logs` VALUES ('829','Ticket','112','','0','Manassrisuksai Sutham (6)','2017-02-08 04:09:50','24','','&lt;p&gt;ตึก2 sunwing WIFI ใช้งานไม่ได้&lt;br /&gt;UPS เสีย&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('830','Ticket','112','','0','Manassrisuksai Sutham (6)','2017-02-08 04:09:50','12','1','6');
INSERT INTO `glpi_logs` VALUES ('831','Ticket','112','','0','Manassrisuksai Sutham (6)','2017-02-08 04:09:50','16','','2017-02-08 04:09:50');
INSERT INTO `glpi_logs` VALUES ('832','Ticket','112','','0','Manassrisuksai Sutham (6)','2017-02-08 04:09:50','17','','2017-02-08 04:09:50');
INSERT INTO `glpi_logs` VALUES ('833','Ticket','113','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:10:40','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('834','Ticket','113','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:10:40','0','','');
INSERT INTO `glpi_logs` VALUES ('835','Ticket','113','','0','Manassrisuksai Sutham (6)','2017-02-08 04:11:00','150','0','734520');
INSERT INTO `glpi_logs` VALUES ('836','Ticket','113','TicketFollowup','17','Manassrisuksai Sutham (6)','2017-02-08 04:11:00','0','','1');
INSERT INTO `glpi_logs` VALUES ('837','Ticket','113','TicketFollowup','17','Manassrisuksai Sutham (6)','2017-02-08 04:11:31','0','','2');
INSERT INTO `glpi_logs` VALUES ('838','Ticket','113','','0','Manassrisuksai Sutham (6)','2017-02-08 04:13:43','24','','&lt;p&gt;ได้ดำเนินการติดตั้งกลับจุดเดิมแล้วสามารถใช้งานได้ตามปกติ&lt;/p&gt;rn&lt;p&gt;ในส่วนของการทดสอบก่อนการส่งซ่อมนั้น ได้ร่วมมือกับคุณโจมทดสอบแล้วพบไฟไม่เข้า&lt;/p&gt;rn&lt;p&g');
INSERT INTO `glpi_logs` VALUES ('839','Ticket','113','','0','Manassrisuksai Sutham (6)','2017-02-08 04:13:43','12','1','6');
INSERT INTO `glpi_logs` VALUES ('840','Ticket','113','','0','Manassrisuksai Sutham (6)','2017-02-08 04:13:43','16','','2017-02-08 04:13:43');
INSERT INTO `glpi_logs` VALUES ('841','Ticket','113','','0','Manassrisuksai Sutham (6)','2017-02-08 04:13:43','17','','2017-02-08 04:13:43');
INSERT INTO `glpi_logs` VALUES ('842','Ticket','114','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:15:38','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('843','Ticket','114','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:15:38','0','','');
INSERT INTO `glpi_logs` VALUES ('844','Ticket','114','','0','Manassrisuksai Sutham (6)','2017-02-08 04:15:49','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('845','Ticket','114','','0','Manassrisuksai Sutham (6)','2017-02-08 04:15:49','12','1','6');
INSERT INTO `glpi_logs` VALUES ('846','Ticket','114','','0','Manassrisuksai Sutham (6)','2017-02-08 04:15:49','16','','2017-02-08 04:15:49');
INSERT INTO `glpi_logs` VALUES ('847','Ticket','114','','0','Manassrisuksai Sutham (6)','2017-02-08 04:15:49','17','','2017-02-08 04:15:49');
INSERT INTO `glpi_logs` VALUES ('848','Ticket','115','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:17:46','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('849','Ticket','115','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:17:46','0','','');
INSERT INTO `glpi_logs` VALUES ('850','Ticket','115','','0','Manassrisuksai Sutham (6)','2017-02-08 04:18:00','24','','&lt;p&gt;ดำเนินการตั้ง Defalt App window10 เป็น excel&lt;/p&gt;rn&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('851','Ticket','115','','0','Manassrisuksai Sutham (6)','2017-02-08 04:18:00','12','1','6');
INSERT INTO `glpi_logs` VALUES ('852','Ticket','115','','0','Manassrisuksai Sutham (6)','2017-02-08 04:18:00','16','','2017-02-08 04:18:00');
INSERT INTO `glpi_logs` VALUES ('853','Ticket','115','','0','Manassrisuksai Sutham (6)','2017-02-08 04:18:00','17','','2017-02-08 04:18:00');
INSERT INTO `glpi_logs` VALUES ('854','Ticket','116','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:18:32','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('855','Ticket','116','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:18:32','0','','');
INSERT INTO `glpi_logs` VALUES ('856','Ticket','116','','0','Manassrisuksai Sutham (6)','2017-02-08 04:18:39','24','','&lt;p&gt;ปรับมุมกล้อง DVR 136 ประตูทางออก&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('857','Ticket','116','','0','Manassrisuksai Sutham (6)','2017-02-08 04:18:39','12','1','6');
INSERT INTO `glpi_logs` VALUES ('858','Ticket','116','','0','Manassrisuksai Sutham (6)','2017-02-08 04:18:39','16','','2017-02-08 04:18:39');
INSERT INTO `glpi_logs` VALUES ('859','Ticket','116','','0','Manassrisuksai Sutham (6)','2017-02-08 04:18:39','17','','2017-02-08 04:18:39');
INSERT INTO `glpi_logs` VALUES ('860','Ticket','117','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:19:21','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('861','Ticket','117','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:19:21','0','','');
INSERT INTO `glpi_logs` VALUES ('862','Ticket','117','','0','Manassrisuksai Sutham (6)','2017-02-08 04:20:13','24','','&lt;p&gt;Comcash latasca ค้าง&lt;/p&gt;rn&lt;p&gt;Ping ไม่หลุด&lt;/p&gt;rn&lt;p&gt;VNC REMOTE ไม่หลุด&lt;/p&gt;rn&lt;p&gt;เวลาค้างจะเป็นแค่ Outlet latasca &lt;/p&gt;rn&lt;p&gt;serv');
INSERT INTO `glpi_logs` VALUES ('863','Ticket','117','','0','Manassrisuksai Sutham (6)','2017-02-08 04:20:13','12','1','6');
INSERT INTO `glpi_logs` VALUES ('864','Ticket','117','','0','Manassrisuksai Sutham (6)','2017-02-08 04:20:13','16','','2017-02-08 04:20:13');
INSERT INTO `glpi_logs` VALUES ('865','Ticket','117','','0','Manassrisuksai Sutham (6)','2017-02-08 04:20:13','17','','2017-02-08 04:20:13');
INSERT INTO `glpi_logs` VALUES ('866','Ticket','118','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:21:04','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('867','Ticket','118','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:21:04','0','','');
INSERT INTO `glpi_logs` VALUES ('868','Ticket','118','','0','Manassrisuksai Sutham (6)','2017-02-08 04:21:54','24','','&lt;p&gt;SYNC DATA Fromas แล้วยังไม่ได้&lt;/p&gt;rn&lt;p&gt;ต้องลบ Account และสร้างใหม่&lt;/p&gt;rn&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('869','Ticket','118','','0','Manassrisuksai Sutham (6)','2017-02-08 04:21:54','12','1','6');
INSERT INTO `glpi_logs` VALUES ('870','Ticket','118','','0','Manassrisuksai Sutham (6)','2017-02-08 04:21:54','16','','2017-02-08 04:21:54');
INSERT INTO `glpi_logs` VALUES ('871','Ticket','118','','0','Manassrisuksai Sutham (6)','2017-02-08 04:21:54','17','','2017-02-08 04:21:54');
INSERT INTO `glpi_logs` VALUES ('872','Ticket','119','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:23:09','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('873','Ticket','119','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:23:09','0','','');
INSERT INTO `glpi_logs` VALUES ('874','Ticket','119','','0','Manassrisuksai Sutham (6)','2017-02-08 04:23:23','24','','&lt;p&gt;ติดตั้งโปรแกรมแช่แข็ง HDD Shadow.Defender COM GUEST ทั้งสองฝั่ง&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('875','Ticket','119','','0','Manassrisuksai Sutham (6)','2017-02-08 04:23:23','12','1','6');
INSERT INTO `glpi_logs` VALUES ('876','Ticket','119','','0','Manassrisuksai Sutham (6)','2017-02-08 04:23:23','16','','2017-02-08 04:23:23');
INSERT INTO `glpi_logs` VALUES ('877','Ticket','119','','0','Manassrisuksai Sutham (6)','2017-02-08 04:23:23','17','','2017-02-08 04:23:23');
INSERT INTO `glpi_logs` VALUES ('878','Ticket','120','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:24:36','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('879','Ticket','120','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:24:36','0','','');
INSERT INTO `glpi_logs` VALUES ('880','Ticket','120','','0','Manassrisuksai Sutham (6)','2017-02-08 04:24:50','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('881','Ticket','120','','0','Manassrisuksai Sutham (6)','2017-02-08 04:24:50','12','1','6');
INSERT INTO `glpi_logs` VALUES ('882','Ticket','120','','0','Manassrisuksai Sutham (6)','2017-02-08 04:24:50','16','','2017-02-08 04:24:50');
INSERT INTO `glpi_logs` VALUES ('883','Ticket','120','','0','Manassrisuksai Sutham (6)','2017-02-08 04:24:50','17','','2017-02-08 04:24:50');
INSERT INTO `glpi_logs` VALUES ('884','Ticket','121','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:25:39','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('885','Ticket','121','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:25:39','0','','');
INSERT INTO `glpi_logs` VALUES ('886','Ticket','121','','0','Manassrisuksai Sutham (6)','2017-02-08 04:26:06','24','','&lt;p&gt;RESTART SERVICE&lt;/p&gt;rn&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('887','Ticket','121','','0','Manassrisuksai Sutham (6)','2017-02-08 04:26:06','12','1','6');
INSERT INTO `glpi_logs` VALUES ('888','Ticket','121','','0','Manassrisuksai Sutham (6)','2017-02-08 04:26:06','16','','2017-02-08 04:26:06');
INSERT INTO `glpi_logs` VALUES ('889','Ticket','121','','0','Manassrisuksai Sutham (6)','2017-02-08 04:26:06','17','','2017-02-08 04:26:06');
INSERT INTO `glpi_logs` VALUES ('890','Ticket','122','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:27:06','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('891','Ticket','122','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:27:06','0','','');
INSERT INTO `glpi_logs` VALUES ('892','Ticket','122','','0','Manassrisuksai Sutham (6)','2017-02-08 04:27:25','24','','&lt;p&gt;ดำเนินการ Add กล้องใหม่&lt;/p&gt;rn&lt;p&gt;สามารถดูได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('893','Ticket','122','','0','Manassrisuksai Sutham (6)','2017-02-08 04:27:25','12','1','6');
INSERT INTO `glpi_logs` VALUES ('894','Ticket','122','','0','Manassrisuksai Sutham (6)','2017-02-08 04:27:25','16','','2017-02-08 04:27:25');
INSERT INTO `glpi_logs` VALUES ('895','Ticket','122','','0','Manassrisuksai Sutham (6)','2017-02-08 04:27:25','17','','2017-02-08 04:27:25');
INSERT INTO `glpi_logs` VALUES ('896','Ticket','123','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:28:08','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('897','Ticket','123','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:28:08','0','','');
INSERT INTO `glpi_logs` VALUES ('898','Ticket','123','','0','Manassrisuksai Sutham (6)','2017-02-08 04:28:17','24','','&lt;p&gt;เปลี่ยน Swtich Hub Latasca ทั้งหมด&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('899','Ticket','123','','0','Manassrisuksai Sutham (6)','2017-02-08 04:28:17','12','1','6');
INSERT INTO `glpi_logs` VALUES ('900','Ticket','123','','0','Manassrisuksai Sutham (6)','2017-02-08 04:28:17','16','','2017-02-08 04:28:17');
INSERT INTO `glpi_logs` VALUES ('901','Ticket','123','','0','Manassrisuksai Sutham (6)','2017-02-08 04:28:17','17','','2017-02-08 04:28:17');
INSERT INTO `glpi_logs` VALUES ('902','Ticket','124','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:29:17','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('903','Ticket','124','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:29:17','0','','');
INSERT INTO `glpi_logs` VALUES ('904','Ticket','124','','0','Manassrisuksai Sutham (6)','2017-02-08 04:29:24','24','','&lt;p&gt;แจ้ง KHUN KIM DATA EXPRESS เปลี่ยน Channel เป็น 1,6,11&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('905','Ticket','124','','0','Manassrisuksai Sutham (6)','2017-02-08 04:29:24','12','1','6');
INSERT INTO `glpi_logs` VALUES ('906','Ticket','124','','0','Manassrisuksai Sutham (6)','2017-02-08 04:29:24','16','','2017-02-08 04:29:24');
INSERT INTO `glpi_logs` VALUES ('907','Ticket','124','','0','Manassrisuksai Sutham (6)','2017-02-08 04:29:24','17','','2017-02-08 04:29:24');
INSERT INTO `glpi_logs` VALUES ('908','Ticket','125','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:30:09','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('909','Ticket','125','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:30:09','0','','');
INSERT INTO `glpi_logs` VALUES ('910','Ticket','125','','0','Manassrisuksai Sutham (6)','2017-02-08 04:30:52','24','','&lt;p&gt;ทำการปิดเครื่องและเปิดใหม่&lt;/p&gt;rn&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;rn&lt;p&gt;ใช้งานได้7วันหลังจาก AOF เข้ามาเซ็ตค่า Config โดยไม่ต้อง Restart Server!&lt;/p&gt');
INSERT INTO `glpi_logs` VALUES ('911','Ticket','125','','0','Manassrisuksai Sutham (6)','2017-02-08 04:30:52','12','1','6');
INSERT INTO `glpi_logs` VALUES ('912','Ticket','125','','0','Manassrisuksai Sutham (6)','2017-02-08 04:30:52','16','','2017-02-08 04:30:52');
INSERT INTO `glpi_logs` VALUES ('913','Ticket','125','','0','Manassrisuksai Sutham (6)','2017-02-08 04:30:52','17','','2017-02-08 04:30:52');
INSERT INTO `glpi_logs` VALUES ('914','Ticket','126','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:31:25','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('915','Ticket','126','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:31:25','0','','');
INSERT INTO `glpi_logs` VALUES ('916','Ticket','126','','0','Manassrisuksai Sutham (6)','2017-02-08 04:31:47','24','','&lt;p&gt;เปลี่ยน RAM สามารถใช้งานได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('917','Ticket','126','','0','Manassrisuksai Sutham (6)','2017-02-08 04:31:47','12','1','6');
INSERT INTO `glpi_logs` VALUES ('918','Ticket','126','','0','Manassrisuksai Sutham (6)','2017-02-08 04:31:47','16','','2017-02-08 04:31:47');
INSERT INTO `glpi_logs` VALUES ('919','Ticket','126','','0','Manassrisuksai Sutham (6)','2017-02-08 04:31:47','17','','2017-02-08 04:31:47');
INSERT INTO `glpi_logs` VALUES ('920','Ticket','127','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:32:46','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('921','Ticket','127','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:32:46','0','','');
INSERT INTO `glpi_logs` VALUES ('922','Ticket','127','','0','Manassrisuksai Sutham (6)','2017-02-08 04:32:57','24','','&lt;p&gt;Setup Antivirus kaspersky controller&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('923','Ticket','127','','0','Manassrisuksai Sutham (6)','2017-02-08 04:32:57','12','1','6');
INSERT INTO `glpi_logs` VALUES ('924','Ticket','127','','0','Manassrisuksai Sutham (6)','2017-02-08 04:32:57','16','','2017-02-08 04:32:57');
INSERT INTO `glpi_logs` VALUES ('925','Ticket','127','','0','Manassrisuksai Sutham (6)','2017-02-08 04:32:57','17','','2017-02-08 04:32:57');
INSERT INTO `glpi_logs` VALUES ('926','Ticket','128','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:33:25','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('927','Ticket','128','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:33:25','0','','');
INSERT INTO `glpi_logs` VALUES ('928','Ticket','128','','0','Manassrisuksai Sutham (6)','2017-02-08 04:33:41','24','','&lt;p&gt;สายสัญญาณเสีย&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('929','Ticket','128','','0','Manassrisuksai Sutham (6)','2017-02-08 04:33:41','12','1','6');
INSERT INTO `glpi_logs` VALUES ('930','Ticket','128','','0','Manassrisuksai Sutham (6)','2017-02-08 04:33:41','16','','2017-02-08 04:33:41');
INSERT INTO `glpi_logs` VALUES ('931','Ticket','128','','0','Manassrisuksai Sutham (6)','2017-02-08 04:33:41','17','','2017-02-08 04:33:41');
INSERT INTO `glpi_logs` VALUES ('932','Ticket','129','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:34:16','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('933','Ticket','129','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:34:16','0','','');
INSERT INTO `glpi_logs` VALUES ('934','Ticket','129','','0','Manassrisuksai Sutham (6)','2017-02-08 04:34:35','24','','&lt;p&gt;แก้ไขเรียบร้อยแล้ว&lt;/p&gt;rn&lt;p&gt;สามารถใช้งานได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('935','Ticket','129','','0','Manassrisuksai Sutham (6)','2017-02-08 04:34:35','12','1','6');
INSERT INTO `glpi_logs` VALUES ('936','Ticket','129','','0','Manassrisuksai Sutham (6)','2017-02-08 04:34:35','16','','2017-02-08 04:34:35');
INSERT INTO `glpi_logs` VALUES ('937','Ticket','129','','0','Manassrisuksai Sutham (6)','2017-02-08 04:34:35','17','','2017-02-08 04:34:35');
INSERT INTO `glpi_logs` VALUES ('938','Ticket','130','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:35:12','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('939','Ticket','130','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:35:12','0','','');
INSERT INTO `glpi_logs` VALUES ('940','Ticket','130','','0','Manassrisuksai Sutham (6)','2017-02-08 04:35:35','24','','&lt;p&gt;ลบและสร้าง Account ใหม่&lt;/p&gt;rn&lt;p&gt;Guest สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('941','Ticket','130','','0','Manassrisuksai Sutham (6)','2017-02-08 04:35:35','12','1','6');
INSERT INTO `glpi_logs` VALUES ('942','Ticket','130','','0','Manassrisuksai Sutham (6)','2017-02-08 04:35:35','16','','2017-02-08 04:35:35');
INSERT INTO `glpi_logs` VALUES ('943','Ticket','130','','0','Manassrisuksai Sutham (6)','2017-02-08 04:35:35','17','','2017-02-08 04:35:35');
INSERT INTO `glpi_logs` VALUES ('944','Ticket','131','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:36:08','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('945','Ticket','131','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:36:08','0','','');
INSERT INTO `glpi_logs` VALUES ('946','Ticket','131','','0','Manassrisuksai Sutham (6)','2017-02-08 04:36:25','24','','&lt;p&gt;สาย LAN หลวม&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('947','Ticket','131','','0','Manassrisuksai Sutham (6)','2017-02-08 04:36:25','12','1','6');
INSERT INTO `glpi_logs` VALUES ('948','Ticket','131','','0','Manassrisuksai Sutham (6)','2017-02-08 04:36:25','16','','2017-02-08 04:36:25');
INSERT INTO `glpi_logs` VALUES ('949','Ticket','131','','0','Manassrisuksai Sutham (6)','2017-02-08 04:36:25','17','','2017-02-08 04:36:25');
INSERT INTO `glpi_logs` VALUES ('950','Ticket','132','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:36:58','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('951','Ticket','132','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:36:58','0','','');
INSERT INTO `glpi_logs` VALUES ('952','Ticket','132','','0','Manassrisuksai Sutham (6)','2017-02-08 04:37:27','24','','&lt;p&gt;สาย Adapter เสีย&lt;/p&gt;rn&lt;p&gt;ได้ไป BIGC ซื้อมาให้คุณดำแล้ว&lt;/p&gt;rn&lt;p&gt;สามารถใช้งานได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('953','Ticket','132','','0','Manassrisuksai Sutham (6)','2017-02-08 04:37:27','12','1','6');
INSERT INTO `glpi_logs` VALUES ('954','Ticket','132','','0','Manassrisuksai Sutham (6)','2017-02-08 04:37:27','16','','2017-02-08 04:37:27');
INSERT INTO `glpi_logs` VALUES ('955','Ticket','132','','0','Manassrisuksai Sutham (6)','2017-02-08 04:37:27','17','','2017-02-08 04:37:27');
INSERT INTO `glpi_logs` VALUES ('956','Ticket','133','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:37:57','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('957','Ticket','133','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:37:57','0','','');
INSERT INTO `glpi_logs` VALUES ('958','Ticket','133','','0','Manassrisuksai Sutham (6)','2017-02-08 04:38:49','24','','&lt;p&gt;หนูกัดสาย Adapter ห้องเก็บของแก้ไขแล้ว&lt;/p&gt;rn&lt;p&gt;ส่วนที่เหลือเป็นปัญหาสายสัยญาณ ส่งเรื่องให้ทางช่างดำเนินการแล้ว&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('959','Ticket','133','','0','Manassrisuksai Sutham (6)','2017-02-08 04:38:49','12','1','6');
INSERT INTO `glpi_logs` VALUES ('960','Ticket','133','','0','Manassrisuksai Sutham (6)','2017-02-08 04:38:49','16','','2017-02-08 04:38:49');
INSERT INTO `glpi_logs` VALUES ('961','Ticket','133','','0','Manassrisuksai Sutham (6)','2017-02-08 04:38:49','17','','2017-02-08 04:38:49');
INSERT INTO `glpi_logs` VALUES ('962','Ticket','134','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:39:59','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('963','Ticket','134','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:39:59','0','','');
INSERT INTO `glpi_logs` VALUES ('964','Ticket','134','','0','Manassrisuksai Sutham (6)','2017-02-08 04:40:20','24','','&lt;p&gt;ทำการ Reboot print Server &lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('965','Ticket','134','','0','Manassrisuksai Sutham (6)','2017-02-08 04:40:20','12','1','6');
INSERT INTO `glpi_logs` VALUES ('966','Ticket','134','','0','Manassrisuksai Sutham (6)','2017-02-08 04:40:20','16','','2017-02-08 04:40:20');
INSERT INTO `glpi_logs` VALUES ('967','Ticket','134','','0','Manassrisuksai Sutham (6)','2017-02-08 04:40:20','17','','2017-02-08 04:40:20');
INSERT INTO `glpi_logs` VALUES ('968','Ticket','135','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:41:18','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('969','Ticket','135','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:41:18','0','','');
INSERT INTO `glpi_logs` VALUES ('970','Ticket','135','','0','Manassrisuksai Sutham (6)','2017-02-08 04:41:37','24','','&lt;p&gt;ดำเนินการเปิดกล้องให้แล้วครับ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('971','Ticket','135','','0','Manassrisuksai Sutham (6)','2017-02-08 04:41:37','12','1','6');
INSERT INTO `glpi_logs` VALUES ('972','Ticket','135','','0','Manassrisuksai Sutham (6)','2017-02-08 04:41:37','16','','2017-02-08 04:41:37');
INSERT INTO `glpi_logs` VALUES ('973','Ticket','135','','0','Manassrisuksai Sutham (6)','2017-02-08 04:41:37','17','','2017-02-08 04:41:37');
INSERT INTO `glpi_logs` VALUES ('974','Ticket','136','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:42:08','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('975','Ticket','136','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:42:08','0','','');
INSERT INTO `glpi_logs` VALUES ('976','Ticket','136','','0','Manassrisuksai Sutham (6)','2017-02-08 04:42:31','24','','&lt;p&gt;ดำเนินการแก้ไขแล้วครับ&lt;/p&gt;rn&lt;p&gt;ลบและสร้าง Account ใหม่&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('977','Ticket','136','','0','Manassrisuksai Sutham (6)','2017-02-08 04:42:31','12','1','6');
INSERT INTO `glpi_logs` VALUES ('978','Ticket','136','','0','Manassrisuksai Sutham (6)','2017-02-08 04:42:31','16','','2017-02-08 04:42:31');
INSERT INTO `glpi_logs` VALUES ('979','Ticket','136','','0','Manassrisuksai Sutham (6)','2017-02-08 04:42:31','17','','2017-02-08 04:42:31');
INSERT INTO `glpi_logs` VALUES ('980','Ticket','137','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:43:02','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('981','Ticket','137','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:43:02','0','','');
INSERT INTO `glpi_logs` VALUES ('982','Ticket','137','','0','Manassrisuksai Sutham (6)','2017-02-08 04:43:25','24','','&lt;p&gt;ลบและสร้าง Account ใหม่&lt;/p&gt;rn&lt;p&gt;Guest สามารถใช้งานได้ปกติครับ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('983','Ticket','137','','0','Manassrisuksai Sutham (6)','2017-02-08 04:43:25','12','1','6');
INSERT INTO `glpi_logs` VALUES ('984','Ticket','137','','0','Manassrisuksai Sutham (6)','2017-02-08 04:43:25','16','','2017-02-08 04:43:25');
INSERT INTO `glpi_logs` VALUES ('985','Ticket','137','','0','Manassrisuksai Sutham (6)','2017-02-08 04:43:25','17','','2017-02-08 04:43:25');
INSERT INTO `glpi_logs` VALUES ('986','Ticket','138','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:44:10','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('987','Ticket','138','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:44:10','0','','');
INSERT INTO `glpi_logs` VALUES ('988','Ticket','138','','0','Manassrisuksai Sutham (6)','2017-02-08 04:44:46','24','','&lt;p&gt;เปลี่ยน Computer เครื่องใหม่ ไม่พบอาการผิดปกติแล้วครับ&lt;/p&gt;rn&lt;p&gt;สาเหตุมาจาก Port Serial เสีย&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('989','Ticket','138','','0','Manassrisuksai Sutham (6)','2017-02-08 04:44:46','12','1','6');
INSERT INTO `glpi_logs` VALUES ('990','Ticket','138','','0','Manassrisuksai Sutham (6)','2017-02-08 04:44:46','16','','2017-02-08 04:44:46');
INSERT INTO `glpi_logs` VALUES ('991','Ticket','138','','0','Manassrisuksai Sutham (6)','2017-02-08 04:44:46','17','','2017-02-08 04:44:46');
INSERT INTO `glpi_logs` VALUES ('992','Ticket','139','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:45:33','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('993','Ticket','139','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:45:33','0','','');
INSERT INTO `glpi_logs` VALUES ('994','Ticket','139','','0','Manassrisuksai Sutham (6)','2017-02-08 04:45:56','24','','&lt;p&gt;ทำการสร้าง Account ให้ใหม่ครับ&lt;/p&gt;rn&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('995','Ticket','139','','0','Manassrisuksai Sutham (6)','2017-02-08 04:45:56','12','1','6');
INSERT INTO `glpi_logs` VALUES ('996','Ticket','139','','0','Manassrisuksai Sutham (6)','2017-02-08 04:45:56','16','','2017-02-08 04:45:56');
INSERT INTO `glpi_logs` VALUES ('997','Ticket','139','','0','Manassrisuksai Sutham (6)','2017-02-08 04:45:56','17','','2017-02-08 04:45:56');
INSERT INTO `glpi_logs` VALUES ('998','Ticket','140','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:46:27','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('999','Ticket','140','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:46:27','0','','');
INSERT INTO `glpi_logs` VALUES ('1000','Ticket','140','','0','Manassrisuksai Sutham (6)','2017-02-08 04:47:51','24','','&lt;p&gt;136 ไฟ220 V สายขาด อันตรายไฟรั่วใต้ซิงค์นํ้า Pool Bar by the pool ปาล์มเล้าท์&lt;/p&gt;rn&lt;p&gt;135 Fino Adapter เสีย&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1001','Ticket','140','','0','Manassrisuksai Sutham (6)','2017-02-08 04:47:51','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1002','Ticket','140','','0','Manassrisuksai Sutham (6)','2017-02-08 04:47:51','16','','2017-02-08 04:47:51');
INSERT INTO `glpi_logs` VALUES ('1003','Ticket','140','','0','Manassrisuksai Sutham (6)','2017-02-08 04:47:51','17','','2017-02-08 04:47:51');
INSERT INTO `glpi_logs` VALUES ('1004','Ticket','141','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:49:48','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1005','Ticket','141','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:49:48','0','','');
INSERT INTO `glpi_logs` VALUES ('1006','Ticket','141','','0','Manassrisuksai Sutham (6)','2017-02-08 04:49:55','24','','&lt;p&gt;ซื้อสาย Adapter ไปเปลี่ยนให้แล้วครับ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1007','Ticket','141','','0','Manassrisuksai Sutham (6)','2017-02-08 04:49:55','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1008','Ticket','141','','0','Manassrisuksai Sutham (6)','2017-02-08 04:49:55','16','','2017-02-08 04:49:55');
INSERT INTO `glpi_logs` VALUES ('1009','Ticket','141','','0','Manassrisuksai Sutham (6)','2017-02-08 04:49:55','17','','2017-02-08 04:49:55');
INSERT INTO `glpi_logs` VALUES ('1010','Ticket','142','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:50:26','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1011','Ticket','142','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:50:26','0','','');
INSERT INTO `glpi_logs` VALUES ('1012','Ticket','142','','0','Manassrisuksai Sutham (6)','2017-02-08 04:51:13','24','','&lt;p&gt;DVR122 ไฟ11 V สายสัญญาณLose กล้องไม่ทำงาน&lt;/p&gt;rn&lt;p&gt;DVR131 Adapter หลวม&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1013','Ticket','142','','0','Manassrisuksai Sutham (6)','2017-02-08 04:51:13','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1014','Ticket','142','','0','Manassrisuksai Sutham (6)','2017-02-08 04:51:13','16','','2017-02-08 04:51:13');
INSERT INTO `glpi_logs` VALUES ('1015','Ticket','142','','0','Manassrisuksai Sutham (6)','2017-02-08 04:51:13','17','','2017-02-08 04:51:13');
INSERT INTO `glpi_logs` VALUES ('1016','Ticket','143','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:51:53','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1017','Ticket','143','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:51:53','0','','');
INSERT INTO `glpi_logs` VALUES ('1018','Ticket','143','','0','Manassrisuksai Sutham (6)','2017-02-08 04:52:42','24','','&lt;p&gt;CH 4 ต้นไม้บัง ให้คนสวนไปดำเนินการแล้ว&lt;/p&gt;rn&lt;p&gt;CH 5 ไม่มีไฟเลี้ยงกล้องสายขาดใน&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1019','Ticket','143','','0','Manassrisuksai Sutham (6)','2017-02-08 04:52:42','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1020','Ticket','143','','0','Manassrisuksai Sutham (6)','2017-02-08 04:52:42','16','','2017-02-08 04:52:42');
INSERT INTO `glpi_logs` VALUES ('1021','Ticket','143','','0','Manassrisuksai Sutham (6)','2017-02-08 04:52:42','17','','2017-02-08 04:52:42');
INSERT INTO `glpi_logs` VALUES ('1022','Ticket','144','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:53:25','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1023','Ticket','144','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:53:25','0','','');
INSERT INTO `glpi_logs` VALUES ('1024','Ticket','144','','0','Manassrisuksai Sutham (6)','2017-02-08 04:54:12','24','','&lt;p&gt;แจ้งทางคุณเพลง SUPPORT KASPERSKY THAILAND&lt;/p&gt;rn&lt;p&gt;Remote ติดตั้ง Antivirus ใน Server Domain เรียบร้อยแล้วครับ&lt;/p&gt;rn&lt;p&gt; &lt;/p&gt;rn&lt;p&gt; &lt;/p');
INSERT INTO `glpi_logs` VALUES ('1025','Ticket','144','','0','Manassrisuksai Sutham (6)','2017-02-08 04:54:12','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1026','Ticket','144','','0','Manassrisuksai Sutham (6)','2017-02-08 04:54:12','16','','2017-02-08 04:54:12');
INSERT INTO `glpi_logs` VALUES ('1027','Ticket','144','','0','Manassrisuksai Sutham (6)','2017-02-08 04:54:12','17','','2017-02-08 04:54:12');
INSERT INTO `glpi_logs` VALUES ('1028','Ticket','145','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:54:53','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1029','Ticket','145','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:54:53','0','','');
INSERT INTO `glpi_logs` VALUES ('1030','Ticket','145','','0','Manassrisuksai Sutham (6)','2017-02-08 04:55:40','24','','&lt;p&gt;ติดตั้งไดร์เวอร์เรียบร้อยแล้วครับ&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1031','Ticket','145','','0','Manassrisuksai Sutham (6)','2017-02-08 04:55:40','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1032','Ticket','145','','0','Manassrisuksai Sutham (6)','2017-02-08 04:55:40','16','','2017-02-08 04:55:40');
INSERT INTO `glpi_logs` VALUES ('1033','Ticket','145','','0','Manassrisuksai Sutham (6)','2017-02-08 04:55:40','17','','2017-02-08 04:55:40');
INSERT INTO `glpi_logs` VALUES ('1034','Ticket','146','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:56:44','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1035','Ticket','146','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:56:44','0','','');
INSERT INTO `glpi_logs` VALUES ('1036','Ticket','146','','0','Manassrisuksai Sutham (6)','2017-02-08 04:57:01','24','','&lt;p&gt;ดำเนินการเปลี่ยนเรียบร้อยแล้วครับ&lt;/p&gt;rn&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1037','Ticket','146','','0','Manassrisuksai Sutham (6)','2017-02-08 04:57:01','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1038','Ticket','146','','0','Manassrisuksai Sutham (6)','2017-02-08 04:57:01','16','','2017-02-08 04:57:01');
INSERT INTO `glpi_logs` VALUES ('1039','Ticket','146','','0','Manassrisuksai Sutham (6)','2017-02-08 04:57:01','17','','2017-02-08 04:57:01');
INSERT INTO `glpi_logs` VALUES ('1040','Ticket','147','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:57:40','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1041','Ticket','147','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:57:40','0','','');
INSERT INTO `glpi_logs` VALUES ('1042','Ticket','147','','0','Manassrisuksai Sutham (6)','2017-02-08 04:58:25','24','','&lt;p&gt;ดำเนินการกู้ไฟล์เรียบร้อยแล้วครับ&lt;/p&gt;rn&lt;p&gt;โดยดึงจาก App datalocal History&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1043','Ticket','147','','0','Manassrisuksai Sutham (6)','2017-02-08 04:58:25','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1044','Ticket','147','','0','Manassrisuksai Sutham (6)','2017-02-08 04:58:25','16','','2017-02-08 07:56:00');
INSERT INTO `glpi_logs` VALUES ('1045','Ticket','147','','0','Manassrisuksai Sutham (6)','2017-02-08 04:58:25','17','','2017-02-08 07:56:00');
INSERT INTO `glpi_logs` VALUES ('1046','Ticket','148','User','15','Manassrisuksai Sutham (6)','2017-02-08 04:59:11','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1047','Ticket','148','0','20','Manassrisuksai Sutham (6)','2017-02-08 04:59:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1048','Ticket','148','','0','Manassrisuksai Sutham (6)','2017-02-08 04:59:41','24','','&lt;p&gt;Server ShutDown ได้ให้คุณ Eban ช่วยดำเนินการเปิดเครื่องใหม่&lt;/p&gt;rn&lt;p&gt;ขณะนี้สามารถใช้งานได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1049','Ticket','148','','0','Manassrisuksai Sutham (6)','2017-02-08 04:59:41','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1050','Ticket','148','','0','Manassrisuksai Sutham (6)','2017-02-08 04:59:41','16','','2017-02-08 04:59:41');
INSERT INTO `glpi_logs` VALUES ('1051','Ticket','148','','0','Manassrisuksai Sutham (6)','2017-02-08 04:59:41','17','','2017-02-08 04:59:41');
INSERT INTO `glpi_logs` VALUES ('1052','Ticket','149','User','15','Manassrisuksai Sutham (6)','2017-02-08 05:00:29','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1053','Ticket','149','0','20','Manassrisuksai Sutham (6)','2017-02-08 05:00:29','0','','');
INSERT INTO `glpi_logs` VALUES ('1054','Ticket','149','','0','Manassrisuksai Sutham (6)','2017-02-08 05:00:56','24','','&lt;p&gt;UPS ดับอยุ่&lt;/p&gt;rn&lt;p&gt;ดำเนินการเปิดขึ้นมาใหม่&lt;/p&gt;rn&lt;p&gt;สามารถใช้งานได้ปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1055','Ticket','149','','0','Manassrisuksai Sutham (6)','2017-02-08 05:00:56','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1056','Ticket','149','','0','Manassrisuksai Sutham (6)','2017-02-08 05:00:56','16','','2017-02-08 10:59:00');
INSERT INTO `glpi_logs` VALUES ('1057','Ticket','149','','0','Manassrisuksai Sutham (6)','2017-02-08 05:00:56','17','','2017-02-08 10:59:00');
INSERT INTO `glpi_logs` VALUES ('1058','Ticket','150','User','15','dong (2)','2017-02-08 05:39:26','0','','dong (2)');
INSERT INTO `glpi_logs` VALUES ('1059','Ticket','150','','0','dong (2)','2017-02-08 05:39:26','150','0','1');
INSERT INTO `glpi_logs` VALUES ('1060','Ticket','150','User','15','dong (2)','2017-02-08 05:39:26','0','','dong (2)');
INSERT INTO `glpi_logs` VALUES ('1061','Ticket','150','0','20','dong (2)','2017-02-08 05:39:26','0','','');
INSERT INTO `glpi_logs` VALUES ('1062','Ticket','151','User','15','dong (2)','2017-02-08 05:40:10','0','','dong (2)');
INSERT INTO `glpi_logs` VALUES ('1063','Ticket','151','','0','dong (2)','2017-02-08 05:40:10','150','0','1');
INSERT INTO `glpi_logs` VALUES ('1064','Ticket','151','User','15','dong (2)','2017-02-08 05:40:10','0','','dong (2)');
INSERT INTO `glpi_logs` VALUES ('1065','Ticket','151','0','20','dong (2)','2017-02-08 05:40:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1066','Ticket','152','User','15','dong (2)','2017-02-08 05:41:08','0','','dong (2)');
INSERT INTO `glpi_logs` VALUES ('1067','Ticket','152','','0','dong (2)','2017-02-08 05:41:08','150','0','46');
INSERT INTO `glpi_logs` VALUES ('1068','Ticket','152','User','15','dong (2)','2017-02-08 05:41:08','0','','dong (2)');
INSERT INTO `glpi_logs` VALUES ('1069','Ticket','152','0','20','dong (2)','2017-02-08 05:41:08','0','','');
INSERT INTO `glpi_logs` VALUES ('1070','Ticket','152','User','15','dong (2)','2017-02-08 05:41:46','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1071','Ticket','152','','0','dong (2)','2017-02-08 05:41:46','21','ติดตั้ง Note Book และ Projector ห้องประชุมเล็ก วันที่ 13-2-60 ก่อน10โมง
ส่งเมลแจ้งกลับด้วย','ติดตั้ง Note Book และ Projector ห้องประชุมเล็ก วันที่ 13-2-60 ก่อน10โมงrnส่งเมลแจ้งกลับด้วย');
INSERT INTO `glpi_logs` VALUES ('1072','Ticket','151','User','15','dong (2)','2017-02-08 05:42:01','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1073','Ticket','151','','0','dong (2)','2017-02-08 05:42:01','21','ติดตั้งเครื่องปริ้น KC BY THE SEA
พี่หญิงขอตัวใหม่ติดตั้ง','ติดตั้งเครื่องปริ้น KC BY THE SEArnพี่หญิงขอตัวใหม่ติดตั้ง');
INSERT INTO `glpi_logs` VALUES ('1074','Ticket','150','User','15','dong (2)','2017-02-08 05:42:13','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1075','Ticket','150','','0','Manassrisuksai Sutham (6)','2017-02-10 09:08:43','24','','&lt;p&gt;ดำเนินการเปลี่ยนเรียบร้อยแล้วครับ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1076','Ticket','150','','0','Manassrisuksai Sutham (6)','2017-02-10 09:08:43','64','dong (2)','sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1077','Ticket','150','','0','Manassrisuksai Sutham (6)','2017-02-10 09:08:43','12','2','6');
INSERT INTO `glpi_logs` VALUES ('1078','Ticket','150','','0','Manassrisuksai Sutham (6)','2017-02-10 09:08:43','16','','2017-02-10 09:08:43');
INSERT INTO `glpi_logs` VALUES ('1079','Ticket','150','','0','Manassrisuksai Sutham (6)','2017-02-10 09:08:43','17','','2017-02-10 09:08:43');
INSERT INTO `glpi_logs` VALUES ('1080','Ticket','153','User','15','Manassrisuksai Sutham (6)','2017-02-10 09:10:09','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1081','Ticket','153','0','20','Manassrisuksai Sutham (6)','2017-02-10 09:10:09','0','','');
INSERT INTO `glpi_logs` VALUES ('1082','Ticket','154','User','15','Manassrisuksai Sutham (6)','2017-02-10 09:11:06','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1083','Ticket','154','0','20','Manassrisuksai Sutham (6)','2017-02-10 09:11:06','0','','');
INSERT INTO `glpi_logs` VALUES ('1084','Ticket','153','','0','Manassrisuksai Sutham (6)','2017-02-10 09:11:29','24','','&lt;p&gt;ดำเนินการเรียบร้อยแล้วครับ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1085','Ticket','153','','0','Manassrisuksai Sutham (6)','2017-02-10 09:11:29','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1086','Ticket','153','','0','Manassrisuksai Sutham (6)','2017-02-10 09:11:29','16','','2017-02-10 09:11:29');
INSERT INTO `glpi_logs` VALUES ('1087','Ticket','153','','0','Manassrisuksai Sutham (6)','2017-02-10 09:11:29','17','','2017-02-10 09:11:29');
INSERT INTO `glpi_logs` VALUES ('1088','Ticket','154','','0','Manassrisuksai Sutham (6)','2017-02-10 09:11:40','24','','&lt;p&gt;หนูกัดสาย Lan&lt;/p&gt;rn&lt;p&gt;ดำเนินการเรียบร้อยแล้วครับ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1089','Ticket','154','','0','Manassrisuksai Sutham (6)','2017-02-10 09:11:40','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1090','Ticket','154','','0','Manassrisuksai Sutham (6)','2017-02-10 09:11:40','16','','2017-02-10 14:10:00');
INSERT INTO `glpi_logs` VALUES ('1091','Ticket','154','','0','Manassrisuksai Sutham (6)','2017-02-10 09:11:40','17','','2017-02-10 14:10:00');
INSERT INTO `glpi_logs` VALUES ('1092','Ticket','155','User','15','Manassrisuksai Sutham (6)','2017-02-10 09:14:16','0','','Manassrisuksai Sutham (6)');
INSERT INTO `glpi_logs` VALUES ('1093','Ticket','155','0','20','Manassrisuksai Sutham (6)','2017-02-10 09:14:16','0','','');
INSERT INTO `glpi_logs` VALUES ('1094','Ticket','155','','0','Manassrisuksai Sutham (6)','2017-02-10 09:14:45','24','','&lt;p&gt;ย้ายฐานข้อมูลภาษีจาก59ไป60&lt;/p&gt;rn&lt;p&gt;Run administrator Program&lt;/p&gt;rn&lt;p&gt;ข๊ะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1095','Ticket','155','','0','Manassrisuksai Sutham (6)','2017-02-10 09:14:45','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1096','Ticket','155','','0','Manassrisuksai Sutham (6)','2017-02-10 09:14:45','16','','2017-02-10 09:14:45');
INSERT INTO `glpi_logs` VALUES ('1097','Ticket','155','','0','Manassrisuksai Sutham (6)','2017-02-10 09:14:45','17','','2017-02-10 09:14:45');

### Dump table glpi_mailcollectors

DROP TABLE IF EXISTS `glpi_mailcollectors`;
CREATE TABLE `glpi_mailcollectors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize_max` int(11) NOT NULL DEFAULT '2097152',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accepted` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `refused` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_kerberos` tinyint(1) NOT NULL DEFAULT '0',
  `errors` int(11) NOT NULL DEFAULT '0',
  `use_mail_date` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_manufacturers

DROP TABLE IF EXISTS `glpi_manufacturers`;
CREATE TABLE `glpi_manufacturers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitormodels

DROP TABLE IF EXISTS `glpi_monitormodels`;
CREATE TABLE `glpi_monitormodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitors

DROP TABLE IF EXISTS `glpi_monitors`;
CREATE TABLE `glpi_monitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT '0',
  `have_micro` tinyint(1) NOT NULL DEFAULT '0',
  `have_speaker` tinyint(1) NOT NULL DEFAULT '0',
  `have_subd` tinyint(1) NOT NULL DEFAULT '0',
  `have_bnc` tinyint(1) NOT NULL DEFAULT '0',
  `have_dvi` tinyint(1) NOT NULL DEFAULT '0',
  `have_pivot` tinyint(1) NOT NULL DEFAULT '0',
  `have_hdmi` tinyint(1) NOT NULL DEFAULT '0',
  `have_displayport` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `monitortypes_id` int(11) NOT NULL DEFAULT '0',
  `monitormodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `monitormodels_id` (`monitormodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `monitortypes_id` (`monitortypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitortypes

DROP TABLE IF EXISTS `glpi_monitortypes`;
CREATE TABLE `glpi_monitortypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_netpoints

DROP TABLE IF EXISTS `glpi_netpoints`;
CREATE TABLE `glpi_netpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `complete` (`entities_id`,`locations_id`,`name`),
  KEY `location_name` (`locations_id`,`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkaliases

DROP TABLE IF EXISTS `glpi_networkaliases`;
CREATE TABLE `glpi_networkaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `networknames_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `networknames_id` (`networknames_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmentfirmwares

DROP TABLE IF EXISTS `glpi_networkequipmentfirmwares`;
CREATE TABLE `glpi_networkequipmentfirmwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmentmodels

DROP TABLE IF EXISTS `glpi_networkequipmentmodels`;
CREATE TABLE `glpi_networkequipmentmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipments

DROP TABLE IF EXISTS `glpi_networkequipments`;
CREATE TABLE `glpi_networkequipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmenttypes_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmentmodels_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmentfirmwares_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `domains_id` (`domains_id`),
  KEY `networkequipmentfirmwares_id` (`networkequipmentfirmwares_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `networkequipmentmodels_id` (`networkequipmentmodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `networkequipmenttypes_id` (`networkequipmenttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmenttypes

DROP TABLE IF EXISTS `glpi_networkequipmenttypes`;
CREATE TABLE `glpi_networkequipmenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkinterfaces

DROP TABLE IF EXISTS `glpi_networkinterfaces`;
CREATE TABLE `glpi_networkinterfaces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networknames

DROP TABLE IF EXISTS `glpi_networknames`;
CREATE TABLE `glpi_networknames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `FQDN` (`name`,`fqdns_id`),
  KEY `name` (`name`),
  KEY `fqdns_id` (`fqdns_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportaggregates

DROP TABLE IF EXISTS `glpi_networkportaggregates`;
CREATE TABLE `glpi_networkportaggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_list` text COLLATE utf8_unicode_ci COMMENT 'array of associated networkports_id',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportaliases

DROP TABLE IF EXISTS `glpi_networkportaliases`;
CREATE TABLE `glpi_networkportaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_alias` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `networkports_id_alias` (`networkports_id_alias`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportdialups

DROP TABLE IF EXISTS `glpi_networkportdialups`;
CREATE TABLE `glpi_networkportdialups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportethernets

DROP TABLE IF EXISTS `glpi_networkportethernets`;
CREATE TABLE `glpi_networkportethernets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'T, LX, SX',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `type` (`type`),
  KEY `speed` (`speed`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportfiberchannels

DROP TABLE IF EXISTS `glpi_networkportfiberchannels`;
CREATE TABLE `glpi_networkportfiberchannels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `wwn` varchar(16) COLLATE utf8_unicode_ci DEFAULT '',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `wwn` (`wwn`),
  KEY `speed` (`speed`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportlocals

DROP TABLE IF EXISTS `glpi_networkportlocals`;
CREATE TABLE `glpi_networkportlocals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports

DROP TABLE IF EXISTS `glpi_networkports`;
CREATE TABLE `glpi_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `logical_number` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `instantiation_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `on_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `mac` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports_networkports

DROP TABLE IF EXISTS `glpi_networkports_networkports`;
CREATE TABLE `glpi_networkports_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id_1` int(11) NOT NULL DEFAULT '0',
  `networkports_id_2` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id_1`,`networkports_id_2`),
  KEY `networkports_id_2` (`networkports_id_2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports_vlans

DROP TABLE IF EXISTS `glpi_networkports_vlans`;
CREATE TABLE `glpi_networkports_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  `tagged` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id`,`vlans_id`),
  KEY `vlans_id` (`vlans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportwifis

DROP TABLE IF EXISTS `glpi_networkportwifis`;
CREATE TABLE `glpi_networkportwifis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `wifinetworks_id` int(11) NOT NULL DEFAULT '0',
  `networkportwifis_id` int(11) NOT NULL DEFAULT '0' COMMENT 'only useful in case of Managed node',
  `version` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'a, a/b, a/b/g, a/b/g/n, a/b/g/n/y',
  `mode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ad-hoc, managed, master, repeater, secondary, monitor, auto',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `essid` (`wifinetworks_id`),
  KEY `version` (`version`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networks

DROP TABLE IF EXISTS `glpi_networks`;
CREATE TABLE `glpi_networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_notepads

DROP TABLE IF EXISTS `glpi_notepads`;
CREATE TABLE `glpi_notepads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date` (`date`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_notifications

DROP TABLE IF EXISTS `glpi_notifications`;
CREATE TABLE `glpi_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `event` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `is_recursive` (`is_recursive`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notifications` VALUES ('1','Alert Tickets not closed','0','Ticket','alertnotclosed','mail','6','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('2','New Ticket','0','Ticket','new','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('3','Update Ticket','0','Ticket','update','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('4','Close Ticket','0','Ticket','closed','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('5','Add Followup','0','Ticket','add_followup','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('6','Add Task','0','Ticket','add_task','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('7','Update Followup','0','Ticket','update_followup','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('8','Update Task','0','Ticket','update_task','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('9','Delete Followup','0','Ticket','delete_followup','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('10','Delete Task','0','Ticket','delete_task','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('11','Resolve ticket','0','Ticket','solved','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('12','Ticket Validation','0','Ticket','validation','mail','7','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('13','New Reservation','0','Reservation','new','mail','2','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('14','Update Reservation','0','Reservation','update','mail','2','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('15','Delete Reservation','0','Reservation','delete','mail','2','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('16','Alert Reservation','0','Reservation','alert','mail','3','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('17','Contract Notice','0','Contract','notice','mail','12','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('18','Contract End','0','Contract','end','mail','12','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('19','MySQL Synchronization','0','DBConnection','desynchronization','mail','1','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('20','Cartridges','0','CartridgeItem','alert','mail','8','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('21','Consumables','0','ConsumableItem','alert','mail','9','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('22','Infocoms','0','Infocom','alert','mail','10','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('23','Software Licenses','0','SoftwareLicense','alert','mail','11','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('24','Ticket Recall','0','Ticket','recall','mail','4','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('25','Password Forget','0','User','passwordforget','mail','13','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('26','Ticket Satisfaction','0','Ticket','satisfaction','mail','14','','1','1','2011-03-04 11:35:15',NULL);
INSERT INTO `glpi_notifications` VALUES ('27','Item not unique','0','FieldUnicity','refuse','mail','15','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('28','Crontask Watcher','0','Crontask','alert','mail','16','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('29','New Problem','0','Problem','new','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('30','Update Problem','0','Problem','update','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('31','Resolve Problem','0','Problem','solved','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('32','Add Task','0','Problem','add_task','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('33','Update Task','0','Problem','update_task','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('34','Delete Task','0','Problem','delete_task','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('35','Close Problem','0','Problem','closed','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('36','Delete Problem','0','Problem','delete','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('37','Ticket Validation Answer','0','Ticket','validation_answer','mail','7','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('38','Contract End Periodicity','0','Contract','periodicity','mail','12','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('39','Contract Notice Periodicity','0','Contract','periodicitynotice','mail','12','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('40','Planning recall','0','PlanningRecall','planningrecall','mail','18','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('41','Delete Ticket','0','Ticket','delete','mail','4','','1','1','2014-01-15 14:35:26',NULL);
INSERT INTO `glpi_notifications` VALUES ('42','New Change','0','Change','new','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('43','Update Change','0','Change','update','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('44','Resolve Change','0','Change','solved','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('45','Add Task','0','Change','add_task','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('46','Update Task','0','Change','update_task','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('47','Delete Task','0','Change','delete_task','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('48','Close Change','0','Change','closed','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('49','Delete Change','0','Change','delete','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('50','Ticket Satisfaction Answer','0','Ticket','replysatisfaction','mail','14','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('51','Receiver errors','0','MailCollector','error','mail','20','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('52','New Project','0','Project','new','mail','21','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('53','Update Project','0','Project','update','mail','21','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('54','Delete Project','0','Project','delete','mail','21','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('55','New Project Task','0','ProjectTask','new','mail','22','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('56','Update Project Task','0','ProjectTask','update','mail','22','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('57','Delete Project Task','0','ProjectTask','delete','mail','22','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('58','Request Unlock Items','0','ObjectLock','unlock','mail','23','','1','1','2016-02-08 16:57:46',NULL);

### Dump table glpi_notificationtargets

DROP TABLE IF EXISTS `glpi_notificationtargets`;
CREATE TABLE `glpi_notificationtargets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `notifications_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `items` (`type`,`items_id`),
  KEY `notifications_id` (`notifications_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtargets` VALUES ('1','3','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('2','1','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('3','3','2','2');
INSERT INTO `glpi_notificationtargets` VALUES ('4','1','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('5','1','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('6','1','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('7','1','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('8','2','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('9','4','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('10','3','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('11','3','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('12','3','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('13','3','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('14','1','1','19');
INSERT INTO `glpi_notificationtargets` VALUES ('15','14','1','12');
INSERT INTO `glpi_notificationtargets` VALUES ('16','3','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('17','1','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('18','3','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('19','1','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('20','1','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('21','3','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('22','1','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('23','3','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('24','1','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('25','3','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('26','1','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('27','3','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('28','1','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('29','3','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('30','1','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('31','3','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('32','19','1','25');
INSERT INTO `glpi_notificationtargets` VALUES ('33','3','1','26');
INSERT INTO `glpi_notificationtargets` VALUES ('34','21','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('35','21','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('36','21','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('37','21','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('38','21','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('39','21','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('40','21','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('41','21','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('42','21','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('43','21','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('75','1','1','41');
INSERT INTO `glpi_notificationtargets` VALUES ('46','1','1','28');
INSERT INTO `glpi_notificationtargets` VALUES ('47','3','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('48','1','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('49','21','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('50','2','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('51','4','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('52','3','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('53','1','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('54','21','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('55','3','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('56','1','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('57','21','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('58','3','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('59','1','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('60','21','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('61','3','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('62','1','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('63','21','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('64','3','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('65','1','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('66','21','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('67','3','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('68','1','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('69','21','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('70','3','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('71','1','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('72','21','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('73','14','1','37');
INSERT INTO `glpi_notificationtargets` VALUES ('74','3','1','40');
INSERT INTO `glpi_notificationtargets` VALUES ('76','3','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('77','1','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('78','21','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('79','2','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('80','4','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('81','3','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('82','1','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('83','21','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('84','3','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('85','1','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('86','21','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('87','3','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('88','1','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('89','21','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('90','3','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('91','1','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('92','21','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('93','3','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('94','1','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('95','21','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('96','3','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('97','1','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('98','21','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('99','3','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('100','1','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('101','21','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('102','3','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('103','2','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('104','1','1','51');
INSERT INTO `glpi_notificationtargets` VALUES ('105','27','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('106','1','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('107','28','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('108','27','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('109','1','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('110','28','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('111','27','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('112','1','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('113','28','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('114','31','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('115','1','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('116','32','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('117','31','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('118','1','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('119','32','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('120','31','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('121','1','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('122','32','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('123','19','1','58');

### Dump table glpi_notificationtemplates

DROP TABLE IF EXISTS `glpi_notificationtemplates`;
CREATE TABLE `glpi_notificationtemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `css` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `itemtype` (`itemtype`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplates` VALUES ('1','MySQL Synchronization','DBConnection','2010-02-01 15:51:46','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('2','Reservations','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('3','Alert Reservation','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('4','Tickets','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('5','Tickets (Simple)','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('6','Alert Tickets not closed','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('7','Tickets Validation','Ticket','2010-02-26 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('8','Cartridges','CartridgeItem','2010-02-16 13:17:24','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('9','Consumables','ConsumableItem','2010-02-16 13:17:38','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('10','Infocoms','Infocom','2010-02-16 13:17:55','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('11','Licenses','SoftwareLicense','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('12','Contracts','Contract','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('13','Password Forget','User','2011-03-04 11:35:13',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('14','Ticket Satisfaction','Ticket','2011-03-04 11:35:15',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('15','Item not unique','FieldUnicity','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('16','Crontask','Crontask','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('17','Problems','Problem','2011-12-06 09:48:33',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('18','Planning recall','PlanningRecall','2014-01-15 14:35:24',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('19','Changes','Change','2014-06-18 08:02:07',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('20','Receiver errors','MailCollector','2014-06-18 08:02:08',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('21','Projects','Project','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('22','Project Tasks','ProjectTask','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('23','Unlock Item request','ObjectLock','2016-02-08 16:57:46',NULL,NULL,NULL);

### Dump table glpi_notificationtemplatetranslations

DROP TABLE IF EXISTS `glpi_notificationtemplatetranslations`;
CREATE TABLE `glpi_notificationtemplatetranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `language` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_text` text COLLATE utf8_unicode_ci,
  `content_html` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('1','1','','##lang.dbconnection.title##','##lang.dbconnection.delay## : ##dbconnection.delay##
','&lt;p&gt;##lang.dbconnection.delay## : ##dbconnection.delay##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('2','2','','##reservation.action##','======================================================================
##lang.reservation.user##: ##reservation.user##
##lang.reservation.item.name##: ##reservation.itemtype## - ##reservation.item.name##
##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech## ##ENDIFreservation.tech##
##lang.reservation.begin##: ##reservation.begin##
##lang.reservation.end##: ##reservation.end##
##lang.reservation.comment##: ##reservation.comment##
======================================================================
','&lt;!-- description{ color: inherit; background: #ebebeb;border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; } --&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.user##:&lt;/span&gt;##reservation.user##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.item.name##:&lt;/span&gt;##reservation.itemtype## - ##reservation.item.name##&lt;br /&gt;##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech####ENDIFreservation.tech##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.begin##:&lt;/span&gt; ##reservation.begin##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.end##:&lt;/span&gt;##reservation.end##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.comment##:&lt;/span&gt; ##reservation.comment##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('3','3','','##reservation.action##  ##reservation.entity##','##lang.reservation.entity## : ##reservation.entity##


##FOREACHreservations##
##lang.reservation.itemtype## : ##reservation.itemtype##

 ##lang.reservation.item## : ##reservation.item##

 ##reservation.url##

 ##ENDFOREACHreservations##','&lt;p&gt;##lang.reservation.entity## : ##reservation.entity## &lt;br /&gt; &lt;br /&gt;
##FOREACHreservations## &lt;br /&gt;##lang.reservation.itemtype## :  ##reservation.itemtype##&lt;br /&gt;
 ##lang.reservation.item## :  ##reservation.item##&lt;br /&gt; &lt;br /&gt;
 &lt;a href=\"##reservation.url##\"&gt; ##reservation.url##&lt;/a&gt;&lt;br /&gt;
 ##ENDFOREACHreservations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('4','4','','##ticket.action## ##ticket.title##',' ##IFticket.storestatus=5##
 ##lang.ticket.url## : ##ticket.urlapprove##
 ##lang.ticket.autoclosewarning##
 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description## ##ENDIFticket.storestatus##
 ##ELSEticket.storestatus## ##lang.ticket.url## : ##ticket.url## ##ENDELSEticket.storestatus##

 ##lang.ticket.description##

 ##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.authors## : ##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors## ##ELSEticket.authors##--##ENDELSEticket.authors##
 ##lang.ticket.creationdate## : ##ticket.creationdate##
 ##lang.ticket.closedate## : ##ticket.closedate##
 ##lang.ticket.requesttype## : ##ticket.requesttype##
##lang.ticket.item.name## :

##FOREACHitems##

 ##IFticket.itemtype##
  ##ticket.itemtype## - ##ticket.item.name##
  ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model##
  ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial##
  ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial##
 ##ENDIFticket.itemtype##

##ENDFOREACHitems##
##IFticket.assigntousers## ##lang.ticket.assigntousers## : ##ticket.assigntousers## ##ENDIFticket.assigntousers##
 ##lang.ticket.status## : ##ticket.status##
##IFticket.assigntogroups## ##lang.ticket.assigntogroups## : ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##
 ##lang.ticket.urgency## : ##ticket.urgency##
 ##lang.ticket.impact## : ##ticket.impact##
 ##lang.ticket.priority## : ##ticket.priority##
##IFticket.user.email## ##lang.ticket.user.email## : ##ticket.user.email ##ENDIFticket.user.email##
##IFticket.category## ##lang.ticket.category## : ##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
 ##lang.ticket.content## : ##ticket.content##
 ##IFticket.storestatus=6##

 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description##
 ##ENDIFticket.storestatus##
 ##lang.ticket.numberoffollowups## : ##ticket.numberoffollowups##

##FOREACHfollowups##

 [##followup.date##] ##lang.followup.isprivate## : ##followup.isprivate##
 ##lang.followup.author## ##followup.author##
 ##lang.followup.description## ##followup.description##
 ##lang.followup.date## ##followup.date##
 ##lang.followup.requesttype## ##followup.requesttype##

##ENDFOREACHfollowups##
 ##lang.ticket.numberoftasks## : ##ticket.numberoftasks##

##FOREACHtasks##

 [##task.date##] ##lang.task.isprivate## : ##task.isprivate##
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##','<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div>##IFticket.storestatus=5##</div>
<div>##lang.ticket.url## : <a href=\"##ticket.urlapprove##\">##ticket.urlapprove##</a> <strong>&#160;</strong></div>
<div><strong>##lang.ticket.autoclosewarning##</strong></div>
<div><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.type##</strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description## ##ENDIFticket.storestatus##</div>
<div>##ELSEticket.storestatus## ##lang.ticket.url## : <a href=\"##ticket.url##\">##ticket.url##</a> ##ENDELSEticket.storestatus##</div>
<p class=\"description b\"><strong>##lang.ticket.description##</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.title##</span>&#160;:##ticket.title## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.authors##</span>&#160;:##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors##    ##ELSEticket.authors##--##ENDELSEticket.authors## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.creationdate##</span>&#160;:##ticket.creationdate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.closedate##</span>&#160;:##ticket.closedate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.requesttype##</span>&#160;:##ticket.requesttype##<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.item.name##</span>&#160;:
<p>##FOREACHitems##</p>
<div class=\"description b\">##IFticket.itemtype## ##ticket.itemtype##&#160;- ##ticket.item.name## ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model## ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial## ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial## ##ENDIFticket.itemtype## </div><br />
<p>##ENDFOREACHitems##</p>
##IFticket.assigntousers## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntousers##</span>&#160;: ##ticket.assigntousers## ##ENDIFticket.assigntousers##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.status## </span>&#160;: ##ticket.status##<br /> ##IFticket.assigntogroups## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntogroups##</span>&#160;: ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.urgency##</span>&#160;: ##ticket.urgency##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.impact##</span>&#160;: ##ticket.impact##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.priority##</span>&#160;: ##ticket.priority## <br /> ##IFticket.user.email##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.user.email##</span>&#160;: ##ticket.user.email ##ENDIFticket.user.email##    <br /> ##IFticket.category##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.category## </span>&#160;:##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##    <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.content##</span>&#160;: ##ticket.content##</p>
<br />##IFticket.storestatus=6##<br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solution.type##</span></strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description##<br />##ENDIFticket.storestatus##</p>
<div class=\"description b\">##lang.ticket.numberoffollowups##&#160;: ##ticket.numberoffollowups##</div>
<p>##FOREACHfollowups##</p>
<div class=\"description b\"><br /> <strong> [##followup.date##] <em>##lang.followup.isprivate## : ##followup.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.author## </span> ##followup.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.description## </span> ##followup.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.date## </span> ##followup.date##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.requesttype## </span> ##followup.requesttype##</div>
<p>##ENDFOREACHfollowups##</p>
<div class=\"description b\">##lang.ticket.numberoftasks##&#160;: ##ticket.numberoftasks##</div>
<p>##FOREACHtasks##</p>
<div class=\"description b\"><br /> <strong> [##task.date##] <em>##lang.task.isprivate## : ##task.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.author##</span> ##task.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.description##</span> ##task.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.time##</span> ##task.time##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.category##</span> ##task.category##</div>
<p>##ENDFOREACHtasks##</p>');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('5','12','','##contract.action##  ##contract.entity##','##lang.contract.entity## : ##contract.entity##

##FOREACHcontracts##
##lang.contract.name## : ##contract.name##
##lang.contract.number## : ##contract.number##
##lang.contract.time## : ##contract.time##
##IFcontract.type####lang.contract.type## : ##contract.type####ENDIFcontract.type##
##contract.url##
##ENDFOREACHcontracts##','&lt;p&gt;##lang.contract.entity## : ##contract.entity##&lt;br /&gt;
&lt;br /&gt;##FOREACHcontracts##&lt;br /&gt;##lang.contract.name## :
##contract.name##&lt;br /&gt;
##lang.contract.number## : ##contract.number##&lt;br /&gt;
##lang.contract.time## : ##contract.time##&lt;br /&gt;
##IFcontract.type####lang.contract.type## : ##contract.type##
##ENDIFcontract.type##&lt;br /&gt;
&lt;a href=\"##contract.url##\"&gt;
##contract.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcontracts##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('6','5','','##ticket.action## ##ticket.title##','##lang.ticket.url## : ##ticket.url##

##lang.ticket.description##


##lang.ticket.title##  :##ticket.title##

##lang.ticket.authors##  :##IFticket.authors##
##ticket.authors## ##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##

##IFticket.category## ##lang.ticket.category##  :##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##

##lang.ticket.content##  : ##ticket.content##
##IFticket.itemtype##
##lang.ticket.item.name##  : ##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##','&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.url##\"&gt;
##ticket.url##&lt;/a&gt;&lt;/div&gt;
&lt;div class=\"description b\"&gt;
##lang.ticket.description##&lt;/div&gt;
&lt;p&gt;&lt;span
style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.title##&lt;/span&gt;&#160;:##ticket.title##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.authors##&lt;/span&gt;
##IFticket.authors## ##ticket.authors##
##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;&#160
;&lt;/span&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;
##IFticket.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.category## &lt;/span&gt;&#160;:##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.content##&lt;/span&gt;&#160;:
##ticket.content##&lt;br /&gt;##IFticket.itemtype##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.item.name##&lt;/span&gt;&#160;:
##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('15','15','','##lang.unicity.action##','##lang.unicity.entity## : ##unicity.entity##

##lang.unicity.itemtype## : ##unicity.itemtype##

##lang.unicity.message## : ##unicity.message##

##lang.unicity.action_user## : ##unicity.action_user##

##lang.unicity.action_type## : ##unicity.action_type##

##lang.unicity.date## : ##unicity.date##','&lt;p&gt;##lang.unicity.entity## : ##unicity.entity##&lt;/p&gt;
&lt;p&gt;##lang.unicity.itemtype## : ##unicity.itemtype##&lt;/p&gt;
&lt;p&gt;##lang.unicity.message## : ##unicity.message##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_user## : ##unicity.action_user##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_type## : ##unicity.action_type##&lt;/p&gt;
&lt;p&gt;##lang.unicity.date## : ##unicity.date##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('7','7','','##ticket.action## ##ticket.title##','##FOREACHvalidations##

##IFvalidation.storestatus=2##
##validation.submission.title##
##lang.validation.commentsubmission## : ##validation.commentsubmission##
##ENDIFvalidation.storestatus##
##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##

##lang.ticket.url## : ##ticket.urlvalidation##

##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
##IFvalidation.commentvalidation##
##lang.validation.commentvalidation## : ##validation.commentvalidation##
##ENDIFvalidation.commentvalidation##
##ENDFOREACHvalidations##','&lt;div&gt;##FOREACHvalidations##&lt;/div&gt;
&lt;p&gt;##IFvalidation.storestatus=2##&lt;/p&gt;
&lt;div&gt;##validation.submission.title##&lt;/div&gt;
&lt;div&gt;##lang.validation.commentsubmission## : ##validation.commentsubmission##&lt;/div&gt;
&lt;div&gt;##ENDIFvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;&lt;/div&gt;
&lt;div&gt;
&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.urlvalidation##\"&gt; ##ticket.urlvalidation## &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;p&gt;##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
&lt;br /&gt; ##IFvalidation.commentvalidation##&lt;br /&gt; ##lang.validation.commentvalidation## :
&#160; ##validation.commentvalidation##&lt;br /&gt; ##ENDIFvalidation.commentvalidation##
&lt;br /&gt;##ENDFOREACHvalidations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('8','6','','##ticket.action## ##ticket.entity##','##lang.ticket.entity## : ##ticket.entity##

##FOREACHtickets##

##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.status## : ##ticket.status##

 ##ticket.url##
 ##ENDFOREACHtickets##','&lt;table class=\"tab_cadre\" border=\"1\" cellspacing=\"2\" cellpadding=\"3\"&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.title##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.attribution##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##FOREACHtickets##
&lt;tr&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;&lt;a href=\"##ticket.url##\"&gt;##ticket.title##&lt;/a&gt;&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##IFticket.assigntousers####ticket.assigntousers##&lt;br /&gt;##ENDIFticket.assigntousers####IFticket.assigntogroups##&lt;br /&gt;##ticket.assigntogroups## ##ENDIFticket.assigntogroups####IFticket.assigntosupplier##&lt;br /&gt;##ticket.assigntosupplier## ##ENDIFticket.assigntosupplier##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##ENDFOREACHtickets##
&lt;/tbody&gt;
&lt;/table&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('9','9','','##consumable.action##  ##consumable.entity##','##lang.consumable.entity## : ##consumable.entity##


##FOREACHconsumables##
##lang.consumable.item## : ##consumable.item##


##lang.consumable.reference## : ##consumable.reference##

##lang.consumable.remaining## : ##consumable.remaining##

##consumable.url##

##ENDFOREACHconsumables##','&lt;p&gt;
##lang.consumable.entity## : ##consumable.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHconsumables##
&lt;br /&gt;##lang.consumable.item## : ##consumable.item##&lt;br /&gt;
&lt;br /&gt;##lang.consumable.reference## : ##consumable.reference##&lt;br /&gt;
##lang.consumable.remaining## : ##consumable.remaining##&lt;br /&gt;
&lt;a href=\"##consumable.url##\"&gt; ##consumable.url##&lt;/a&gt;&lt;br /&gt;
   ##ENDFOREACHconsumables##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('10','8','','##cartridge.action##  ##cartridge.entity##','##lang.cartridge.entity## : ##cartridge.entity##


##FOREACHcartridges##
##lang.cartridge.item## : ##cartridge.item##


##lang.cartridge.reference## : ##cartridge.reference##

##lang.cartridge.remaining## : ##cartridge.remaining##

##cartridge.url##
 ##ENDFOREACHcartridges##','&lt;p&gt;##lang.cartridge.entity## : ##cartridge.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHcartridges##
&lt;br /&gt;##lang.cartridge.item## :
##cartridge.item##&lt;br /&gt; &lt;br /&gt;
##lang.cartridge.reference## :
##cartridge.reference##&lt;br /&gt;
##lang.cartridge.remaining## :
##cartridge.remaining##&lt;br /&gt;
&lt;a href=\"##cartridge.url##\"&gt;
##cartridge.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcartridges##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('11','10','','##infocom.action##  ##infocom.entity##','##lang.infocom.entity## : ##infocom.entity##


##FOREACHinfocoms##

##lang.infocom.itemtype## : ##infocom.itemtype##

##lang.infocom.item## : ##infocom.item##


##lang.infocom.expirationdate## : ##infocom.expirationdate##

##infocom.url##
 ##ENDFOREACHinfocoms##','&lt;p&gt;##lang.infocom.entity## : ##infocom.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHinfocoms##
&lt;br /&gt;##lang.infocom.itemtype## : ##infocom.itemtype##&lt;br /&gt;
##lang.infocom.item## : ##infocom.item##&lt;br /&gt; &lt;br /&gt;
##lang.infocom.expirationdate## : ##infocom.expirationdate##
&lt;br /&gt; &lt;a href=\"##infocom.url##\"&gt;
##infocom.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHinfocoms##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('12','11','','##license.action##  ##license.entity##','##lang.license.entity## : ##license.entity##

##FOREACHlicenses##

##lang.license.item## : ##license.item##

##lang.license.serial## : ##license.serial##

##lang.license.expirationdate## : ##license.expirationdate##

##license.url##
 ##ENDFOREACHlicenses##','&lt;p&gt;
##lang.license.entity## : ##license.entity##&lt;br /&gt;
##FOREACHlicenses##
&lt;br /&gt;##lang.license.item## : ##license.item##&lt;br /&gt;
##lang.license.serial## : ##license.serial##&lt;br /&gt;
##lang.license.expirationdate## : ##license.expirationdate##
&lt;br /&gt; &lt;a href=\"##license.url##\"&gt; ##license.url##
&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHlicenses##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('13','13','','##user.action##','##user.realname## ##user.firstname##

##lang.passwordforget.information##

##lang.passwordforget.link## ##user.passwordforgeturl##','&lt;p&gt;&lt;strong&gt;##user.realname## ##user.firstname##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.information##&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.link## &lt;a title=\"##user.passwordforgeturl##\" href=\"##user.passwordforgeturl##\"&gt;##user.passwordforgeturl##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('14','14','','##ticket.action## ##ticket.title##','##lang.ticket.title## : ##ticket.title##

##lang.ticket.closedate## : ##ticket.closedate##

##lang.satisfaction.text## ##ticket.urlsatisfaction##','&lt;p&gt;##lang.ticket.title## : ##ticket.title##&lt;/p&gt;
&lt;p&gt;##lang.ticket.closedate## : ##ticket.closedate##&lt;/p&gt;
&lt;p&gt;##lang.satisfaction.text## &lt;a href=\"##ticket.urlsatisfaction##\"&gt;##ticket.urlsatisfaction##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('16','16','','##crontask.action##','##lang.crontask.warning##

##FOREACHcrontasks##
 ##crontask.name## : ##crontask.description##

##ENDFOREACHcrontasks##','&lt;p&gt;##lang.crontask.warning##&lt;/p&gt;
&lt;p&gt;##FOREACHcrontasks## &lt;br /&gt;&lt;a href=\"##crontask.url##\"&gt;##crontask.name##&lt;/a&gt; : ##crontask.description##&lt;br /&gt; &lt;br /&gt;##ENDFOREACHcrontasks##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('17','17','','##problem.action## ##problem.title##','##IFproblem.storestatus=5##
 ##lang.problem.url## : ##problem.urlapprove##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description## ##ENDIFproblem.storestatus##
 ##ELSEproblem.storestatus## ##lang.problem.url## : ##problem.url## ##ENDELSEproblem.storestatus##

 ##lang.problem.description##

 ##lang.problem.title##  :##problem.title##
 ##lang.problem.authors##  :##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors## ##ELSEproblem.authors##--##ENDELSEproblem.authors##
 ##lang.problem.creationdate##  :##problem.creationdate##
 ##IFproblem.assigntousers## ##lang.problem.assigntousers##  : ##problem.assigntousers## ##ENDIFproblem.assigntousers##
 ##lang.problem.status##  : ##problem.status##
 ##IFproblem.assigntogroups## ##lang.problem.assigntogroups##  : ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##
 ##lang.problem.urgency##  : ##problem.urgency##
 ##lang.problem.impact##  : ##problem.impact##
 ##lang.problem.priority## : ##problem.priority##
##IFproblem.category## ##lang.problem.category##  :##problem.category## ##ENDIFproblem.category## ##ELSEproblem.category## ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##
 ##lang.problem.content##  : ##problem.content##

##IFproblem.storestatus=6##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description##
##ENDIFproblem.storestatus##
 ##lang.problem.numberoftickets## : ##problem.numberoftickets##

##FOREACHtickets##
 [##ticket.date##] ##lang.problem.title## : ##ticket.title##
 ##lang.problem.content## ##ticket.content##

##ENDFOREACHtickets##
 ##lang.problem.numberoftasks## : ##problem.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFproblem.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.problem.url## : &lt;a href=\"##problem.urlapprove##\"&gt;##problem.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description## ##ENDIFproblem.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEproblem.storestatus## ##lang.problem.url## : &lt;a href=\"##problem.url##\"&gt;##problem.url##&lt;/a&gt; ##ENDELSEproblem.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.problem.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.title##&lt;/span&gt;&#160;:##problem.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.authors##&lt;/span&gt;&#160;:##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors##    ##ELSEproblem.authors##--##ENDELSEproblem.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.creationdate##&lt;/span&gt;&#160;:##problem.creationdate## &lt;br /&gt; ##IFproblem.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntousers##&lt;/span&gt;&#160;: ##problem.assigntousers## ##ENDIFproblem.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.status## &lt;/span&gt;&#160;: ##problem.status##&lt;br /&gt; ##IFproblem.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntogroups##&lt;/span&gt;&#160;: ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.urgency##&lt;/span&gt;&#160;: ##problem.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.impact##&lt;/span&gt;&#160;: ##problem.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.priority##&lt;/span&gt; : ##problem.priority## &lt;br /&gt;##IFproblem.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.category## &lt;/span&gt;&#160;:##problem.category##  ##ENDIFproblem.category## ##ELSEproblem.category##  ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.content##&lt;/span&gt;&#160;: ##problem.content##&lt;/p&gt;
&lt;p&gt;##IFproblem.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description##&lt;br /&gt;##ENDIFproblem.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftickets##&#160;: ##problem.numberoftickets##&lt;/div&gt;
&lt;p&gt;##FOREACHtickets##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##ticket.date##] &lt;em&gt;##lang.problem.title## : &lt;a href=\"##ticket.url##\"&gt;##ticket.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.content## &lt;/span&gt; ##ticket.content##
&lt;p&gt;##ENDFOREACHtickets##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftasks##&#160;: ##problem.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('18','18','','##recall.action##: ##recall.item.name##','##recall.action##: ##recall.item.name##

##recall.item.content##

##lang.recall.planning.begin##: ##recall.planning.begin##
##lang.recall.planning.end##: ##recall.planning.end##
##lang.recall.planning.state##: ##recall.planning.state##
##lang.recall.item.private##: ##recall.item.private##','&lt;p&gt;##recall.action##: &lt;a href=\"##recall.item.url##\"&gt;##recall.item.name##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;##recall.item.content##&lt;/p&gt;
&lt;p&gt;##lang.recall.planning.begin##: ##recall.planning.begin##&lt;br /&gt;##lang.recall.planning.end##: ##recall.planning.end##&lt;br /&gt;##lang.recall.planning.state##: ##recall.planning.state##&lt;br /&gt;##lang.recall.item.private##: ##recall.item.private##&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('19','19','','##change.action## ##change.title##','##IFchange.storestatus=5##
 ##lang.change.url## : ##change.urlapprove##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description## ##ENDIFchange.storestatus##
 ##ELSEchange.storestatus## ##lang.change.url## : ##change.url## ##ENDELSEchange.storestatus##

 ##lang.change.description##

 ##lang.change.title##  :##change.title##
 ##lang.change.authors##  :##IFchange.authors## ##change.authors## ##ENDIFchange.authors## ##ELSEchange.authors##--##ENDELSEchange.authors##
 ##lang.change.creationdate##  :##change.creationdate##
 ##IFchange.assigntousers## ##lang.change.assigntousers##  : ##change.assigntousers## ##ENDIFchange.assigntousers##
 ##lang.change.status##  : ##change.status##
 ##IFchange.assigntogroups## ##lang.change.assigntogroups##  : ##change.assigntogroups## ##ENDIFchange.assigntogroups##
 ##lang.change.urgency##  : ##change.urgency##
 ##lang.change.impact##  : ##change.impact##
 ##lang.change.priority## : ##change.priority##
##IFchange.category## ##lang.change.category##  :##change.category## ##ENDIFchange.category## ##ELSEchange.category## ##lang.change.nocategoryassigned## ##ENDELSEchange.category##
 ##lang.change.content##  : ##change.content##

##IFchange.storestatus=6##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description##
##ENDIFchange.storestatus##
 ##lang.change.numberofproblems## : ##change.numberofproblems##

##FOREACHproblems##
 [##problem.date##] ##lang.change.title## : ##problem.title##
 ##lang.change.content## ##problem.content##

##ENDFOREACHproblems##
 ##lang.change.numberoftasks## : ##change.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFchange.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.change.url## : &lt;a href=\"##change.urlapprove##\"&gt;##change.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description## ##ENDIFchange.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEchange.storestatus## ##lang.change.url## : &lt;a href=\"##change.url##\"&gt;##change.url##&lt;/a&gt; ##ENDELSEchange.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.change.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.title##&lt;/span&gt;&#160;:##change.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.authors##&lt;/span&gt;&#160;:##IFchange.authors## ##change.authors## ##ENDIFchange.authors##    ##ELSEchange.authors##--##ENDELSEchange.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.creationdate##&lt;/span&gt;&#160;:##change.creationdate## &lt;br /&gt; ##IFchange.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntousers##&lt;/span&gt;&#160;: ##change.assigntousers## ##ENDIFchange.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.status## &lt;/span&gt;&#160;: ##change.status##&lt;br /&gt; ##IFchange.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntogroups##&lt;/span&gt;&#160;: ##change.assigntogroups## ##ENDIFchange.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.urgency##&lt;/span&gt;&#160;: ##change.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.impact##&lt;/span&gt;&#160;: ##change.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.priority##&lt;/span&gt; : ##change.priority## &lt;br /&gt;##IFchange.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.category## &lt;/span&gt;&#160;:##change.category##  ##ENDIFchange.category## ##ELSEchange.category##  ##lang.change.nocategoryassigned## ##ENDELSEchange.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.content##&lt;/span&gt;&#160;: ##change.content##&lt;/p&gt;
&lt;p&gt;##IFchange.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description##&lt;br /&gt;##ENDIFchange.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberofproblems##&#160;: ##change.numberofproblems##&lt;/div&gt;
&lt;p&gt;##FOREACHproblems##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##problem.date##] &lt;em&gt;##lang.change.title## : &lt;a href=\"##problem.url##\"&gt;##problem.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.content## &lt;/span&gt; ##problem.content##
&lt;p&gt;##ENDFOREACHproblems##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberoftasks##&#160;: ##change.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('20','20','','##mailcollector.action##','##FOREACHmailcollectors##
##lang.mailcollector.name## : ##mailcollector.name##
##lang.mailcollector.errors## : ##mailcollector.errors##
##mailcollector.url##
##ENDFOREACHmailcollectors##','&lt;p&gt;##FOREACHmailcollectors##&lt;br /&gt;##lang.mailcollector.name## : ##mailcollector.name##&lt;br /&gt; ##lang.mailcollector.errors## : ##mailcollector.errors##&lt;br /&gt;&lt;a href=\"##mailcollector.url##\"&gt;##mailcollector.url##&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHmailcollectors##&lt;/p&gt;
&lt;p&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('21','21','','##project.action## ##project.name## ##project.code##','##lang.project.url## : ##project.url##

##lang.project.description##

##lang.project.name## : ##project.name##
##lang.project.code## : ##project.code##
##lang.project.manager## : ##project.manager##
##lang.project.managergroup## : ##project.managergroup##
##lang.project.creationdate## : ##project.creationdate##
##lang.project.priority## : ##project.priority##
##lang.project.state## : ##project.state##
##lang.project.type## : ##project.type##
##lang.project.description## : ##project.description##

##lang.project.numberoftasks## : ##project.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.project.url## : &lt;a href=\"##project.url##\"&gt;##project.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.project.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.project.name## : ##project.name##&lt;br /&gt;##lang.project.code## : ##project.code##&lt;br /&gt; ##lang.project.manager## : ##project.manager##&lt;br /&gt;##lang.project.managergroup## : ##project.managergroup##&lt;br /&gt; ##lang.project.creationdate## : ##project.creationdate##&lt;br /&gt;##lang.project.priority## : ##project.priority## &lt;br /&gt;##lang.project.state## : ##project.state##&lt;br /&gt;##lang.project.type## : ##project.type##&lt;br /&gt;##lang.project.description## : ##project.description##&lt;/p&gt;
&lt;p&gt;##lang.project.numberoftasks## : ##project.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt; ##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('22','22','','##projecttask.action## ##projecttask.name##','##lang.projecttask.url## : ##projecttask.url##

##lang.projecttask.description##

##lang.projecttask.name## : ##projecttask.name##
##lang.projecttask.project## : ##projecttask.project##
##lang.projecttask.creationdate## : ##projecttask.creationdate##
##lang.projecttask.state## : ##projecttask.state##
##lang.projecttask.type## : ##projecttask.type##
##lang.projecttask.description## : ##projecttask.description##

##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.projecttask.url## : &lt;a href=\"##projecttask.url##\"&gt;##projecttask.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.projecttask.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.projecttask.name## : ##projecttask.name##&lt;br /&gt;##lang.projecttask.project## : &lt;a href=\"##projecttask.projecturl##\"&gt;##projecttask.project##&lt;/a&gt;&lt;br /&gt;##lang.projecttask.creationdate## : ##projecttask.creationdate##&lt;br /&gt;##lang.projecttask.state## : ##projecttask.state##&lt;br /&gt;##lang.projecttask.type## : ##projecttask.type##&lt;br /&gt;##lang.projecttask.description## : ##projecttask.description##&lt;/p&gt;
&lt;p&gt;##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt;##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('23','23','','##objectlock.action##','##objectlock.type## ###objectlock.id## - ##objectlock.name##

      ##lang.objectlock.url##
      ##objectlock.url##

      ##lang.objectlock.date_mod##
      ##objectlock.date_mod##

      Hello ##objectlock.lockedby.firstname##,
      Could go to this item and unlock it for me?
      Thank you,
      Regards,
      ##objectlock.requester.firstname##','&lt;table&gt;
      &lt;tbody&gt;
      &lt;tr&gt;&lt;th colspan=\"2\"&gt;&lt;a href=\"##objectlock.url##\"&gt;##objectlock.type## ###objectlock.id## - ##objectlock.name##&lt;/a&gt;&lt;/th&gt;&lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.url##&lt;/td&gt;
      &lt;td&gt;##objectlock.url##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.date_mod##&lt;/td&gt;
      &lt;td&gt;##objectlock.date_mod##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;/tbody&gt;
      &lt;/table&gt;
      &lt;p&gt;&lt;span style=\"font-size: small;\"&gt;Hello ##objectlock.lockedby.firstname##,&lt;br /&gt;Could go to this item and unlock it for me?&lt;br /&gt;Thank you,&lt;br /&gt;Regards,&lt;br /&gt;##objectlock.requester.firstname## ##objectlock.requester.lastname##&lt;/span&gt;&lt;/p&gt;');

### Dump table glpi_notimportedemails

DROP TABLE IF EXISTS `glpi_notimportedemails`;
CREATE TABLE `glpi_notimportedemails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `mailcollectors_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `subject` text,
  `messageid` varchar(255) NOT NULL,
  `reason` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `mailcollectors_id` (`mailcollectors_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


### Dump table glpi_objectlocks

DROP TABLE IF EXISTS `glpi_objectlocks`;
CREATE TABLE `glpi_objectlocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Type of locked object',
  `items_id` int(11) NOT NULL COMMENT 'RELATION to various tables, according to itemtype (ID)',
  `users_id` int(11) NOT NULL COMMENT 'id of the locker',
  `date_mod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp of the lock',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemarchitectures

DROP TABLE IF EXISTS `glpi_operatingsystemarchitectures`;
CREATE TABLE `glpi_operatingsystemarchitectures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystems

DROP TABLE IF EXISTS `glpi_operatingsystems`;
CREATE TABLE `glpi_operatingsystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemservicepacks

DROP TABLE IF EXISTS `glpi_operatingsystemservicepacks`;
CREATE TABLE `glpi_operatingsystemservicepacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemversions

DROP TABLE IF EXISTS `glpi_operatingsystemversions`;
CREATE TABLE `glpi_operatingsystemversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripheralmodels

DROP TABLE IF EXISTS `glpi_peripheralmodels`;
CREATE TABLE `glpi_peripheralmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripherals

DROP TABLE IF EXISTS `glpi_peripherals`;
CREATE TABLE `glpi_peripherals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `peripheraltypes_id` int(11) NOT NULL DEFAULT '0',
  `peripheralmodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `peripheralmodels_id` (`peripheralmodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `peripheraltypes_id` (`peripheraltypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripheraltypes

DROP TABLE IF EXISTS `glpi_peripheraltypes`;
CREATE TABLE `glpi_peripheraltypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonemodels

DROP TABLE IF EXISTS `glpi_phonemodels`;
CREATE TABLE `glpi_phonemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonepowersupplies

DROP TABLE IF EXISTS `glpi_phonepowersupplies`;
CREATE TABLE `glpi_phonepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phones

DROP TABLE IF EXISTS `glpi_phones`;
CREATE TABLE `glpi_phones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firmware` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `phonetypes_id` int(11) NOT NULL DEFAULT '0',
  `phonemodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `number_line` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_headset` tinyint(1) NOT NULL DEFAULT '0',
  `have_hp` tinyint(1) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `phonemodels_id` (`phonemodels_id`),
  KEY `phonepowersupplies_id` (`phonepowersupplies_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `phonetypes_id` (`phonetypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonetypes

DROP TABLE IF EXISTS `glpi_phonetypes`;
CREATE TABLE `glpi_phonetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_planningrecalls

DROP TABLE IF EXISTS `glpi_planningrecalls`;
CREATE TABLE `glpi_planningrecalls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `before_time` int(11) NOT NULL DEFAULT '-10',
  `when` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`users_id`),
  KEY `users_id` (`users_id`),
  KEY `before_time` (`before_time`),
  KEY `when` (`when`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugins

DROP TABLE IF EXISTS `glpi_plugins`;
CREATE TABLE `glpi_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `directory` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PLUGIN_* constant',
  `author` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `homepage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`directory`),
  KEY `state` (`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_printermodels

DROP TABLE IF EXISTS `glpi_printermodels`;
CREATE TABLE `glpi_printermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_printers

DROP TABLE IF EXISTS `glpi_printers`;
CREATE TABLE `glpi_printers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_serial` tinyint(1) NOT NULL DEFAULT '0',
  `have_parallel` tinyint(1) NOT NULL DEFAULT '0',
  `have_usb` tinyint(1) NOT NULL DEFAULT '0',
  `have_wifi` tinyint(1) NOT NULL DEFAULT '0',
  `have_ethernet` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `memory_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `printertypes_id` int(11) NOT NULL DEFAULT '0',
  `printermodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `init_pages_counter` int(11) NOT NULL DEFAULT '0',
  `last_pages_counter` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `printermodels_id` (`printermodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `printertypes_id` (`printertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `last_pages_counter` (`last_pages_counter`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_printertypes

DROP TABLE IF EXISTS `glpi_printertypes`;
CREATE TABLE `glpi_printertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problemcosts

DROP TABLE IF EXISTS `glpi_problemcosts`;
CREATE TABLE `glpi_problemcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `problems_id` (`problems_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems

DROP TABLE IF EXISTS `glpi_problems`;
CREATE TABLE `glpi_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `content` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `impactcontent` longtext COLLATE utf8_unicode_ci,
  `causecontent` longtext COLLATE utf8_unicode_ci,
  `symptomcontent` longtext COLLATE utf8_unicode_ci,
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin_waiting_date` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `date_mod` (`date_mod`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `due_date` (`due_date`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_suppliers

DROP TABLE IF EXISTS `glpi_problems_suppliers`;
CREATE TABLE `glpi_problems_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_tickets

DROP TABLE IF EXISTS `glpi_problems_tickets`;
CREATE TABLE `glpi_problems_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_users

DROP TABLE IF EXISTS `glpi_problems_users`;
CREATE TABLE `glpi_problems_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problemtasks

DROP TABLE IF EXISTS `glpi_problemtasks`;
CREATE TABLE `glpi_problemtasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `problems_id` (`problems_id`),
  KEY `users_id` (`users_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `state` (`state`),
  KEY `taskcategories_id` (`taskcategories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profilerights

DROP TABLE IF EXISTS `glpi_profilerights`;
CREATE TABLE `glpi_profilerights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rights` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`profiles_id`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profilerights` VALUES ('1','1','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('2','1','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('3','1','software','0');
INSERT INTO `glpi_profilerights` VALUES ('4','1','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('5','1','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('6','1','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('7','1','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('8','1','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('9','1','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('10','1','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('734','6','queuedmail','0');
INSERT INTO `glpi_profilerights` VALUES ('12','1','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('13','1','document','0');
INSERT INTO `glpi_profilerights` VALUES ('14','1','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('15','1','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('16','1','knowbase','2048');
INSERT INTO `glpi_profilerights` VALUES ('20','1','reservation','1024');
INSERT INTO `glpi_profilerights` VALUES ('21','1','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('22','1','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('24','1','device','0');
INSERT INTO `glpi_profilerights` VALUES ('25','1','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('26','1','link','0');
INSERT INTO `glpi_profilerights` VALUES ('27','1','config','0');
INSERT INTO `glpi_profilerights` VALUES ('29','1','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('30','1','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('31','1','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('32','1','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('33','1','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('684','5','location','0');
INSERT INTO `glpi_profilerights` VALUES ('679','7','domain','31');
INSERT INTO `glpi_profilerights` VALUES ('36','1','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('37','1','user','0');
INSERT INTO `glpi_profilerights` VALUES ('39','1','group','0');
INSERT INTO `glpi_profilerights` VALUES ('40','1','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('41','1','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('42','1','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('43','1','reminder_public','1');
INSERT INTO `glpi_profilerights` VALUES ('44','1','rssfeed_public','1');
INSERT INTO `glpi_profilerights` VALUES ('45','1','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('46','1','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('47','1','ticket','131077');
INSERT INTO `glpi_profilerights` VALUES ('51','1','followup','5');
INSERT INTO `glpi_profilerights` VALUES ('52','1','task','1');
INSERT INTO `glpi_profilerights` VALUES ('64','1','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('716','2','state','0');
INSERT INTO `glpi_profilerights` VALUES ('709','2','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('67','1','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('68','1','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('70','1','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('71','1','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('72','1','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('73','1','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('75','1','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('76','1','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('728','7','solutiontemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('79','1','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('80','1','sla','0');
INSERT INTO `glpi_profilerights` VALUES ('81','1','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('85','1','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('702','2','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('697','4','knowbasecategory','31');
INSERT INTO `glpi_profilerights` VALUES ('691','5','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('89','1','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('90','1','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('91','1','ticketcost','1');
INSERT INTO `glpi_profilerights` VALUES ('671','6','changevalidation','20');
INSERT INTO `glpi_profilerights` VALUES ('94','1','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('95','2','computer','33');
INSERT INTO `glpi_profilerights` VALUES ('96','2','monitor','33');
INSERT INTO `glpi_profilerights` VALUES ('97','2','software','33');
INSERT INTO `glpi_profilerights` VALUES ('98','2','networking','33');
INSERT INTO `glpi_profilerights` VALUES ('99','2','internet','1');
INSERT INTO `glpi_profilerights` VALUES ('100','2','printer','33');
INSERT INTO `glpi_profilerights` VALUES ('101','2','peripheral','33');
INSERT INTO `glpi_profilerights` VALUES ('102','2','cartridge','33');
INSERT INTO `glpi_profilerights` VALUES ('103','2','consumable','33');
INSERT INTO `glpi_profilerights` VALUES ('104','2','phone','33');
INSERT INTO `glpi_profilerights` VALUES ('733','5','queuedmail','0');
INSERT INTO `glpi_profilerights` VALUES ('106','2','contact_enterprise','33');
INSERT INTO `glpi_profilerights` VALUES ('107','2','document','33');
INSERT INTO `glpi_profilerights` VALUES ('108','2','contract','33');
INSERT INTO `glpi_profilerights` VALUES ('109','2','infocom','1');
INSERT INTO `glpi_profilerights` VALUES ('110','2','knowbase','2049');
INSERT INTO `glpi_profilerights` VALUES ('114','2','reservation','1025');
INSERT INTO `glpi_profilerights` VALUES ('115','2','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('116','2','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('118','2','device','0');
INSERT INTO `glpi_profilerights` VALUES ('119','2','typedoc','1');
INSERT INTO `glpi_profilerights` VALUES ('120','2','link','1');
INSERT INTO `glpi_profilerights` VALUES ('121','2','config','0');
INSERT INTO `glpi_profilerights` VALUES ('123','2','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('124','2','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('125','2','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('126','2','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('127','2','search_config','1055');
INSERT INTO `glpi_profilerights` VALUES ('683','4','location','31');
INSERT INTO `glpi_profilerights` VALUES ('678','6','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('130','2','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('131','2','user','2049');
INSERT INTO `glpi_profilerights` VALUES ('133','2','group','1');
INSERT INTO `glpi_profilerights` VALUES ('134','2','entity','32');
INSERT INTO `glpi_profilerights` VALUES ('135','2','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('136','2','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('137','2','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('138','2','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('139','2','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('140','2','backup','1024');
INSERT INTO `glpi_profilerights` VALUES ('141','2','ticket','168989');
INSERT INTO `glpi_profilerights` VALUES ('145','2','followup','5');
INSERT INTO `glpi_profilerights` VALUES ('146','2','task','1');
INSERT INTO `glpi_profilerights` VALUES ('748','6','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('749','7','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('158','2','planning','1');
INSERT INTO `glpi_profilerights` VALUES ('715','1','state','0');
INSERT INTO `glpi_profilerights` VALUES ('708','1','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('161','2','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('162','2','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('164','2','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('165','2','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('166','2','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('167','2','budget','33');
INSERT INTO `glpi_profilerights` VALUES ('169','2','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('170','2','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('726','5','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('727','6','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('173','2','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('174','2','sla','0');
INSERT INTO `glpi_profilerights` VALUES ('175','2','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('179','2','problem','1057');
INSERT INTO `glpi_profilerights` VALUES ('701','1','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('696','3','knowbasecategory','31');
INSERT INTO `glpi_profilerights` VALUES ('690','4','itilcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('183','2','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('184','2','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('185','2','ticketcost','1');
INSERT INTO `glpi_profilerights` VALUES ('669','4','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('670','5','changevalidation','20');
INSERT INTO `glpi_profilerights` VALUES ('188','2','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('189','3','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('190','3','monitor','127');
INSERT INTO `glpi_profilerights` VALUES ('191','3','software','127');
INSERT INTO `glpi_profilerights` VALUES ('192','3','networking','127');
INSERT INTO `glpi_profilerights` VALUES ('193','3','internet','31');
INSERT INTO `glpi_profilerights` VALUES ('194','3','printer','127');
INSERT INTO `glpi_profilerights` VALUES ('195','3','peripheral','127');
INSERT INTO `glpi_profilerights` VALUES ('196','3','cartridge','127');
INSERT INTO `glpi_profilerights` VALUES ('197','3','consumable','127');
INSERT INTO `glpi_profilerights` VALUES ('198','3','phone','127');
INSERT INTO `glpi_profilerights` VALUES ('732','4','queuedmail','31');
INSERT INTO `glpi_profilerights` VALUES ('200','3','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('201','3','document','127');
INSERT INTO `glpi_profilerights` VALUES ('202','3','contract','127');
INSERT INTO `glpi_profilerights` VALUES ('203','3','infocom','31');
INSERT INTO `glpi_profilerights` VALUES ('204','3','knowbase','6175');
INSERT INTO `glpi_profilerights` VALUES ('208','3','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('209','3','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('210','3','dropdown','31');
INSERT INTO `glpi_profilerights` VALUES ('212','3','device','31');
INSERT INTO `glpi_profilerights` VALUES ('213','3','typedoc','31');
INSERT INTO `glpi_profilerights` VALUES ('214','3','link','31');
INSERT INTO `glpi_profilerights` VALUES ('215','3','config','0');
INSERT INTO `glpi_profilerights` VALUES ('217','3','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('218','3','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('219','3','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('220','3','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('221','3','search_config','3103');
INSERT INTO `glpi_profilerights` VALUES ('682','3','location','31');
INSERT INTO `glpi_profilerights` VALUES ('677','5','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('224','3','profile','1');
INSERT INTO `glpi_profilerights` VALUES ('225','3','user','7199');
INSERT INTO `glpi_profilerights` VALUES ('227','3','group','31');
INSERT INTO `glpi_profilerights` VALUES ('228','3','entity','96');
INSERT INTO `glpi_profilerights` VALUES ('229','3','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('230','3','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('231','3','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('232','3','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('233','3','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('234','3','backup','1024');
INSERT INTO `glpi_profilerights` VALUES ('235','3','ticket','259103');
INSERT INTO `glpi_profilerights` VALUES ('239','3','followup','15383');
INSERT INTO `glpi_profilerights` VALUES ('240','3','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('745','3','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('746','4','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('747','5','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('252','3','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('714','7','taskcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('707','7','netpoint','31');
INSERT INTO `glpi_profilerights` VALUES ('255','3','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('256','3','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('258','3','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('259','3','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('260','3','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('261','3','budget','127');
INSERT INTO `glpi_profilerights` VALUES ('263','3','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('264','3','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('724','3','solutiontemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('725','4','solutiontemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('267','3','calendar','31');
INSERT INTO `glpi_profilerights` VALUES ('268','3','sla','0');
INSERT INTO `glpi_profilerights` VALUES ('269','3','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('273','3','problem','1151');
INSERT INTO `glpi_profilerights` VALUES ('695','2','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('689','3','itilcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('277','3','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('278','3','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('279','3','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('667','2','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('668','3','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('282','3','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('283','4','computer','255');
INSERT INTO `glpi_profilerights` VALUES ('284','4','monitor','255');
INSERT INTO `glpi_profilerights` VALUES ('285','4','software','255');
INSERT INTO `glpi_profilerights` VALUES ('286','4','networking','255');
INSERT INTO `glpi_profilerights` VALUES ('287','4','internet','159');
INSERT INTO `glpi_profilerights` VALUES ('288','4','printer','255');
INSERT INTO `glpi_profilerights` VALUES ('289','4','peripheral','255');
INSERT INTO `glpi_profilerights` VALUES ('290','4','cartridge','255');
INSERT INTO `glpi_profilerights` VALUES ('291','4','consumable','255');
INSERT INTO `glpi_profilerights` VALUES ('292','4','phone','255');
INSERT INTO `glpi_profilerights` VALUES ('294','4','contact_enterprise','255');
INSERT INTO `glpi_profilerights` VALUES ('295','4','document','255');
INSERT INTO `glpi_profilerights` VALUES ('296','4','contract','255');
INSERT INTO `glpi_profilerights` VALUES ('297','4','infocom','31');
INSERT INTO `glpi_profilerights` VALUES ('298','4','knowbase','7327');
INSERT INTO `glpi_profilerights` VALUES ('302','4','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('303','4','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('304','4','dropdown','31');
INSERT INTO `glpi_profilerights` VALUES ('306','4','device','31');
INSERT INTO `glpi_profilerights` VALUES ('307','4','typedoc','31');
INSERT INTO `glpi_profilerights` VALUES ('308','4','link','159');
INSERT INTO `glpi_profilerights` VALUES ('309','4','config','31');
INSERT INTO `glpi_profilerights` VALUES ('311','4','rule_ticket','1055');
INSERT INTO `glpi_profilerights` VALUES ('312','4','rule_import','31');
INSERT INTO `glpi_profilerights` VALUES ('313','4','rule_ldap','31');
INSERT INTO `glpi_profilerights` VALUES ('314','4','rule_softwarecategories','31');
INSERT INTO `glpi_profilerights` VALUES ('315','4','search_config','3103');
INSERT INTO `glpi_profilerights` VALUES ('681','2','location','0');
INSERT INTO `glpi_profilerights` VALUES ('676','4','domain','31');
INSERT INTO `glpi_profilerights` VALUES ('318','4','profile','159');
INSERT INTO `glpi_profilerights` VALUES ('319','4','user','7327');
INSERT INTO `glpi_profilerights` VALUES ('321','4','group','159');
INSERT INTO `glpi_profilerights` VALUES ('322','4','entity','3327');
INSERT INTO `glpi_profilerights` VALUES ('323','4','transfer','31');
INSERT INTO `glpi_profilerights` VALUES ('324','4','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('325','4','reminder_public','159');
INSERT INTO `glpi_profilerights` VALUES ('326','4','rssfeed_public','159');
INSERT INTO `glpi_profilerights` VALUES ('327','4','bookmark_public','31');
INSERT INTO `glpi_profilerights` VALUES ('328','4','backup','1055');
INSERT INTO `glpi_profilerights` VALUES ('329','4','ticket','259231');
INSERT INTO `glpi_profilerights` VALUES ('333','4','followup','15383');
INSERT INTO `glpi_profilerights` VALUES ('334','4','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('742','7','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('743','1','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('744','2','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('346','4','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('713','6','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('706','6','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('349','4','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('350','4','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('352','4','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('353','4','rule_dictionnary_software','31');
INSERT INTO `glpi_profilerights` VALUES ('354','4','rule_dictionnary_dropdown','31');
INSERT INTO `glpi_profilerights` VALUES ('355','4','budget','255');
INSERT INTO `glpi_profilerights` VALUES ('357','4','notification','31');
INSERT INTO `glpi_profilerights` VALUES ('358','4','rule_mailcollector','31');
INSERT INTO `glpi_profilerights` VALUES ('722','1','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('723','2','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('361','4','calendar','31');
INSERT INTO `glpi_profilerights` VALUES ('362','4','sla','31');
INSERT INTO `glpi_profilerights` VALUES ('363','4','rule_dictionnary_printer','31');
INSERT INTO `glpi_profilerights` VALUES ('367','4','problem','1279');
INSERT INTO `glpi_profilerights` VALUES ('694','1','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('688','2','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('371','4','tickettemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('372','4','ticketrecurrent','31');
INSERT INTO `glpi_profilerights` VALUES ('373','4','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('665','7','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('666','1','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('376','4','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('377','5','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('378','5','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('379','5','software','0');
INSERT INTO `glpi_profilerights` VALUES ('380','5','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('381','5','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('382','5','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('383','5','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('384','5','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('385','5','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('386','5','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('731','3','queuedmail','0');
INSERT INTO `glpi_profilerights` VALUES ('388','5','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('389','5','document','0');
INSERT INTO `glpi_profilerights` VALUES ('390','5','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('391','5','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('392','5','knowbase','0');
INSERT INTO `glpi_profilerights` VALUES ('396','5','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('397','5','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('398','5','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('400','5','device','0');
INSERT INTO `glpi_profilerights` VALUES ('401','5','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('402','5','link','0');
INSERT INTO `glpi_profilerights` VALUES ('403','5','config','0');
INSERT INTO `glpi_profilerights` VALUES ('405','5','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('406','5','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('407','5','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('408','5','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('409','5','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('680','1','location','0');
INSERT INTO `glpi_profilerights` VALUES ('675','3','domain','31');
INSERT INTO `glpi_profilerights` VALUES ('412','5','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('413','5','user','1025');
INSERT INTO `glpi_profilerights` VALUES ('415','5','group','0');
INSERT INTO `glpi_profilerights` VALUES ('416','5','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('417','5','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('418','5','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('419','5','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('420','5','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('421','5','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('422','5','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('423','5','ticket','140295');
INSERT INTO `glpi_profilerights` VALUES ('427','5','followup','12295');
INSERT INTO `glpi_profilerights` VALUES ('428','5','task','8193');
INSERT INTO `glpi_profilerights` VALUES ('739','4','project','1279');
INSERT INTO `glpi_profilerights` VALUES ('740','5','project','1150');
INSERT INTO `glpi_profilerights` VALUES ('741','6','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('440','5','planning','1');
INSERT INTO `glpi_profilerights` VALUES ('712','5','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('705','5','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('443','5','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('444','5','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('446','5','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('447','5','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('448','5','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('449','5','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('451','5','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('452','5','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('720','6','state','0');
INSERT INTO `glpi_profilerights` VALUES ('721','7','state','31');
INSERT INTO `glpi_profilerights` VALUES ('455','5','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('456','5','sla','0');
INSERT INTO `glpi_profilerights` VALUES ('457','5','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('461','5','problem','1024');
INSERT INTO `glpi_profilerights` VALUES ('700','7','knowbasecategory','31');
INSERT INTO `glpi_profilerights` VALUES ('687','1','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('465','5','tickettemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('466','5','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('467','5','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('663','5','change','1054');
INSERT INTO `glpi_profilerights` VALUES ('664','6','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('470','5','ticketvalidation','3088');
INSERT INTO `glpi_profilerights` VALUES ('471','6','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('472','6','monitor','127');
INSERT INTO `glpi_profilerights` VALUES ('473','6','software','127');
INSERT INTO `glpi_profilerights` VALUES ('474','6','networking','127');
INSERT INTO `glpi_profilerights` VALUES ('475','6','internet','31');
INSERT INTO `glpi_profilerights` VALUES ('476','6','printer','127');
INSERT INTO `glpi_profilerights` VALUES ('477','6','peripheral','127');
INSERT INTO `glpi_profilerights` VALUES ('478','6','cartridge','127');
INSERT INTO `glpi_profilerights` VALUES ('479','6','consumable','127');
INSERT INTO `glpi_profilerights` VALUES ('480','6','phone','127');
INSERT INTO `glpi_profilerights` VALUES ('730','2','queuedmail','0');
INSERT INTO `glpi_profilerights` VALUES ('482','6','contact_enterprise','96');
INSERT INTO `glpi_profilerights` VALUES ('483','6','document','127');
INSERT INTO `glpi_profilerights` VALUES ('484','6','contract','96');
INSERT INTO `glpi_profilerights` VALUES ('485','6','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('486','6','knowbase','6175');
INSERT INTO `glpi_profilerights` VALUES ('490','6','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('491','6','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('492','6','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('494','6','device','0');
INSERT INTO `glpi_profilerights` VALUES ('495','6','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('496','6','link','0');
INSERT INTO `glpi_profilerights` VALUES ('497','6','config','0');
INSERT INTO `glpi_profilerights` VALUES ('499','6','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('500','6','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('501','6','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('502','6','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('503','6','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('674','2','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('506','6','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('507','6','user','1055');
INSERT INTO `glpi_profilerights` VALUES ('509','6','group','1');
INSERT INTO `glpi_profilerights` VALUES ('510','6','entity','97');
INSERT INTO `glpi_profilerights` VALUES ('511','6','transfer','1');
INSERT INTO `glpi_profilerights` VALUES ('512','6','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('513','6','reminder_public','31');
INSERT INTO `glpi_profilerights` VALUES ('514','6','rssfeed_public','31');
INSERT INTO `glpi_profilerights` VALUES ('515','6','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('516','6','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('517','6','ticket','168967');
INSERT INTO `glpi_profilerights` VALUES ('521','6','followup','13319');
INSERT INTO `glpi_profilerights` VALUES ('522','6','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('736','1','project','0');
INSERT INTO `glpi_profilerights` VALUES ('737','2','project','1025');
INSERT INTO `glpi_profilerights` VALUES ('738','3','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('534','6','planning','1');
INSERT INTO `glpi_profilerights` VALUES ('711','4','taskcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('704','4','netpoint','31');
INSERT INTO `glpi_profilerights` VALUES ('537','6','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('538','6','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('540','6','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('541','6','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('542','6','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('543','6','budget','96');
INSERT INTO `glpi_profilerights` VALUES ('545','6','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('546','6','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('718','4','state','31');
INSERT INTO `glpi_profilerights` VALUES ('719','5','state','0');
INSERT INTO `glpi_profilerights` VALUES ('549','6','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('550','6','sla','1');
INSERT INTO `glpi_profilerights` VALUES ('551','6','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('555','6','problem','1121');
INSERT INTO `glpi_profilerights` VALUES ('699','6','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('693','7','itilcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('686','7','location','31');
INSERT INTO `glpi_profilerights` VALUES ('559','6','tickettemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('560','6','ticketrecurrent','1');
INSERT INTO `glpi_profilerights` VALUES ('561','6','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('661','3','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('662','4','change','1279');
INSERT INTO `glpi_profilerights` VALUES ('564','6','ticketvalidation','3088');
INSERT INTO `glpi_profilerights` VALUES ('565','7','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('566','7','monitor','127');
INSERT INTO `glpi_profilerights` VALUES ('567','7','software','127');
INSERT INTO `glpi_profilerights` VALUES ('568','7','networking','127');
INSERT INTO `glpi_profilerights` VALUES ('569','7','internet','31');
INSERT INTO `glpi_profilerights` VALUES ('570','7','printer','127');
INSERT INTO `glpi_profilerights` VALUES ('571','7','peripheral','127');
INSERT INTO `glpi_profilerights` VALUES ('572','7','cartridge','127');
INSERT INTO `glpi_profilerights` VALUES ('573','7','consumable','127');
INSERT INTO `glpi_profilerights` VALUES ('574','7','phone','127');
INSERT INTO `glpi_profilerights` VALUES ('729','1','queuedmail','0');
INSERT INTO `glpi_profilerights` VALUES ('576','7','contact_enterprise','96');
INSERT INTO `glpi_profilerights` VALUES ('577','7','document','127');
INSERT INTO `glpi_profilerights` VALUES ('578','7','contract','96');
INSERT INTO `glpi_profilerights` VALUES ('579','7','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('580','7','knowbase','6175');
INSERT INTO `glpi_profilerights` VALUES ('584','7','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('585','7','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('586','7','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('588','7','device','0');
INSERT INTO `glpi_profilerights` VALUES ('589','7','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('590','7','link','0');
INSERT INTO `glpi_profilerights` VALUES ('591','7','config','0');
INSERT INTO `glpi_profilerights` VALUES ('593','7','rule_ticket','1055');
INSERT INTO `glpi_profilerights` VALUES ('594','7','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('595','7','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('596','7','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('597','7','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('673','1','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('600','7','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('601','7','user','1055');
INSERT INTO `glpi_profilerights` VALUES ('603','7','group','1');
INSERT INTO `glpi_profilerights` VALUES ('604','7','entity','97');
INSERT INTO `glpi_profilerights` VALUES ('605','7','transfer','1');
INSERT INTO `glpi_profilerights` VALUES ('606','7','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('607','7','reminder_public','31');
INSERT INTO `glpi_profilerights` VALUES ('608','7','rssfeed_public','31');
INSERT INTO `glpi_profilerights` VALUES ('609','7','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('610','7','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('611','7','ticket','259103');
INSERT INTO `glpi_profilerights` VALUES ('615','7','followup','13335');
INSERT INTO `glpi_profilerights` VALUES ('616','7','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('735','7','queuedmail','0');
INSERT INTO `glpi_profilerights` VALUES ('628','7','planning','2049');
INSERT INTO `glpi_profilerights` VALUES ('710','3','taskcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('703','3','netpoint','31');
INSERT INTO `glpi_profilerights` VALUES ('631','7','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('632','7','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('634','7','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('635','7','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('636','7','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('637','7','budget','96');
INSERT INTO `glpi_profilerights` VALUES ('639','7','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('640','7','rule_mailcollector','31');
INSERT INTO `glpi_profilerights` VALUES ('672','7','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('717','3','state','31');
INSERT INTO `glpi_profilerights` VALUES ('643','7','calendar','31');
INSERT INTO `glpi_profilerights` VALUES ('644','7','sla','31');
INSERT INTO `glpi_profilerights` VALUES ('645','7','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('649','7','problem','1151');
INSERT INTO `glpi_profilerights` VALUES ('698','5','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('692','6','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('685','6','location','0');
INSERT INTO `glpi_profilerights` VALUES ('653','7','tickettemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('654','7','ticketrecurrent','31');
INSERT INTO `glpi_profilerights` VALUES ('655','7','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('659','1','change','0');
INSERT INTO `glpi_profilerights` VALUES ('660','2','change','1057');
INSERT INTO `glpi_profilerights` VALUES ('658','7','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('750','8','backup','1');
INSERT INTO `glpi_profilerights` VALUES ('751','8','bookmark_public','1');
INSERT INTO `glpi_profilerights` VALUES ('752','8','budget','161');
INSERT INTO `glpi_profilerights` VALUES ('753','8','calendar','1');
INSERT INTO `glpi_profilerights` VALUES ('754','8','cartridge','161');
INSERT INTO `glpi_profilerights` VALUES ('755','8','change','1185');
INSERT INTO `glpi_profilerights` VALUES ('756','8','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('757','8','computer','161');
INSERT INTO `glpi_profilerights` VALUES ('758','8','config','1');
INSERT INTO `glpi_profilerights` VALUES ('759','8','consumable','161');
INSERT INTO `glpi_profilerights` VALUES ('760','8','contact_enterprise','161');
INSERT INTO `glpi_profilerights` VALUES ('761','8','contract','161');
INSERT INTO `glpi_profilerights` VALUES ('762','8','device','0');
INSERT INTO `glpi_profilerights` VALUES ('763','8','document','161');
INSERT INTO `glpi_profilerights` VALUES ('764','8','domain','1');
INSERT INTO `glpi_profilerights` VALUES ('765','8','dropdown','1');
INSERT INTO `glpi_profilerights` VALUES ('766','8','entity','1185');
INSERT INTO `glpi_profilerights` VALUES ('767','8','followup','8193');
INSERT INTO `glpi_profilerights` VALUES ('768','8','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('769','8','group','129');
INSERT INTO `glpi_profilerights` VALUES ('770','8','infocom','1');
INSERT INTO `glpi_profilerights` VALUES ('771','8','internet','129');
INSERT INTO `glpi_profilerights` VALUES ('772','8','itilcategory','1');
INSERT INTO `glpi_profilerights` VALUES ('773','8','knowbase','2177');
INSERT INTO `glpi_profilerights` VALUES ('774','8','knowbasecategory','1');
INSERT INTO `glpi_profilerights` VALUES ('775','8','link','129');
INSERT INTO `glpi_profilerights` VALUES ('776','8','location','1');
INSERT INTO `glpi_profilerights` VALUES ('777','8','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('778','8','monitor','161');
INSERT INTO `glpi_profilerights` VALUES ('779','8','netpoint','1');
INSERT INTO `glpi_profilerights` VALUES ('780','8','networking','161');
INSERT INTO `glpi_profilerights` VALUES ('781','8','notification','1');
INSERT INTO `glpi_profilerights` VALUES ('782','8','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('783','8','peripheral','161');
INSERT INTO `glpi_profilerights` VALUES ('784','8','phone','161');
INSERT INTO `glpi_profilerights` VALUES ('785','8','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('786','8','printer','161');
INSERT INTO `glpi_profilerights` VALUES ('787','8','problem','1185');
INSERT INTO `glpi_profilerights` VALUES ('788','8','profile','129');
INSERT INTO `glpi_profilerights` VALUES ('789','8','project','1185');
INSERT INTO `glpi_profilerights` VALUES ('790','8','projecttask','1');
INSERT INTO `glpi_profilerights` VALUES ('791','8','queuedmail','1');
INSERT INTO `glpi_profilerights` VALUES ('792','8','reminder_public','129');
INSERT INTO `glpi_profilerights` VALUES ('793','8','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('794','8','reservation','1');
INSERT INTO `glpi_profilerights` VALUES ('795','8','rssfeed_public','129');
INSERT INTO `glpi_profilerights` VALUES ('796','8','rule_dictionnary_dropdown','1');
INSERT INTO `glpi_profilerights` VALUES ('797','8','rule_dictionnary_printer','1');
INSERT INTO `glpi_profilerights` VALUES ('798','8','rule_dictionnary_software','1');
INSERT INTO `glpi_profilerights` VALUES ('799','8','rule_import','1');
INSERT INTO `glpi_profilerights` VALUES ('800','8','rule_ldap','1');
INSERT INTO `glpi_profilerights` VALUES ('801','8','rule_mailcollector','1');
INSERT INTO `glpi_profilerights` VALUES ('802','8','rule_softwarecategories','1');
INSERT INTO `glpi_profilerights` VALUES ('803','8','rule_ticket','1');
INSERT INTO `glpi_profilerights` VALUES ('804','8','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('805','8','show_group_hardware','1');
INSERT INTO `glpi_profilerights` VALUES ('806','8','sla','1');
INSERT INTO `glpi_profilerights` VALUES ('807','8','software','161');
INSERT INTO `glpi_profilerights` VALUES ('808','8','solutiontemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('809','8','state','1');
INSERT INTO `glpi_profilerights` VALUES ('810','8','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('811','8','task','8193');
INSERT INTO `glpi_profilerights` VALUES ('812','8','taskcategory','1');
INSERT INTO `glpi_profilerights` VALUES ('813','8','ticket','138369');
INSERT INTO `glpi_profilerights` VALUES ('814','8','ticketcost','1');
INSERT INTO `glpi_profilerights` VALUES ('815','8','ticketrecurrent','1');
INSERT INTO `glpi_profilerights` VALUES ('816','8','tickettemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('817','8','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('818','8','transfer','1');
INSERT INTO `glpi_profilerights` VALUES ('819','8','typedoc','1');
INSERT INTO `glpi_profilerights` VALUES ('820','8','user','2177');
INSERT INTO `glpi_profilerights` VALUES ('821','1','license','0');
INSERT INTO `glpi_profilerights` VALUES ('822','2','license','33');
INSERT INTO `glpi_profilerights` VALUES ('823','3','license','127');
INSERT INTO `glpi_profilerights` VALUES ('824','4','license','255');
INSERT INTO `glpi_profilerights` VALUES ('825','5','license','0');
INSERT INTO `glpi_profilerights` VALUES ('826','6','license','127');
INSERT INTO `glpi_profilerights` VALUES ('827','7','license','127');
INSERT INTO `glpi_profilerights` VALUES ('828','8','license','161');

### Dump table glpi_profiles

DROP TABLE IF EXISTS `glpi_profiles`;
CREATE TABLE `glpi_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interface` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'helpdesk',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `helpdesk_hardware` int(11) NOT NULL DEFAULT '0',
  `helpdesk_item_type` text COLLATE utf8_unicode_ci,
  `ticket_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `problem_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `create_ticket_on_login` tinyint(1) NOT NULL DEFAULT '0',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `change_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `interface` (`interface`),
  KEY `is_default` (`is_default`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profiles` VALUES ('1','Self-Service','helpdesk','1','1','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0},\"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('2','Observer','central','0','1','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('3','Admin','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('4','Super-Admin','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('5','Hotliner','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','1','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('6','Technician','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('7','Supervisor','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('8','Read-Only','central','0','0','[]','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},
                       \"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},
                       \"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},
                       \"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},
                       \"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0},
                       \"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}',NULL,'This profile defines read-only access. It is used when objects are locked. It can also be used to give to users rights to unlock objects.','{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"4\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"5\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"8\":0,\"6\":0},
                      \"8\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},
                      \"6\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0}}','0','0','{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"7\":{\"1\":0,\"9\":0,\"10\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"4\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"11\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"12\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"5\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"8\":0,\"6\":0},
                       \"8\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"6\":0},
                       \"6\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0}}','2016-02-08 16:57:46');

### Dump table glpi_profiles_reminders

DROP TABLE IF EXISTS `glpi_profiles_reminders`;
CREATE TABLE `glpi_profiles_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profiles_rssfeeds

DROP TABLE IF EXISTS `glpi_profiles_rssfeeds`;
CREATE TABLE `glpi_profiles_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profiles_users

DROP TABLE IF EXISTS `glpi_profiles_users`;
CREATE TABLE `glpi_profiles_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `users_id` (`users_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profiles_users` VALUES ('2','2','4','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('3','3','1','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('4','4','6','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('5','5','2','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('6','6','6','0','0','0');

### Dump table glpi_projectcosts

DROP TABLE IF EXISTS `glpi_projectcosts`;
CREATE TABLE `glpi_projectcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `projects_id` (`projects_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projects

DROP TABLE IF EXISTS `glpi_projects`;
CREATE TABLE `glpi_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttypes_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `show_on_global_gantt` tinyint(1) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `code` (`code`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttypes_id` (`projecttypes_id`),
  KEY `priority` (`priority`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `groups_id` (`groups_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `show_on_global_gantt` (`show_on_global_gantt`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projectstates

DROP TABLE IF EXISTS `glpi_projectstates`;
CREATE TABLE `glpi_projectstates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_finished` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_finished` (`is_finished`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_projectstates` VALUES ('1','New',NULL,'#06ff00','0',NULL,NULL);
INSERT INTO `glpi_projectstates` VALUES ('2','Processing',NULL,'#ffb800','0',NULL,NULL);
INSERT INTO `glpi_projectstates` VALUES ('3','Closed',NULL,'#ff0000','1',NULL,NULL);

### Dump table glpi_projecttasks

DROP TABLE IF EXISTS `glpi_projecttasks`;
CREATE TABLE `glpi_projecttasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `planned_duration` int(11) NOT NULL DEFAULT '0',
  `effective_duration` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttasktypes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `is_milestone` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projecttasks_id` (`projecttasks_id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttasktypes_id` (`projecttasktypes_id`),
  KEY `is_milestone` (`is_milestone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttasks_tickets

DROP TABLE IF EXISTS `glpi_projecttasks_tickets`;
CREATE TABLE `glpi_projecttasks_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`projecttasks_id`),
  KEY `projects_id` (`projecttasks_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttaskteams

DROP TABLE IF EXISTS `glpi_projecttaskteams`;
CREATE TABLE `glpi_projecttaskteams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projecttasks_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttasktypes

DROP TABLE IF EXISTS `glpi_projecttasktypes`;
CREATE TABLE `glpi_projecttasktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projectteams

DROP TABLE IF EXISTS `glpi_projectteams`;
CREATE TABLE `glpi_projectteams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttypes

DROP TABLE IF EXISTS `glpi_projecttypes`;
CREATE TABLE `glpi_projecttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_queuedmails

DROP TABLE IF EXISTS `glpi_queuedmails`;
CREATE TABLE `glpi_queuedmails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `sent_try` int(11) NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `send_time` datetime DEFAULT NULL,
  `sent_time` datetime DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `sender` text COLLATE utf8_unicode_ci,
  `sendername` text COLLATE utf8_unicode_ci,
  `recipient` text COLLATE utf8_unicode_ci,
  `recipientname` text COLLATE utf8_unicode_ci,
  `replyto` text COLLATE utf8_unicode_ci,
  `replytoname` text COLLATE utf8_unicode_ci,
  `headers` text COLLATE utf8_unicode_ci,
  `body_html` longtext COLLATE utf8_unicode_ci,
  `body_text` longtext COLLATE utf8_unicode_ci,
  `messageid` text COLLATE utf8_unicode_ci,
  `documents` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`,`notificationtemplates_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `entities_id` (`entities_id`),
  KEY `sent_try` (`sent_try`),
  KEY `create_time` (`create_time`),
  KEY `send_time` (`send_time`),
  KEY `sent_time` (`sent_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_queuedmails` VALUES ('1','Ticket','150','4','0','0','1','2017-02-10 09:08:43','2017-02-10 09:08:43',NULL,'[GLPI #0000150] Closing of the ticket Printer Epson Kc Latasca หมึกหมด','suthamtg@gmail.com','DONG','suthamtg@gmail.com','DONG','suthamtg@gmail.com','','{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI #0000150] Closing of the ticket Printer Epson Kc Latasca หมึกหมด</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div></div>
<div> URL : <a href=\"http://itkamala.com/glpi/index.php?redirect=ticket_150_Ticket$1&amp;noAUTO=1\">http://itkamala.com/glpi/index.php?redirect=ticket_150_Ticket$1&amp;noAUTO=1</a> </div>
<p class=\"description b\"><strong>Ticket: Description</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Title</span>&#160;:Printer Epson Kc Latasca หมึกหมด <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Requesters</span>&#160;: dong      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Opening date</span>&#160;:2017-02-08 12:38 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Closing date</span>&#160;:2017-02-10 09:08 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Request source</span>&#160;:Helpdesk<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Associated item</span>&#160;:
<p></p>
 <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Assigned to technicians</span>&#160;: dong, Manassrisuksai Sutham <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Status </span>&#160;: Closed<br /> <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Urgency</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Impact</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Priority</span>&#160;: Medium <br />     <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Category </span>&#160;:Printer &gt; EPSON210/220      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Description</span>&#160;: Printer Epson Kc Latasca หมึกหมด</p>
<br /><br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">Date of solving</span></strong></span> : 2017-02-10 09:08<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">Solution type</span></strong></span> : <br /><span style=\"text-decoration: underline; color: #888888;\"><strong>Solution</strong></span> : <p>ดำเนินการเปลี่ยนเรียบร้อยแล้วครับ</p><br /></p>
<div class=\"description b\">Number of followups&#160;: 0</div>
<p></p>
<div class=\"description b\">Number of tasks&#160;: 0</div>
<p></p><br><br>-- 
<br>SIGNATURE<br>Automatically generated by GLPI 9.1.2<br><br>

</body></html>','URL : http://itkamala.com/glpi/index.php?redirect=ticket_150_Ticket$1&amp;noAUTO=1 

Ticket: Description

Title : Printer Epson Kc Latasca หมึกหมด
 Requesters : dong 
 Opening date : 2017-02-08 12:38
 Closing date : 2017-02-10 09:08
 Request source : Helpdesk
Associated item :

Assigned to technicians : dong, Manassrisuksai Sutham 
 Status : Closed

Urgency : Medium
 Impact : Medium
 Priority : Medium

Category : Printer &gt; EPSON210/220 
 Description : Printer Epson Kc Latasca หมึกหมด

Date of solving : 2017-02-10 09:08
 Solution type : 
 Solution : 
ดำเนินการเปลี่ยนเรียบร้อยแล้วครับ

Number of followups : 0

Number of tasks : 0

-- 
SIGNATURE
Automatically generated by GLPI 9.1.2

','GLPI-150.1486717723.1343738103@dong','');
INSERT INTO `glpi_queuedmails` VALUES ('6','Ticket','153','4','0','0','1','2017-02-10 09:11:29','2017-02-10 09:11:29',NULL,'[GLPI #0000153] Closing of the ticket Print ภาพ คุณ Montre  Guest Relation','suthamtg@gmail.com','DONG','suthamtg@gmail.com','DONG','suthamtg@gmail.com','','{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI #0000153] Closing of the ticket Print ภาพ คุณ Montre  Guest Relation</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div></div>
<div> URL : <a href=\"http://itkamala.com/glpi/index.php?redirect=ticket_153_Ticket$1&amp;noAUTO=1\">http://itkamala.com/glpi/index.php?redirect=ticket_153_Ticket$1&amp;noAUTO=1</a> </div>
<p class=\"description b\"><strong>Ticket: Description</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Title</span>&#160;:Print ภาพ คุณ Montre  Guest Relation <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Requesters</span>&#160;: Manassrisuksai Sutham      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Opening date</span>&#160;:2017-02-10 09:08 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Closing date</span>&#160;:2017-02-10 09:11 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Request source</span>&#160;:Helpdesk<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Associated item</span>&#160;:
<p></p>
<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Status </span>&#160;: Closed<br /> <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Urgency</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Impact</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Priority</span>&#160;: Medium <br />     <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Category </span>&#160;:Orther      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Description</span>&#160;: Print ภาพ คุณ Montre Guest Relation</p>
<br /><br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">Date of solving</span></strong></span> : 2017-02-10 09:11<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">Solution type</span></strong></span> : <br /><span style=\"text-decoration: underline; color: #888888;\"><strong>Solution</strong></span> : <p>ดำเนินการเรียบร้อยแล้วครับ</p><br /></p>
<div class=\"description b\">Number of followups&#160;: 0</div>
<p></p>
<div class=\"description b\">Number of tasks&#160;: 0</div>
<p></p><br><br>-- 
<br>SIGNATURE<br>Automatically generated by GLPI 9.1.2<br><br>

</body></html>','URL : http://itkamala.com/glpi/index.php?redirect=ticket_153_Ticket$1&amp;noAUTO=1 

Ticket: Description

Title : Print ภาพ คุณ Montre Guest Relation
 Requesters : Manassrisuksai Sutham 
 Opening date : 2017-02-10 09:08
 Closing date : 2017-02-10 09:11
 Request source : Helpdesk
Associated item :

Status : Closed

Urgency : Medium
 Impact : Medium
 Priority : Medium

Category : Orther 
 Description : Print ภาพ คุณ Montre Guest Relation

Date of solving : 2017-02-10 09:11
 Solution type : 
 Solution : 
ดำเนินการเรียบร้อยแล้วครับ

Number of followups : 0

Number of tasks : 0

-- 
SIGNATURE
Automatically generated by GLPI 9.1.2

','GLPI-153.1486717889.1335529034@dong','');
INSERT INTO `glpi_queuedmails` VALUES ('7','Ticket','153','4','0','0','1','2017-02-10 09:11:29','2017-02-10 09:11:29',NULL,'[GLPI #0000153] Closing of the ticket Print ภาพ คุณ Montre  Guest Relation','suthamtg@gmail.com','DONG','itswrkb@oceanresortgroup.net','Manassrisuksai Sutham','suthamtg@gmail.com','','{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI #0000153] Closing of the ticket Print ภาพ คุณ Montre  Guest Relation</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div></div>
<div> URL : <a href=\"http://itkamala.com/glpi/index.php?redirect=ticket_153_Ticket$1&amp;noAUTO=1\">http://itkamala.com/glpi/index.php?redirect=ticket_153_Ticket$1&amp;noAUTO=1</a> </div>
<p class=\"description b\"><strong>Ticket: Description</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Title</span>&#160;:Print ภาพ คุณ Montre  Guest Relation <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Requesters</span>&#160;: Manassrisuksai Sutham      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Opening date</span>&#160;:2017-02-10 09:08 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Closing date</span>&#160;:2017-02-10 09:11 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Request source</span>&#160;:Helpdesk<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Associated item</span>&#160;:
<p></p>
<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Status </span>&#160;: Closed<br /> <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Urgency</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Impact</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Priority</span>&#160;: Medium <br />     <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Category </span>&#160;:Orther      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Description</span>&#160;: Print ภาพ คุณ Montre Guest Relation</p>
<br /><br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">Date of solving</span></strong></span> : 2017-02-10 09:11<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">Solution type</span></strong></span> : <br /><span style=\"text-decoration: underline; color: #888888;\"><strong>Solution</strong></span> : <p>ดำเนินการเรียบร้อยแล้วครับ</p><br /></p>
<div class=\"description b\">Number of followups&#160;: 0</div>
<p></p>
<div class=\"description b\">Number of tasks&#160;: 0</div>
<p></p><br><br>-- 
<br>SIGNATURE<br>Automatically generated by GLPI 9.1.2<br><br>

</body></html>','URL : http://itkamala.com/glpi/index.php?redirect=ticket_153_Ticket$1&amp;noAUTO=1 

Ticket: Description

Title : Print ภาพ คุณ Montre Guest Relation
 Requesters : Manassrisuksai Sutham 
 Opening date : 2017-02-10 09:08
 Closing date : 2017-02-10 09:11
 Request source : Helpdesk
Associated item :

Status : Closed

Urgency : Medium
 Impact : Medium
 Priority : Medium

Category : Orther 
 Description : Print ภาพ คุณ Montre Guest Relation

Date of solving : 2017-02-10 09:11
 Solution type : 
 Solution : 
ดำเนินการเรียบร้อยแล้วครับ

Number of followups : 0

Number of tasks : 0

-- 
SIGNATURE
Automatically generated by GLPI 9.1.2

','GLPI-153.1486717890.1801225452@dong','');
INSERT INTO `glpi_queuedmails` VALUES ('8','Ticket','154','4','0','0','1','2017-02-10 09:11:40','2017-02-10 09:11:40',NULL,'[GLPI #0000154] Closing of the ticket สาย LAN มีปัญหา Pool By the sea','suthamtg@gmail.com','DONG','suthamtg@gmail.com','DONG','suthamtg@gmail.com','','{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI #0000154] Closing of the ticket สาย LAN มีปัญหา Pool By the sea</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div></div>
<div> URL : <a href=\"http://itkamala.com/glpi/index.php?redirect=ticket_154_Ticket$1&amp;noAUTO=1\">http://itkamala.com/glpi/index.php?redirect=ticket_154_Ticket$1&amp;noAUTO=1</a> </div>
<p class=\"description b\"><strong>Ticket: Description</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Title</span>&#160;:สาย LAN มีปัญหา Pool By the sea <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Requesters</span>&#160;: Manassrisuksai Sutham      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Opening date</span>&#160;:2017-02-10 14:10 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Closing date</span>&#160;:2017-02-10 14:10 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Request source</span>&#160;:Helpdesk<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Associated item</span>&#160;:
<p></p>
<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Status </span>&#160;: Closed<br /> <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Urgency</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Impact</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Priority</span>&#160;: Medium <br />     <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Category </span>&#160;:Network &gt; LAN      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Description</span>&#160;: สาย LAN มีปัญหา Pool By the sea</p>
<br /><br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">Date of solving</span></strong></span> : 2017-02-10 14:10<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">Solution type</span></strong></span> : <br /><span style=\"text-decoration: underline; color: #888888;\"><strong>Solution</strong></span> : <p>หนูกัดสาย Lan</p>
<p>ดำเนินการเรียบร้อยแล้วครับ</p><br /></p>
<div class=\"description b\">Number of followups&#160;: 0</div>
<p></p>
<div class=\"description b\">Number of tasks&#160;: 0</div>
<p></p><br><br>-- 
<br>SIGNATURE<br>Automatically generated by GLPI 9.1.2<br><br>

</body></html>','URL : http://itkamala.com/glpi/index.php?redirect=ticket_154_Ticket$1&amp;noAUTO=1 

Ticket: Description

Title : สาย LAN มีปัญหา Pool By the sea
 Requesters : Manassrisuksai Sutham 
 Opening date : 2017-02-10 14:10
 Closing date : 2017-02-10 14:10
 Request source : Helpdesk
Associated item :

Status : Closed

Urgency : Medium
 Impact : Medium
 Priority : Medium

Category : Network &gt; LAN 
 Description : สาย LAN มีปัญหา Pool By the sea

Date of solving : 2017-02-10 14:10
 Solution type : 
 Solution : 
หนูกัดสาย Lan

ดำเนินการเรียบร้อยแล้วครับ

Number of followups : 0

Number of tasks : 0

-- 
SIGNATURE
Automatically generated by GLPI 9.1.2

','GLPI-154.1486717900.479070844@dong','');
INSERT INTO `glpi_queuedmails` VALUES ('9','Ticket','154','4','0','0','1','2017-02-10 09:11:40','2017-02-10 09:11:40',NULL,'[GLPI #0000154] Closing of the ticket สาย LAN มีปัญหา Pool By the sea','suthamtg@gmail.com','DONG','itswrkb@oceanresortgroup.net','Manassrisuksai Sutham','suthamtg@gmail.com','','{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI #0000154] Closing of the ticket สาย LAN มีปัญหา Pool By the sea</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div></div>
<div> URL : <a href=\"http://itkamala.com/glpi/index.php?redirect=ticket_154_Ticket$1&amp;noAUTO=1\">http://itkamala.com/glpi/index.php?redirect=ticket_154_Ticket$1&amp;noAUTO=1</a> </div>
<p class=\"description b\"><strong>Ticket: Description</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Title</span>&#160;:สาย LAN มีปัญหา Pool By the sea <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Requesters</span>&#160;: Manassrisuksai Sutham      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Opening date</span>&#160;:2017-02-10 14:10 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Closing date</span>&#160;:2017-02-10 14:10 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Request source</span>&#160;:Helpdesk<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Associated item</span>&#160;:
<p></p>
<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Status </span>&#160;: Closed<br /> <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Urgency</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Impact</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Priority</span>&#160;: Medium <br />     <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Category </span>&#160;:Network &gt; LAN      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Description</span>&#160;: สาย LAN มีปัญหา Pool By the sea</p>
<br /><br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">Date of solving</span></strong></span> : 2017-02-10 14:10<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">Solution type</span></strong></span> : <br /><span style=\"text-decoration: underline; color: #888888;\"><strong>Solution</strong></span> : <p>หนูกัดสาย Lan</p>
<p>ดำเนินการเรียบร้อยแล้วครับ</p><br /></p>
<div class=\"description b\">Number of followups&#160;: 0</div>
<p></p>
<div class=\"description b\">Number of tasks&#160;: 0</div>
<p></p><br><br>-- 
<br>SIGNATURE<br>Automatically generated by GLPI 9.1.2<br><br>

</body></html>','URL : http://itkamala.com/glpi/index.php?redirect=ticket_154_Ticket$1&amp;noAUTO=1 

Ticket: Description

Title : สาย LAN มีปัญหา Pool By the sea
 Requesters : Manassrisuksai Sutham 
 Opening date : 2017-02-10 14:10
 Closing date : 2017-02-10 14:10
 Request source : Helpdesk
Associated item :

Status : Closed

Urgency : Medium
 Impact : Medium
 Priority : Medium

Category : Network &gt; LAN 
 Description : สาย LAN มีปัญหา Pool By the sea

Date of solving : 2017-02-10 14:10
 Solution type : 
 Solution : 
หนูกัดสาย Lan

ดำเนินการเรียบร้อยแล้วครับ

Number of followups : 0

Number of tasks : 0

-- 
SIGNATURE
Automatically generated by GLPI 9.1.2

','GLPI-154.1486717900.595036363@dong','');
INSERT INTO `glpi_queuedmails` VALUES ('12','Ticket','155','4','0','0','1','2017-02-10 09:14:45','2017-02-10 09:14:45',NULL,'[GLPI #0000155] Closing of the ticket เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้','suthamtg@gmail.com','DONG','suthamtg@gmail.com','DONG','suthamtg@gmail.com','','{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI #0000155] Closing of the ticket เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div></div>
<div> URL : <a href=\"http://itkamala.com/glpi/index.php?redirect=ticket_155_Ticket$1&amp;noAUTO=1\">http://itkamala.com/glpi/index.php?redirect=ticket_155_Ticket$1&amp;noAUTO=1</a> </div>
<p class=\"description b\"><strong>Ticket: Description</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Title</span>&#160;:เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้ <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Requesters</span>&#160;: Manassrisuksai Sutham      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Opening date</span>&#160;:2017-02-08 16:12 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Closing date</span>&#160;:2017-02-10 09:14 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Request source</span>&#160;:Helpdesk<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Associated item</span>&#160;:
<p></p>
<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Status </span>&#160;: Closed<br /> <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Urgency</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Impact</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Priority</span>&#160;: Medium <br />     <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Category </span>&#160;:Software &gt; HR @PAYROLL      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Description</span>&#160;: เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้<br />
TR ไม่สามารถใช้งานได้</p>
<br /><br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">Date of solving</span></strong></span> : 2017-02-10 09:14<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">Solution type</span></strong></span> : <br /><span style=\"text-decoration: underline; color: #888888;\"><strong>Solution</strong></span> : <p>ย้ายฐานข้อมูลภาษีจาก59ไป60</p>
<p>Run administrator Program</p>
<p>ข๊ะนี้สามารถใช้งานได้ตามปกติ</p><br /></p>
<div class=\"description b\">Number of followups&#160;: 0</div>
<p></p>
<div class=\"description b\">Number of tasks&#160;: 0</div>
<p></p><br><br>-- 
<br>SIGNATURE<br>Automatically generated by GLPI 9.1.2<br><br>

</body></html>','URL : http://itkamala.com/glpi/index.php?redirect=ticket_155_Ticket$1&amp;noAUTO=1 

Ticket: Description

Title : เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้
 Requesters : Manassrisuksai Sutham 
 Opening date : 2017-02-08 16:12
 Closing date : 2017-02-10 09:14
 Request source : Helpdesk
Associated item :

Status : Closed

Urgency : Medium
 Impact : Medium
 Priority : Medium

Category : Software &gt; HR @PAYROLL 
 Description : เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้
TR ไม่สามารถใช้งานได้

Date of solving : 2017-02-10 09:14
 Solution type : 
 Solution : 
ย้ายฐานข้อมูลภาษีจาก59ไป60

Run administrator Program

ข๊ะนี้สามารถใช้งานได้ตามปกติ

Number of followups : 0

Number of tasks : 0

-- 
SIGNATURE
Automatically generated by GLPI 9.1.2

','GLPI-155.1486718085.813618670@dong','');
INSERT INTO `glpi_queuedmails` VALUES ('13','Ticket','155','4','0','0','1','2017-02-10 09:14:45','2017-02-10 09:14:45',NULL,'[GLPI #0000155] Closing of the ticket เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้','suthamtg@gmail.com','DONG','itswrkb@oceanresortgroup.net','Manassrisuksai Sutham','suthamtg@gmail.com','','{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI #0000155] Closing of the ticket เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div></div>
<div> URL : <a href=\"http://itkamala.com/glpi/index.php?redirect=ticket_155_Ticket$1&amp;noAUTO=1\">http://itkamala.com/glpi/index.php?redirect=ticket_155_Ticket$1&amp;noAUTO=1</a> </div>
<p class=\"description b\"><strong>Ticket: Description</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Title</span>&#160;:เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้ <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Requesters</span>&#160;: Manassrisuksai Sutham      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Opening date</span>&#160;:2017-02-08 16:12 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Closing date</span>&#160;:2017-02-10 09:14 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Request source</span>&#160;:Helpdesk<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Associated item</span>&#160;:
<p></p>
<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Status </span>&#160;: Closed<br /> <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Urgency</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Impact</span>&#160;: Medium<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Priority</span>&#160;: Medium <br />     <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Category </span>&#160;:Software &gt; HR @PAYROLL      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Description</span>&#160;: เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้<br />
TR ไม่สามารถใช้งานได้</p>
<br /><br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">Date of solving</span></strong></span> : 2017-02-10 09:14<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">Solution type</span></strong></span> : <br /><span style=\"text-decoration: underline; color: #888888;\"><strong>Solution</strong></span> : <p>ย้ายฐานข้อมูลภาษีจาก59ไป60</p>
<p>Run administrator Program</p>
<p>ข๊ะนี้สามารถใช้งานได้ตามปกติ</p><br /></p>
<div class=\"description b\">Number of followups&#160;: 0</div>
<p></p>
<div class=\"description b\">Number of tasks&#160;: 0</div>
<p></p><br><br>-- 
<br>SIGNATURE<br>Automatically generated by GLPI 9.1.2<br><br>

</body></html>','URL : http://itkamala.com/glpi/index.php?redirect=ticket_155_Ticket$1&amp;noAUTO=1 

Ticket: Description

Title : เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้
 Requesters : Manassrisuksai Sutham 
 Opening date : 2017-02-08 16:12
 Closing date : 2017-02-10 09:14
 Request source : Helpdesk
Associated item :

Status : Closed

Urgency : Medium
 Impact : Medium
 Priority : Medium

Category : Software &gt; HR @PAYROLL 
 Description : เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้
TR ไม่สามารถใช้งานได้

Date of solving : 2017-02-10 09:14
 Solution type : 
 Solution : 
ย้ายฐานข้อมูลภาษีจาก59ไป60

Run administrator Program

ข๊ะนี้สามารถใช้งานได้ตามปกติ

Number of followups : 0

Number of tasks : 0

-- 
SIGNATURE
Automatically generated by GLPI 9.1.2

','GLPI-155.1486718085.248230050@dong','');

### Dump table glpi_registeredids

DROP TABLE IF EXISTS `glpi_registeredids`;
CREATE TABLE `glpi_registeredids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `device_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'USB, PCI ...',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `item` (`items_id`,`itemtype`),
  KEY `device_type` (`device_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reminders

DROP TABLE IF EXISTS `glpi_reminders`;
CREATE TABLE `glpi_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `is_planned` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '0',
  `begin_view_date` datetime DEFAULT NULL,
  `end_view_date` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `users_id` (`users_id`),
  KEY `is_planned` (`is_planned`),
  KEY `state` (`state`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reminders_users

DROP TABLE IF EXISTS `glpi_reminders_users`;
CREATE TABLE `glpi_reminders_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_requesttypes

DROP TABLE IF EXISTS `glpi_requesttypes`;
CREATE TABLE `glpi_requesttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_helpdesk_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_followup_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_mail_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_mailfollowup_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_ticketheader` tinyint(1) NOT NULL DEFAULT '1',
  `is_ticketfollowup` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_helpdesk_default` (`is_helpdesk_default`),
  KEY `is_followup_default` (`is_followup_default`),
  KEY `is_mail_default` (`is_mail_default`),
  KEY `is_mailfollowup_default` (`is_mailfollowup_default`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `is_active` (`is_active`),
  KEY `is_ticketheader` (`is_ticketheader`),
  KEY `is_ticketfollowup` (`is_ticketfollowup`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_requesttypes` VALUES ('1','Helpdesk','1','1','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('2','E-Mail','0','0','1','1','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('3','Phone','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('4','Direct','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('5','Written','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('6','Other','0','0','0','0','1','1','1',NULL,NULL,NULL);

### Dump table glpi_reservationitems

DROP TABLE IF EXISTS `glpi_reservationitems`;
CREATE TABLE `glpi_reservationitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reservations

DROP TABLE IF EXISTS `glpi_reservations`;
CREATE TABLE `glpi_reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservationitems_id` int(11) NOT NULL DEFAULT '0',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `group` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `reservationitems_id` (`reservationitems_id`),
  KEY `users_id` (`users_id`),
  KEY `resagroup` (`reservationitems_id`,`group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_rssfeeds

DROP TABLE IF EXISTS `glpi_rssfeeds`;
CREATE TABLE `glpi_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `url` text COLLATE utf8_unicode_ci,
  `refresh_rate` int(11) NOT NULL DEFAULT '86400',
  `max_items` int(11) NOT NULL DEFAULT '20',
  `have_error` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `users_id` (`users_id`),
  KEY `date_mod` (`date_mod`),
  KEY `have_error` (`have_error`),
  KEY `is_active` (`is_active`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_rssfeeds_users

DROP TABLE IF EXISTS `glpi_rssfeeds_users`;
CREATE TABLE `glpi_rssfeeds_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ruleactions

DROP TABLE IF EXISTS `glpi_ruleactions`;
CREATE TABLE `glpi_ruleactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rules_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'VALUE IN (assign, regex_result, append_regex_result, affectbyip, affectbyfqdn, affectbymac)',
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rules_id` (`rules_id`),
  KEY `field_value` (`field`(50),`value`(50))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ruleactions` VALUES ('6','6','fromitem','locations_id','1');
INSERT INTO `glpi_ruleactions` VALUES ('2','2','assign','entities_id','0');
INSERT INTO `glpi_ruleactions` VALUES ('3','3','assign','entities_id','0');
INSERT INTO `glpi_ruleactions` VALUES ('4','4','assign','_refuse_email_no_response','1');
INSERT INTO `glpi_ruleactions` VALUES ('5','5','assign','_refuse_email_no_response','1');
INSERT INTO `glpi_ruleactions` VALUES ('7','7','fromuser','locations_id','1');

### Dump table glpi_rulecriterias

DROP TABLE IF EXISTS `glpi_rulecriterias`;
CREATE TABLE `glpi_rulecriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rules_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rules_id` (`rules_id`),
  KEY `condition` (`condition`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rulecriterias` VALUES ('9','6','locations_id','9','1');
INSERT INTO `glpi_rulecriterias` VALUES ('2','2','uid','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('3','2','samaccountname','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('4','2','MAIL_EMAIL','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('5','3','subject','6','/.*/');
INSERT INTO `glpi_rulecriterias` VALUES ('6','4','x-auto-response-suppress','6','/\\S+/');
INSERT INTO `glpi_rulecriterias` VALUES ('7','5','auto-submitted','6','/\\S+/');
INSERT INTO `glpi_rulecriterias` VALUES ('8','5','auto-submitted','1','no');
INSERT INTO `glpi_rulecriterias` VALUES ('10','6','items_locations','8','1');
INSERT INTO `glpi_rulecriterias` VALUES ('11','7','locations_id','9','1');
INSERT INTO `glpi_rulecriterias` VALUES ('12','7','users_locations','8','1');

### Dump table glpi_rulerightparameters

DROP TABLE IF EXISTS `glpi_rulerightparameters`;
CREATE TABLE `glpi_rulerightparameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rulerightparameters` VALUES ('1','(LDAP)Organization','o','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('2','(LDAP)Common Name','cn','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('3','(LDAP)Department Number','departmentnumber','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('4','(LDAP)Email','mail','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('5','Object Class','objectclass','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('6','(LDAP)User ID','uid','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('7','(LDAP)Telephone Number','phone','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('8','(LDAP)Employee Number','employeenumber','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('9','(LDAP)Manager','manager','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('10','(LDAP)DistinguishedName','dn','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('12','(AD)User ID','samaccountname','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('13','(LDAP) Title','title','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('14','(LDAP) MemberOf','memberof','',NULL,NULL);

### Dump table glpi_rules

DROP TABLE IF EXISTS `glpi_rules`;
CREATE TABLE `glpi_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `sub_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ranking` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_active` (`is_active`),
  KEY `sub_type` (`sub_type`),
  KEY `date_mod` (`date_mod`),
  KEY `is_recursive` (`is_recursive`),
  KEY `condition` (`condition`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rules` VALUES ('2','0','RuleRight','1','Root','','OR','1',NULL,NULL,'0','500717c8-2bd6e957-53a12b5fd35745.02608131','0',NULL);
INSERT INTO `glpi_rules` VALUES ('3','0','RuleMailCollector','3','Root','','OR','1',NULL,NULL,'0','500717c8-2bd6e957-53a12b5fd36404.54713349','0',NULL);
INSERT INTO `glpi_rules` VALUES ('4','0','RuleMailCollector','1','Auto-Reply X-Auto-Response-Suppress','Exclude Auto-Reply emails using X-Auto-Response-Suppress header','AND','1',NULL,'2011-01-18 11:40:42','1','500717c8-2bd6e957-53a12b5fd36d97.94503423','0',NULL);
INSERT INTO `glpi_rules` VALUES ('5','0','RuleMailCollector','2','Auto-Reply Auto-Submitted','Exclude Auto-Reply emails using Auto-Submitted header','AND','1',NULL,'2011-01-18 11:40:42','1','500717c8-2bd6e957-53a12b5fd376c2.87642651','0',NULL);
INSERT INTO `glpi_rules` VALUES ('6','0','RuleTicket','1','Ticket location from item','','AND','0','Automatically generated by GLPI 0.84',NULL,'1','500717c8-2bd6e957-53a12b5fd37f94.10365341','1',NULL);
INSERT INTO `glpi_rules` VALUES ('7','0','RuleTicket','2','Ticket location from user','','AND','0','Automatically generated by GLPI 0.84',NULL,'1','500717c8-2bd6e957-53a12b5fd38869.86002585','1',NULL);

### Dump table glpi_slalevelactions

DROP TABLE IF EXISTS `glpi_slalevelactions`;
CREATE TABLE `glpi_slalevelactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slalevels_id` (`slalevels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevelcriterias

DROP TABLE IF EXISTS `glpi_slalevelcriterias`;
CREATE TABLE `glpi_slalevelcriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slalevels_id` (`slalevels_id`),
  KEY `condition` (`condition`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevels

DROP TABLE IF EXISTS `glpi_slalevels`;
CREATE TABLE `glpi_slalevels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slts_id` int(11) NOT NULL DEFAULT '0',
  `execution_time` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_active` (`is_active`),
  KEY `slts_id` (`slts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevels_tickets

DROP TABLE IF EXISTS `glpi_slalevels_tickets`;
CREATE TABLE `glpi_slalevels_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `slalevels_id` (`slalevels_id`),
  KEY `unicity` (`tickets_id`,`slalevels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slas

DROP TABLE IF EXISTS `glpi_slas`;
CREATE TABLE `glpi_slas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `calendars_id` (`calendars_id`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slts

DROP TABLE IF EXISTS `glpi_slts`;
CREATE TABLE `glpi_slts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `number_time` int(11) NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `definition_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_of_working_day` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `slas_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `slas_id` (`slas_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_softwarecategories

DROP TABLE IF EXISTS `glpi_softwarecategories`;
CREATE TABLE `glpi_softwarecategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `softwarecategories_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `softwarecategories_id` (`softwarecategories_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwarecategories` VALUES ('1','FUSION',NULL,'0','FUSION','1',NULL,NULL);

### Dump table glpi_softwarelicenses

DROP TABLE IF EXISTS `glpi_softwarelicenses`;
CREATE TABLE `glpi_softwarelicenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL DEFAULT '0',
  `softwarelicensetypes_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `softwareversions_id_buy` int(11) NOT NULL DEFAULT '0',
  `softwareversions_id_use` int(11) NOT NULL DEFAULT '0',
  `expire` date DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `is_valid` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_helpdesk_visible` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `expire` (`expire`),
  KEY `softwareversions_id_buy` (`softwareversions_id_buy`),
  KEY `entities_id` (`entities_id`),
  KEY `softwarelicensetypes_id` (`softwarelicensetypes_id`),
  KEY `softwareversions_id_use` (`softwareversions_id_use`),
  KEY `date_mod` (`date_mod`),
  KEY `softwares_id_expire` (`softwares_id`,`expire`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `users_id` (`users_id`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `groups_id` (`groups_id`),
  KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  KEY `is_deleted` (`is_helpdesk_visible`),
  KEY `date_creation` (`date_creation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_softwarelicensetypes

DROP TABLE IF EXISTS `glpi_softwarelicensetypes`;
CREATE TABLE `glpi_softwarelicensetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwarelicensetypes` VALUES ('1','OEM','',NULL,NULL);

### Dump table glpi_softwares

DROP TABLE IF EXISTS `glpi_softwares`;
CREATE TABLE `glpi_softwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_update` tinyint(1) NOT NULL DEFAULT '0',
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_helpdesk_visible` tinyint(1) NOT NULL DEFAULT '1',
  `softwarecategories_id` int(11) NOT NULL DEFAULT '0',
  `is_valid` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_update` (`is_update`),
  KEY `softwarecategories_id` (`softwarecategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `softwares_id` (`softwares_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_softwareversions

DROP TABLE IF EXISTS `glpi_softwareversions`;
CREATE TABLE `glpi_softwareversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `operatingsystems_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `softwares_id` (`softwares_id`),
  KEY `states_id` (`states_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `operatingsystems_id` (`operatingsystems_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_solutiontemplates

DROP TABLE IF EXISTS `glpi_solutiontemplates`;
CREATE TABLE `glpi_solutiontemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_solutiontypes

DROP TABLE IF EXISTS `glpi_solutiontypes`;
CREATE TABLE `glpi_solutiontypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ssovariables

DROP TABLE IF EXISTS `glpi_ssovariables`;
CREATE TABLE `glpi_ssovariables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ssovariables` VALUES ('1','HTTP_AUTH_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('2','REMOTE_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('3','PHP_AUTH_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('4','USERNAME','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('5','REDIRECT_REMOTE_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('6','HTTP_REMOTE_USER','',NULL,NULL);

### Dump table glpi_states

DROP TABLE IF EXISTS `glpi_states`;
CREATE TABLE `glpi_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `states_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_visible_computer` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_monitor` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_networkequipment` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_peripheral` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_phone` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_printer` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_softwareversion` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_softwarelicense` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `unicity` (`states_id`,`name`),
  KEY `is_visible_computer` (`is_visible_computer`),
  KEY `is_visible_monitor` (`is_visible_monitor`),
  KEY `is_visible_networkequipment` (`is_visible_networkequipment`),
  KEY `is_visible_peripheral` (`is_visible_peripheral`),
  KEY `is_visible_phone` (`is_visible_phone`),
  KEY `is_visible_printer` (`is_visible_printer`),
  KEY `is_visible_softwareversion` (`is_visible_softwareversion`),
  KEY `is_visible_softwarelicense` (`is_visible_softwarelicense`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_suppliers

DROP TABLE IF EXISTS `glpi_suppliers`;
CREATE TABLE `glpi_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suppliertypes_id` int(11) NOT NULL DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `suppliertypes_id` (`suppliertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_suppliers_tickets

DROP TABLE IF EXISTS `glpi_suppliers_tickets`;
CREATE TABLE `glpi_suppliers_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_suppliertypes

DROP TABLE IF EXISTS `glpi_suppliertypes`;
CREATE TABLE `glpi_suppliertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_taskcategories

DROP TABLE IF EXISTS `glpi_taskcategories`;
CREATE TABLE `glpi_taskcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_helpdeskvisible` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_active` (`is_active`),
  KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tasktemplates

DROP TABLE IF EXISTS `glpi_tasktemplates`;
CREATE TABLE `glpi_tasktemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketcosts

DROP TABLE IF EXISTS `glpi_ticketcosts`;
CREATE TABLE `glpi_ticketcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `tickets_id` (`tickets_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketfollowups

DROP TABLE IF EXISTS `glpi_ticketfollowups`;
CREATE TABLE `glpi_ticketfollowups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `requesttypes_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `is_private` (`is_private`),
  KEY `requesttypes_id` (`requesttypes_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ticketfollowups` VALUES ('1','113','2017-02-08 04:11:00','6','ดำเนินการส่งซ่อม Stor Sunwing','0','1','2017-02-08 04:11:00');
INSERT INTO `glpi_ticketfollowups` VALUES ('2','113','2017-02-08 04:11:31','6','ทาง Store  SUNWING แจ้งว่าสามารถใช้งานได้ปกติ
คิดค่าเปิด Print 300 เนื่องจากไม่เสีย','0','1','2017-02-08 04:11:31');

### Dump table glpi_ticketrecurrents

DROP TABLE IF EXISTS `glpi_ticketrecurrents`;
CREATE TABLE `glpi_ticketrecurrents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `begin_date` datetime DEFAULT NULL,
  `periodicity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_before` int(11) NOT NULL DEFAULT '0',
  `next_creation_date` datetime DEFAULT NULL,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_active` (`is_active`),
  KEY `tickettemplates_id` (`tickettemplates_id`),
  KEY `next_creation_date` (`next_creation_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickets

DROP TABLE IF EXISTS `glpi_tickets`;
CREATE TABLE `glpi_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `requesttypes_id` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `global_validation` int(11) NOT NULL DEFAULT '1',
  `slts_tto_id` int(11) NOT NULL DEFAULT '0',
  `slts_ttr_id` int(11) NOT NULL DEFAULT '0',
  `ttr_slalevels_id` int(11) NOT NULL DEFAULT '0',
  `due_date` datetime DEFAULT NULL,
  `time_to_own` datetime DEFAULT NULL,
  `begin_waiting_date` datetime DEFAULT NULL,
  `sla_waiting_duration` int(11) NOT NULL DEFAULT '0',
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `takeintoaccount_delay_stat` int(11) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `validation_percent` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `request_type` (`requesttypes_id`),
  KEY `date_mod` (`date_mod`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `global_validation` (`global_validation`),
  KEY `slts_tto_id` (`slts_tto_id`),
  KEY `slts_ttr_id` (`slts_ttr_id`),
  KEY `due_date` (`due_date`),
  KEY `time_to_own` (`time_to_own`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `type` (`type`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `name` (`name`),
  KEY `locations_id` (`locations_id`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickets` VALUES ('1','0','WIFI R6219 ใช้งานไม่ได้ ตัดทุกๆ5นาที','2017-01-01 08:45:00','2017-02-06 04:26:09','2017-02-06 04:26:09','2017-02-06 04:26:09','6','6','6','1','WIFI R6219 ใช้งานไม่ได้ ตัดทุกๆ5นาที','3','3','3','10','1','0','&lt;p&gt;Switch ใต้ตึกดับ ดำเนินการแก้ไขแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','3094869','3094869','3094869','0','0','0','0','2017-02-06 04:23:59');
INSERT INTO `glpi_tickets` VALUES ('2','0','Print ใบเสร็จเป็นภาษาต่างดาว','2017-01-02 08:28:00','2017-02-06 04:30:51','2017-02-06 04:30:51','2017-02-06 04:30:51','6','6','6','1','Print ใบเสร็จเป็นภาษาต่างดาว','3','3','3','13','1','0','&lt;p&gt;เมนบอร์ดเสีย  ได้ดำเนินการเปลี่ยนคอมพิวเตอร์ให้ใหม่&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','3009771','3009771','3009771','0','0','0','0','2017-02-06 04:29:52');
INSERT INTO `glpi_tickets` VALUES ('3','0','แก้ไข ระยะเวลา Authen Relogin Sunprime','2017-01-02 13:30:00','2017-02-06 04:33:47','2017-02-06 04:33:47','2017-02-06 04:33:47','6','6','6','1','ประชุมกับคุณ Henlix และคุณวิสุต
แก้ไข ระยะเวลา Authen Relogin Sunprime','3','3','3','10','1','0','&lt;p&gt;ปรับเวลาเป็น 7 วัน ใน Authen&lt;/p&gt;
&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2991827','2991827','2991827','0','0','0','0','2017-02-06 04:33:07');
INSERT INTO `glpi_tickets` VALUES ('4','0','UPS เสีย Accounting Room','2017-01-03 10:33:00','2017-02-06 04:35:26','2017-02-06 04:35:26','2017-02-06 04:35:26','6','6','6','1','UPS เสีย Accounting Room','3','3','3','22','1','0','&lt;p&gt;เปลี่ยน UPS Accounting Room&lt;/p&gt;
&lt;p&gt;User ใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2916146','2916146','2916146','0','0','0','0','2017-02-06 04:35:02');
INSERT INTO `glpi_tickets` VALUES ('5','0','Computer เสีย','2017-01-03 09:35:00','2017-02-06 04:38:10','2017-02-06 04:38:10','2017-02-06 04:38:10','6','6','6','1','Computer เสีย พี่นี Store','3','3','3','2','1','0','&lt;p&gt;สายปลั๊กไฟหลุด&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2919790','2919790','2919790','0','0','0','0','2017-02-06 04:37:37');
INSERT INTO `glpi_tickets` VALUES ('6','0','Printer ใช้งานไม่ได้','2017-01-03 10:38:00','2017-02-06 04:41:28','2017-02-06 04:41:28','2017-02-06 04:41:28','6','6','6','1','Epson 220 พี่นก Store','3','3','3','71','1','0','&lt;p&gt;ลงไดร์เวอร์ใหม่ User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2916208','2916208','2916208','0','0','0','0','2017-02-06 04:39:39');
INSERT INTO `glpi_tickets` VALUES ('7','0','Authen ไม่ขึ้นหน้า Login','2017-01-03 14:39:00','2017-02-06 04:49:27','2017-02-06 04:49:27','2017-02-06 04:49:27','6','6','6','1','Authen ไม่ขึ้นหน้า Login R7206','3','3','3','65','1','0','&lt;p&gt;เบื้องต้นดำเนินากร Bypass ให้แขกใช้งานก่อนครับ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2902227','2902227','2901985','0','0','0','0','2017-02-06 04:42:39');
INSERT INTO `glpi_tickets` VALUES ('8','0','Printer Hr หมึกหมด','2017-02-06 04:49:34','2017-02-06 04:50:37','2017-02-06 04:50:37','2017-02-06 04:50:37','6','6','6','1','Printer Hr หมึกหมด','3','3','3','71','1','0','&lt;p&gt;ดำเนินการเปลี่ยนให้เรียบร้อยแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','63','63','63','0','0','0','0','2017-02-06 04:49:59');
INSERT INTO `glpi_tickets` VALUES ('9','0','Iphone Guest R6116 ไม่สามารถใช้งานได้','2017-01-04 10:50:00','2017-02-06 04:52:07','2017-02-06 04:52:07','2017-02-06 04:52:07','6','6','6','1','Iphone Guest R6116 ไม่สามารถใช้งานได้','3','3','3','65','1','0','&lt;p&gt;เบื้องต้น Bypass ให้แขกใช้งานได้ก่อน&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2829727','2829727','2829727','0','0','0','0','2017-02-06 04:51:34');
INSERT INTO `glpi_tickets` VALUES ('10','0','PDF File เปิดไม่ได้','2017-01-04 11:52:00','2017-02-06 04:53:55','2017-02-06 04:53:55','2017-02-06 04:53:55','6','6','6','1','ได้รับแจ้งจากคุณ KAR ว่า PDF File เปิดไม่ได้','3','3','3','27','1','0','&lt;p&gt;ลงโปรแกรมใหม่ User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2826115','2826115','2826115','0','0','0','0','2017-02-06 04:53:34');
INSERT INTO `glpi_tickets` VALUES ('11','0','Report Sale Slip ไม่ขึ้น Fromas','2017-01-04 14:09:00','2017-02-06 05:11:05','2017-02-06 05:11:05','2017-02-06 05:11:05','6','6','6','1','Ging แจ้งว่า Report Sale Slip ไม่ขึ้น Fromas','3','3','3','33','1','0','&lt;p&gt;ลงโปรแกรม Fromas ใหม่ใช้งานได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2818925','2818925','2818925','0','0','0','0','2017-02-06 05:10:42');
INSERT INTO `glpi_tickets` VALUES ('12','0','computer ช้า','2017-02-06 05:11:11','2017-02-06 05:13:11','2017-02-06 05:13:11','2017-02-06 05:13:11','6','6','6','1','พี่หญิง Sunprime Kitchen','3','3','3','2','1','0','&lt;p&gt;ลงวินโดวใหม่ ใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','120','120','120','0','0','0','0','2017-02-06 05:12:17');
INSERT INTO `glpi_tickets` VALUES ('13','0','เปิด Report Income ไม่ได้','2017-01-04 16:13:00','2017-02-06 05:14:56','2017-02-06 05:14:56','2017-02-06 05:14:56','6','6','6','1','พี่สาว บัญชี เปิด Report Income ไม่ได้','3','3','3','37','1','0','&lt;p&gt;Path หลุดได้ดำเนินการแก้ไขแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2811716','2811716','2811716','0','0','0','0','2017-02-06 05:14:14');
INSERT INTO `glpi_tickets` VALUES ('14','0','Computer ใช้งานไม่ได้','2017-01-06 09:15:00','2017-02-06 05:16:27','2017-02-06 05:16:27','2017-02-06 05:16:27','6','6','6','1','ครัว Bythesea Computer ใช้งานไม่ได้','3','3','3','9','1','0','&lt;p&gt;สาย Lan หลวม ดำเนินการแก้ไขแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2664087','2664087','2664087','0','0','0','0','2017-02-06 05:16:05');
INSERT INTO `glpi_tickets` VALUES ('15','0','Pol Bar By the Pool computer slow','2017-01-06 10:16:00','2017-02-06 05:19:02','2017-02-06 05:19:02','2017-02-06 05:19:02','6','6','6','1','Pol Bar By the Pool computer slow','3','3','3','2','1','0','&lt;p&gt;ลงวินโดวใหม่ใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2660582','2660582','2660582','0','0','0','0','2017-02-06 05:17:24');
INSERT INTO `glpi_tickets` VALUES ('16','0','wifi r3230 ใช้งานไม่ได้','2017-01-06 13:17:00','2017-02-06 05:24:12','2017-02-06 05:24:12','2017-02-06 05:24:12','6','6','6','1','wifi r3230 ใช้งานไม่ได้','3','3','3','10','1','0','&lt;p&gt;Reboot Ap ใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2650032','2650032','2650032','0','0','0','0','2017-02-06 05:23:50');
INSERT INTO `glpi_tickets` VALUES ('17','0','COMPUTER Crenic Printer มีปัญหา','2017-01-06 15:06:00','2017-02-08 01:11:06','2017-02-08 01:11:06','2017-02-08 01:11:06','6','6','6','1','COMPUTER Crenic Printer มีปัญหา','3','3','3','69','1','0','&lt;p&gt;แนะนำวิธีการใช้งาน&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2801106','2801106','2801106','0','0','0','0','2017-02-08 01:10:22');
INSERT INTO `glpi_tickets` VALUES ('18','0','computer ไม่สามารถใช้งานได้','2017-01-06 16:10:00','2017-02-08 01:12:34','2017-02-08 01:12:34','2017-02-08 01:12:34','6','6','6','1','computer ไม่สามารถใช้งานได้','3','3','3','2','1','0','&lt;p&gt;ไฟ 220v เสีย&lt;/p&gt;
&lt;p&gt;แจ้งช่างดำเนินการเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2797354','2797354','2797354','0','0','0','0','2017-02-08 01:11:58');
INSERT INTO `glpi_tickets` VALUES ('19','0','com KC ช้า','2017-01-06 08:11:00','2017-02-08 01:14:09','2017-02-08 01:14:09','2017-02-08 01:14:09','6','6','6','1','com KC ช้า','3','3','3','8','1','0','&lt;p&gt;ใส่การ์ด Lan ใหม่ ใช้งานได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2826189','2826189','2826189','0','0','0','0','2017-02-08 01:13:42');
INSERT INTO `glpi_tickets` VALUES ('20','0','I-phone แขก ไม่สามารถ Login ได้ ไม่ขึ้นหน้า Login','2017-01-07 09:13:00','2017-02-08 01:15:56','2017-02-08 01:15:56','2017-02-08 01:15:56','6','6','6','1','I-phone แขก ไม่สามารถ Login ได้ ไม่ขึ้นหน้า Login','3','3','3','65','1','0','&lt;p&gt;ดำเนินการ Bypass &lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2736176','2736176','2736176','0','0','0','0','2017-02-08 01:15:15');
INSERT INTO `glpi_tickets` VALUES ('21','0','เครื่องพี่ปุ๊กใช้งาน adobe illustrator ไม่ได้','2017-01-07 11:20:00','2017-02-08 01:22:32','2017-02-08 01:22:32','2017-02-08 01:22:32','6','6','6','1','เครื่องพี่ปุ๊กใช้งาน adobe illustrator ไม่ได้','3','3','3','74','1','0','&lt;p&gt;ติดตั้งโปรแกรมใหม่&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2728952','2728952','2728952','0','0','0','0','2017-02-08 01:21:29');
INSERT INTO `glpi_tickets` VALUES ('22','0','comcash FB By the sea เด่งออกเวลากด Total','2017-01-07 13:21:00','2017-02-08 01:23:47','2017-02-08 01:23:47','2017-02-08 01:23:47','6','6','6','1','comcash FB By the sea เด่งออกเวลากด Total','3','3','3','43','1','0','&lt;p&gt;ลงโปรแกรมใหม่&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2721767','2721767','2721767','0','0','0','0','2017-02-08 01:23:29');
INSERT INTO `glpi_tickets` VALUES ('23','0','จอไม่ติดRestaurant Grand The pool','2017-01-07 14:23:00','2017-02-08 01:25:18','2017-02-08 01:25:18','2017-02-08 01:25:18','6','6','6','1','จอไม่ติดRestaurant Grand The pool','3','3','3','3','1','0','&lt;p&gt;สายไฟหลวม&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2718138','2718138','2718138','0','0','0','0','2017-02-08 01:25:00');
INSERT INTO `glpi_tickets` VALUES ('24','0','FB LATASCA COMCASH ค้าง Sever ช้า','2017-01-07 15:25:00','2017-02-08 01:26:46','2017-02-08 01:26:46','2017-02-08 01:26:46','6','6','6','1','FB LATASCA COMCASH ค้าง Sever ช้า','3','3','3','43','1','0','&lt;p&gt;เบื้องต้นได้อัพเดทโปรแกรมใหม่แล้วแต่ยังคงเกิดปัญหา&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2714506','2714506','2714506','0','0','0','0','2017-02-08 01:26:18');
INSERT INTO `glpi_tickets` VALUES ('25','0','พี่พร DVR 130 ดูไม่ได้','2017-01-07 16:26:00','2017-02-08 01:28:04','2017-02-08 01:28:04','2017-02-08 01:28:04','6','6','6','1','พี่พร DVR 130 ดูไม่ได้','3','3','3','47','1','0','&lt;p&gt;REBOOT DVR ใหม่ สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2710924','2710924','2710924','0','0','0','0','2017-02-08 01:27:42');
INSERT INTO `glpi_tickets` VALUES ('26','0','แชร์ google Drive ไม่ได้ ENG KML','2017-01-08 08:29:00','2017-02-08 01:30:52','2017-02-08 01:30:52','2017-02-08 01:30:52','6','6','6','1','แชร์ google Drive ไม่ได้ ENG KML','3','3','3','75','1','0','&lt;p&gt;สอนวิธีการใช้งาน&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2653312','2653312','2653312','0','0','0','0','2017-02-08 01:30:36');
INSERT INTO `glpi_tickets` VALUES ('27','0','ติดตั้งโปรแกรม Fromas Clinic','2017-01-08 10:30:00','2017-02-08 01:31:52','2017-02-08 01:31:52','2017-02-08 01:31:52','6','6','6','1','ติดตั้งโปรแกรม Fromas Clinic','3','3','3','33','1','0','&lt;p&gt;ดำเนินการติดตั้งให้เรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2646112','2646112','2646112','0','0','0','0','2017-02-08 01:31:27');
INSERT INTO `glpi_tickets` VALUES ('28','0','Keyboard Fino เสีย','2017-01-09 11:31:00','2017-02-08 01:33:55','2017-02-08 01:33:55','2017-02-08 01:33:55','6','6','6','1','Keyboard Fino เสีย','3','3','3','5','1','0','&lt;p&gt;เปลี่ยน Keyboard ใหม่&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2556175','2556175','2556175','0','0','0','0','2017-02-08 01:33:32');
INSERT INTO `glpi_tickets` VALUES ('29','0','คอม HR ใช้งาน internet ช้า','2017-01-09 13:33:00','2017-02-08 01:35:33','2017-02-08 01:35:33','2017-02-08 01:35:33','6','6','6','1','คอม HR ใช้งาน internet ช้า','3','3','3','60','1','0','&lt;p&gt;เปลั้ยน Lan Card ใหม่&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2548953','2548953','2548953','0','0','0','0','2017-02-08 01:35:04');
INSERT INTO `glpi_tickets` VALUES ('30','0','Computer พี่ก้อย Ap ช้า','2017-01-09 15:35:00','2017-02-08 01:36:49','2017-02-08 01:36:49','2017-02-08 01:36:49','6','6','6','1','Computer พี่ก้อย Ap ช้า','3','3','3','2','1','0','&lt;p&gt;ลงโปรแกรมใหม่ใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2541709','2541709','2541709','0','0','0','0','2017-02-08 01:36:29');
INSERT INTO `glpi_tickets` VALUES ('31','0','Com หน้า Front ใช้งานโปรแกรม Fromas ไม่ได้','2017-01-10 08:36:00','2017-02-08 01:38:29','2017-02-08 01:38:29','2017-02-08 01:38:29','6','6','6','1','Com หน้า Front ใช้งานโปรแกรม Fromas ไม่ได้
กะโสมแจ้ง','3','3','3','33','1','0','&lt;p&gt;ลงโปรแกรม Fromas ใหม่&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2480549','2480549','2480549','0','0','0','0','2017-02-08 01:37:49');
INSERT INTO `glpi_tickets` VALUES ('32','0','Macbook madam r1335 update OS ไม่ได้','2017-01-10 11:37:00','2017-02-08 01:40:27','2017-02-08 01:40:27','2017-02-08 01:40:27','6','6','6','1','Macbook madam r1335 update OS ไม่ได้','3','3','3','10','1','0','&lt;p&gt;ดำเนินการ Bypass ให้แกแล้วแต่ยังคงไม่สามารถใช้งานได้&lt;/p&gt;
&lt;p&gt; OS  Macbook เสียต้องส่งศูนย์&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2469807','2469807','2469807','0','0','0','0','2017-02-08 01:39:44');
INSERT INTO `glpi_tickets` VALUES ('33','0','Printer หมึกหมด','2017-01-10 15:39:00','2017-02-08 01:41:33','2017-02-08 01:41:33','2017-02-08 01:41:33','6','6','6','1','Printer หมึกหมด
พี่นก Store','3','3','3','71','1','0','&lt;p&gt;ส่งเติมหมึกแล้ว&lt;/p&gt;
&lt;p&gt;ดำเนินการการนำมาติดตั้งให้แล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2455353','2455353','2455353','0','0','0','0','2017-02-08 01:41:10');
INSERT INTO `glpi_tickets` VALUES ('34','0','Fromas Sunprime ช้า','2017-01-11 08:41:00','2017-02-08 01:42:44','2017-02-08 01:42:44','2017-02-08 01:42:44','6','6','6','1','Fromas Sunprime ช้า
มีการอัพเดทโปรแกรม','3','3','3','33','1','0','&lt;p&gt;ทางนิวซอฟเข้ามาดำเนินการอัพเดทโปรแกรมใหม่&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2394104','2394104','2394104','0','0','0','0','2017-02-08 01:42:20');
INSERT INTO `glpi_tickets` VALUES ('35','0','มีการย้ายเซิฟเวอร์ใหม่ ดำเนินการแจ้งคุณรัษ ให้ย้ายIPU SERVER sunwing','2017-01-11 10:42:00','2017-02-08 01:44:33','2017-02-08 01:44:33','2017-02-08 01:44:33','6','6','6','1','มีการย้ายเซิฟเวอร์ใหม่ ดำเนินการแจ้งคุณรัษ ให้ย้ายIPU SERVER sunwing','3','3','3','73','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้วครับ&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2386953','2386953','2386953','0','0','0','0','2017-02-08 01:43:56');
INSERT INTO `glpi_tickets` VALUES ('36','0','ดำเนินการ Check DVR 126','2017-01-11 14:43:00','2017-02-08 01:46:08','2017-02-08 01:46:08','2017-02-08 01:46:08','6','6','6','1','ดำเนินการ Check DVR 126','3','3','3','47','1','0','&lt;p&gt;ดำเนินการตรวจสอบแล้ว&lt;/p&gt;
&lt;p&gt;สามารถดูออนไลน์ได้ปกติแต่ CHANNEL บางจุดยังมีปัญหา&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2372588','2372588','2372588','0','0','0','0','2017-02-08 01:45:10');
INSERT INTO `glpi_tickets` VALUES ('37','0','Set line lan sofie at office Sunwing','2017-01-11 18:50:00','2017-02-08 01:51:43','2017-02-08 01:51:43','2017-02-08 01:51:43','6','6','6','1','Set line lan sofie at office Sunwing','3','3','3','9','1','0','&lt;p&gt;setup already&lt;/p&gt;
&lt;p&gt;user available.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2358103','2358103','2358103','0','0','0','0','2017-02-08 01:50:39');
INSERT INTO `glpi_tickets` VALUES ('38','0','Set คอมพี่ก้อย และ Join Domain','2017-01-13 10:50:00','2017-02-08 01:52:39','2017-02-08 01:52:39','2017-02-08 01:52:39','6','6','6','1','Set คอมพี่ก้อย และ Join Domain','3','3','3','2','1','0','&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2214159','2214159','2214159','0','0','0','0','2017-02-08 01:52:23');
INSERT INTO `glpi_tickets` VALUES ('39','0','DVR136 ดูไม่ได้','2017-01-13 13:52:00','2017-02-08 01:53:41','2017-02-08 01:53:41','2017-02-08 01:53:41','6','6','6','1','DVR136 ดูไม่ได้','3','3','3','47','1','0','&lt;p&gt;REBOOT DVR136&lt;/p&gt;
&lt;p&gt;สามารถดูได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2203301','2203301','2203301','0','0','0','0','2017-02-08 01:53:22');
INSERT INTO `glpi_tickets` VALUES ('40','0','Iphone แขกไม่สามรถใช้งานwifi ได้','2017-01-13 14:53:00','2017-02-08 01:54:55','2017-02-08 01:54:55','2017-02-08 01:54:55','6','6','6','1','Iphone แขกไม่สามรถใช้งานwifi ได้','3','3','3','65','1','0','&lt;p&gt;Bypass iphone Guest&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2199715','2199715','2199715','0','0','0','0','2017-02-08 01:54:26');
INSERT INTO `glpi_tickets` VALUES ('41','0','Guest want to see TV APPLE','2017-01-13 14:55:00','2017-02-08 01:56:51','2017-02-08 01:56:51','2017-02-08 01:56:51','6','6','6','1','Guest want to see TV APPLE 
But tv apple can\'t authen wifi sunwing
r1417','3','3','3','10','1','0','&lt;p&gt;Bypass TV APPLE Already.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2199711','2199711','2199711','0','0','0','0','2017-02-08 01:56:26');
INSERT INTO `glpi_tickets` VALUES ('42','0','Iphone แขกไม่สามรถใช้งานwifi ได้ sunprime','2017-01-13 15:56:00','2017-02-08 01:58:04','2017-02-08 01:58:04','2017-02-08 01:58:04','6','6','6','1','Iphone แขกไม่สามรถใช้งานwifi ได้ sunprime','3','3','3','65','1','0','&lt;p&gt;Bypass iphone Guest&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2196124','2196124','2196124','0','0','0','0','2017-02-08 01:57:48');
INSERT INTO `glpi_tickets` VALUES ('43','0','ไม่สามารถเชื่อมต่อ wifi sunprime ได้','2017-01-14 16:57:00','2017-02-08 02:00:05','2017-02-08 02:00:05','2017-02-08 02:00:05','6','6','6','1','ไม่สามารถเชื่อมต่อ wifi sunprime ได้
ไม่ได้รับ DHCP','3','3','3','10','1','0','&lt;p&gt;Mikrotik มีปัญหาให้ทางคุณแจ็ค AMATI restore ค่าคอนฟิกไปวันที่12 ช่วงที่พี่ตุ้งลงมาติดตั้ง&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2106185','2106185','2106185','0','0','0','0','2017-02-08 01:59:18');
INSERT INTO `glpi_tickets` VALUES ('44','0','ดำเนินการ Check DVR 126 Ch ที่เหลือ','2017-01-14 09:59:00','2017-02-08 02:01:51','2017-02-08 02:01:51','2017-02-08 02:01:51','6','6','6','1','ดำเนินการ Check DVR 126 Ch ที่เหลือ','3','3','3','47','1','0','&lt;p&gt;restore format factory Default DVR&lt;/p&gt;
&lt;p&gt;ทำการเซ็ตค่าใหม่ยังไม่หาย&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2131371','2131371','2131371','0','0','0','0','2017-02-08 02:00:59');
INSERT INTO `glpi_tickets` VALUES ('45','0','Wifi แขก sunwing ไม่สามารถใช้งานได้','2017-01-14 14:01:00','2017-02-08 02:03:18','2017-02-08 02:03:18','2017-02-08 02:03:18','6','6','6','1','Wifi แขก sunwing ไม่สามารถใช้งานได้','3','3','3','10','1','0','&lt;p&gt;Mikrotik มีปัญหาให้ทางพี่แจ็ค Amati restore ไปวันที่12&lt;/p&gt;
&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2116938','2116938','2116938','0','0','0','0','2017-02-08 02:02:43');
INSERT INTO `glpi_tickets` VALUES ('46','0','Login wifi มีปัญหา','2017-01-14 16:02:00','2017-02-08 02:04:19','2017-02-08 02:04:19','2017-02-08 02:04:19','6','6','6','1','Login wifi มีปัญหา','3','3','3','10','1','0','&lt;p&gt;Mikrotik มีปัญหาต้องให้ทางพี่แจ็ค Amati resort เป้นวันที่ 12&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2109739','2109739','2109739','0','0','0','0','2017-02-08 02:03:55');
INSERT INTO `glpi_tickets` VALUES ('47','0','คุณ Johan พาเดิน Lobby ตึก6 สระ connect wifi และแจ้งปัญหาwifi','2017-01-14 17:03:00','2017-02-08 02:07:19','2017-02-08 02:07:19','2017-02-08 02:07:19','6','6','6','1','คุณ Johan พาเดิน Lobby ตึก6 สระ connect wifi และแจ้งปัญหาwifi','3','3','3','10','1','0','&lt;p&gt;Mikrotik ค่า Config มีปัญหา ส่งผลให้ wifi ทั้งระบบล่ม &lt;/p&gt;
&lt;p&gt;ซึ่งวันที่12 ได้ทำการ Backup ค่า Config ของทาง NEWSOFT ไว้ จึงสามารถแก้ไขปัญหาดังกล่าวได้ให้สามารถใช้งานได้ตามปกติ&lt;/p&gt;
&lt;p&gt;ทั้งนี้ได้ประสานงานกับคุณแจ็ค Amati ให้ดำเนินการ แก้ไข MIkrotik แล้ว&lt;/p&gt;
&lt;p&gt;หลังจาก Resote สามารถใช้งานได้ตามปกติแล้วครับ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2106259','2106259','2106259','0','0','0','0','2017-02-08 02:05:31');
INSERT INTO `glpi_tickets` VALUES ('48','0','ปัญหา wifi ตามตึก sunprime','2017-01-15 10:07:00','2017-02-08 02:08:49','2017-02-08 02:08:49','2017-02-08 02:08:49','6','6','6','1','ปัญหา wifi ตามตึก sunprime','3','3','3','10','1','0','&lt;p&gt;Restore Mikrotik&lt;/p&gt;
&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2044909','2044909','2044909','0','0','0','0','2017-02-08 02:08:23');
INSERT INTO `glpi_tickets` VALUES ('49','0','ปัญหา Hr @payroll','2017-01-15 11:08:00','2017-02-08 02:22:07','2017-02-08 02:22:07','2017-02-08 02:22:07','6','6','6','1','ปัญหา Hr @payroll','3','3','3','29','1','0','&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2042047','2042047','2042047','0','0','0','0','2017-02-08 02:21:52');
INSERT INTO `glpi_tickets` VALUES ('50','0','เปลี่ยน DVR 126','2017-01-15 14:21:00','2017-02-08 02:23:20','2017-02-08 02:23:20','2017-02-08 02:23:20','6','6','6','1','เปลี่ยน DVR 126','3','3','3','47','1','0','&lt;p&gt;เปลี่ยน DVR126 เพื่อนทดสอบ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2030540','2030540','2030540','0','0','0','0','2017-02-08 02:22:40');
INSERT INTO `glpi_tickets` VALUES ('51','0','เครื่องแนน ทำการ Join Domain','2017-01-15 14:22:00','2017-02-08 02:24:29','2017-02-08 02:24:29','2017-02-08 02:24:29','6','6','6','1','เครื่องแนน ทำการ Join Domain','3','3','3','2','1','0','&lt;p&gt;ดำเนินการ Join Domain แล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','2030549','2030549','2030549','0','0','0','0','2017-02-08 02:24:09');
INSERT INTO `glpi_tickets` VALUES ('52','0','Printer ไม่ตัดกระดาษ Latasca','2017-02-08 02:24:09','2017-02-08 02:25:54','2017-02-08 02:25:54','2017-02-08 02:25:54','6','6','6','1','Printer ไม่ตัดกระดาษ Latasca','3','3','3','70','1','0','&lt;p&gt;เปลี่ยน ใบมีดแล้วใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','105','105','105','0','0','0','0','2017-02-08 02:25:25');
INSERT INTO `glpi_tickets` VALUES ('53','0','Smartphone Guest non pop up login','2017-01-17 14:25:00','2017-02-08 02:27:17','2017-02-08 02:27:17','2017-02-08 02:27:17','6','6','6','1','Smartphone Guest non pop up login','3','3','3','10','1','0','&lt;p&gt;Bypass smart phone&lt;/p&gt;
&lt;p&gt;Guest available.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1857737','1857737','1857737','0','0','0','0','2017-02-08 02:26:43');
INSERT INTO `glpi_tickets` VALUES ('54','0','Comcash latasca summery ไม่ออก','2017-01-17 16:26:00','2017-02-08 02:28:45','2017-02-08 02:28:45','2017-02-08 02:28:45','6','6','6','1','Comcash latasca summery ไม่ออก','3','3','3','43','1','0','&lt;p&gt;ได้ปรึกษากับทางพี่เอสและแจ้งทาง Newsoft ให้แก้ไขแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1850565','1850565','1850565','0','0','0','0','2017-02-08 02:28:06');
INSERT INTO `glpi_tickets` VALUES ('55','0','wifi R3104 LOGIN ไม่ได้','2017-01-18 14:28:00','2017-02-08 02:31:08','2017-02-08 02:31:08','2017-02-08 02:31:08','6','6','6','1','wifi R3104 LOGIN ไม่ได้','3','3','3','10','1','0','&lt;p&gt;GROUP ที่ระบบสร้างเป็น signup&lt;/p&gt;
&lt;p&gt;ย้ายกลุ่มใหม่เป็น Free ก็ยังไม่ได้&lt;/p&gt;
&lt;p&gt;ลบ Account และสร้างใหม่ใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1771388','1771388','1771388','0','0','0','0','2017-02-08 02:30:28');
INSERT INTO `glpi_tickets` VALUES ('56','0','Key Registor Program Newsoft หลุด','2017-01-18 19:24:00','2017-02-08 02:32:38','2017-02-08 02:32:38','2017-02-08 02:32:38','6','6','6','1','Key Registor Program Newsoft หลุด
19.24','3','3','3','63','1','0','&lt;p&gt;แจ้งคุณ Art ให้ลงทะเบียนให้ใหม่ ใช้ระยะเวลา10นาที&lt;/p&gt;
&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1753718','1753718','1753718','0','0','0','0','2017-02-08 02:31:58');
INSERT INTO `glpi_tickets` VALUES ('57','0','ลง MSOFFICE ใหม่ เครื่อง Khon Anusorn','2017-01-18 21:31:00','2017-02-08 02:33:42','2017-02-08 02:33:42','2017-02-08 02:33:42','6','6','6','1','ลง MSOFFICE ใหม่ เครื่อง Khon Anusorn','3','3','3','27','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1746162','1746162','1746162','0','0','0','0','2017-02-08 02:33:22');
INSERT INTO `glpi_tickets` VALUES ('58','0','Scan virus computer Khun หมอ wittawat','2017-01-18 19:18:00','2017-02-08 02:35:18','2017-02-08 02:35:18','2017-02-08 02:35:18','6','6','6','1','Scan virus computer Khun หมอ wittawat','3','3','3','75','1','0','&lt;p&gt;ดำเนินการติดตั้ง bytemailware&lt;/p&gt;
&lt;p&gt;ทำการสแกนเรียบร้อยแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1754238','1754238','1754238','0','0','0','0','2017-02-08 02:34:45');
INSERT INTO `glpi_tickets` VALUES ('59','0','Wifi แขก login ไม่ได้ Front sunwing','2017-01-18 20:34:00','2017-02-08 02:36:48','2017-02-08 02:36:48','2017-02-08 02:36:48','6','6','6','1','Wifi แขก login ไม่ได้ Front sunwing
Iphone แขกมีปัญหา','3','3','3','10','1','0','&lt;p&gt;OS IPHONE แขกมีปัญหา Connect ไม่ได้&lt;/p&gt;
&lt;p&gt;ต้องลองหลายรอบกว่าจะสามารถใช้งานได้&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1749768','1749768','1749768','0','0','0','0','2017-02-08 02:36:07');
INSERT INTO `glpi_tickets` VALUES ('60','0','DVR123 HDD ไม่บันทึกภาพ','2017-01-19 18:36:00','2017-02-08 02:37:46','2017-02-08 02:37:46','2017-02-08 02:37:46','6','6','6','1','DVR123 HDD ไม่บันทึกภาพ','3','3','3','47','1','0','&lt;p&gt;ดำเนินการเปลี่ยน HDD ใหม่แล้ว&lt;/p&gt;
&lt;p&gt;รอผลการทดสอบ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1670506','1670506','1670506','0','0','0','0','2017-02-08 02:37:21');
INSERT INTO `glpi_tickets` VALUES ('61','0','Check Excel Khun Anusorn','2017-01-19 20:37:00','2017-02-08 02:38:44','2017-02-08 02:38:44','2017-02-08 02:38:44','6','6','6','1','Check Excel Khun Anusorn','3','3','3','27','1','0','&lt;p&gt;ดำเนินการตรวจเช็คแล้วสามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1663304','1663304','1663304','0','0','0','0','2017-02-08 02:38:28');
INSERT INTO `glpi_tickets` VALUES ('62','0','Printer ไม่ตัดกระดาษ Latasca','2017-01-19 20:38:00','2017-02-08 02:39:36','2017-02-08 02:39:36','2017-02-08 02:39:36','6','6','6','1','Check Excel Khun Anusorn','3','3','3','70','1','0','&lt;p&gt;รอดำเนินการเปลี่ยนเครื่องใหม่ &lt;/p&gt;
&lt;p&gt;เบื้องต้นสลับใบมีดใช้งานไปก่อน&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1663296','1663296','1663296','0','0','0','0','2017-02-08 02:39:14');
INSERT INTO `glpi_tickets` VALUES ('63','0','Comcash Cost Imegretion Used Summary ไม่แสดง','2017-01-20 19:39:00','2017-02-08 02:41:25','2017-02-08 02:41:25','2017-02-08 02:41:25','6','6','6','1','Comcash Cost Imegretion Used Summary ไม่แสดง','3','3','3','43','1','0','&lt;p&gt;เป็นปัญหา Config ใน Server แจ้งทาง Art แก้ไขแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1580545','1580545','1580545','0','0','0','0','2017-02-08 02:40:28');
INSERT INTO `glpi_tickets` VALUES ('64','0','Bill Double Latasca','2017-01-20 19:40:00','2017-02-08 02:42:39','2017-02-08 02:42:39','2017-02-08 02:42:39','6','6','6','1','Bill Double Latasca','3','3','3','43','1','0','&lt;p&gt;upgrade conputer เพิ่ม Ram 2G&lt;/p&gt;
&lt;p&gt;ลงโปรแกรม Comcash ใหม่&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1580559','1580559','1580559','0','0','0','0','2017-02-08 02:42:13');
INSERT INTO `glpi_tickets` VALUES ('65','0','เปลี่ยนDVR 123 ตัวใหม่เนื่องจากไม่บันทึกภาพ','2017-01-20 20:42:00','2017-02-08 02:43:57','2017-02-08 02:43:57','2017-02-08 02:43:57','6','6','6','1','เปลี่ยนDVR 123 ตัวใหม่เนื่องจากไม่บันทึกภาพ','3','3','3','47','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1576917','1576917','1576917','0','0','0','0','2017-02-08 02:43:38');
INSERT INTO `glpi_tickets` VALUES ('66','0','Outlet pk by the sea Check report ไม่ได้','2017-01-20 22:00:00','2017-02-08 02:45:31','2017-02-08 02:45:31','2017-02-08 02:45:31','6','6','6','1','Outlet pk by the sea Check report ไม่ได้','3','3','3','43','1','0','&lt;p&gt;เป็นปัญหา Version Comcash ได้ประสานงานกับทาง Newsoft แก้ไขแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1572331','1572331','1572331','0','0','0','0','2017-02-08 02:44:46');
INSERT INTO `glpi_tickets` VALUES ('67','0','จอ Monitor มีปัญหา FB Grand','2017-01-21 14:44:00','2017-02-08 02:46:41','2017-02-08 02:46:41','2017-02-08 02:46:41','6','6','6','1','จอ Monitor มีปัญหา FB Grand','3','3','3','3','1','0','&lt;p&gt;ดำเนินการเปลี่ยนจอให้ใหม่แล้ว &lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1512161','1512161','1512161','0','0','0','0','2017-02-08 02:46:18');
INSERT INTO `glpi_tickets` VALUES ('68','0','Computer Khun wiroj มีปัญหาเครื่องช้า','2017-01-21 16:46:00','2017-02-08 02:47:49','2017-02-08 02:47:49','2017-02-08 02:47:49','6','6','6','1','Computer Khun wiroj มีปัญหาเครื่องช้า','3','3','3','2','1','0','&lt;p&gt;เปลี่ยนคอมใหม่&lt;/p&gt;
&lt;p&gt;&lt;br /&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1504909','1504909','1504909','0','0','0','0','2017-02-08 02:47:28');
INSERT INTO `glpi_tickets` VALUES ('69','0','ดำเนินการ ติดตั้ง Ram Server SWR,KML 32G','2017-01-21 23:00:00','2017-02-08 02:49:01','2017-02-08 02:49:01','2017-02-08 02:49:01','6','6','6','1','ดำเนินการ ติดตั้ง Ram Server SWR,KML 32G','3','3','3','61','1','0','&lt;p&gt;ดำเนินการ ติดตั้ง Ram Server SWR,KML 32G&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1482541','1482541','1482541','0','0','0','0','2017-02-08 02:48:45');
INSERT INTO `glpi_tickets` VALUES ('70','0','remote Desktop khun Joy site KAMALA','2017-02-08 13:49:00','2017-02-08 13:49:00','2017-02-08 13:49:00','2017-02-08 02:50:02','6','6','6','1','remote Desktop khun Joy site KAMALA','3','3','3','75','1','0','&lt;p&gt;ดำเนินการแก้ไขเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;&lt;br /&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','0','0','1','0','0','0','0','2017-02-08 02:49:46');
INSERT INTO `glpi_tickets` VALUES ('71','0','Setup vpn bangtao k.sunisa,k.วรรณ','2017-01-21 14:49:00','2017-02-08 02:51:31','2017-02-08 02:51:31','2017-02-08 02:51:31','6','6','6','1','Setup vpn bangtao k.sunisa,k.วรรณ','3','3','3','75','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1512151','1512151','1512151','0','0','0','0','2017-02-08 02:51:20');
INSERT INTO `glpi_tickets` VALUES ('72','0','เปลี่ยน UPS ตัวใหม่ ห้องบัญชี','2017-01-21 16:51:00','2017-02-08 02:52:25','2017-02-08 02:52:25','2017-02-08 02:52:25','6','6','6','1','เปลี่ยน UPS ตัวใหม่ ห้องบัญชี','3','3','3','22','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1504885','1504885','1504885','0','0','0','0','2017-02-08 02:52:14');
INSERT INTO `glpi_tickets` VALUES ('73','0','Check DVR 126 WITH KHUN JOM','2017-01-22 14:52:00','2017-02-08 02:53:45','2017-02-08 02:53:45','2017-02-08 02:53:45','6','6','6','1','Check DVR 126 WITH KHUN JOM','3','3','3','47','1','0','&lt;p&gt;Line Cable and Cord have a problem.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1425705','1425705','1425705','0','0','0','0','2017-02-08 02:53:23');
INSERT INTO `glpi_tickets` VALUES ('74','0','Comcash เลือกเมนู lolo แล้วค้าง!','2017-01-23 19:53:00','2017-02-08 02:55:03','2017-02-08 02:55:03','2017-02-08 02:55:03','6','6','6','1','Comcash เลือกเมนู lolo แล้วค้าง!
คุณ Tan','3','3','3','43','1','0','&lt;p&gt;ติดต่อสอบถามไปยัง Newsoft แล้วปัญหาดังกล่าวไม่หน้าจะเกี่ยวกับ Menu&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1321323','1321323','1321323','0','0','0','0','2017-02-08 02:54:34');
INSERT INTO `glpi_tickets` VALUES ('75','0','Package wifi SUNPRIME R7134 หมดอายุ','2017-01-22 20:54:00','2017-02-08 02:56:35','2017-02-08 02:56:35','2017-02-08 02:56:35','6','6','6','1','Package wifi SUNPRIME R7134 หมดอายุ','3','3','3','10','1','0','&lt;p&gt;ดำเนินการแก้ไขแล้วครับ&lt;/p&gt;
&lt;p&gt;ลบและสร้าง Account ให้ใหม่&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1404155','1404155','1404155','0','0','0','0','2017-02-08 02:56:13');
INSERT INTO `glpi_tickets` VALUES ('76','0','Package wifi SUNPRIME R1023 หมดอายุ','2017-01-22 19:56:00','2017-02-08 02:57:39','2017-02-08 02:57:39','2017-02-08 02:57:39','6','6','6','1','Package wifi SUNPRIME R1023 หมดอายุ','3','3','3','10','1','0','&lt;p&gt;ดำเนินการแก้ไขแล้วครับ&lt;/p&gt;
&lt;p&gt;ลบและสร้าง Account ใหม่&lt;/p&gt;
&lt;p&gt;แขกสามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1407699','1407699','1407699','0','0','0','0','2017-02-08 02:57:11');
INSERT INTO `glpi_tickets` VALUES ('77','0','DVR126 ดำเนินการไล่สายกับช่าง MAX SUNWING','2017-01-23 14:57:00','2017-02-08 02:59:15','2017-02-08 02:59:15','2017-02-08 02:59:15','6','6','6','1','DVR126 ดำเนินการไล่สายกับช่าง MAX SUNWING','3','3','3','47','1','0','&lt;p&gt;CH1,2,3 เปลี่ยน DVR ใหม่ใช้งานได้ปกติ&lt;/p&gt;
&lt;p&gt;ส่วน CH4 เดินสายไฟใหม่&lt;/p&gt;
&lt;p&gt;ยังคงเหลือในส่วนของ CH5 บริเวรณสระ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1339335','1339335','1339335','0','0','0','0','2017-02-08 02:58:25');
INSERT INTO `glpi_tickets` VALUES ('78','0','ปัญหา Menu lolo ค้าง Latasca','2017-01-23 19:58:00','2017-02-08 03:00:44','2017-02-08 03:00:44','2017-02-08 03:00:44','6','6','6','1','ดำเนินการบันทึกภาพขณะ User ใช้งาน','3','3','3','43','1','0','&lt;p&gt;ทำการเก็บตัวอย่างมาวิเคราะห์&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1321364','1321364','1321364','0','0','0','0','2017-02-08 03:00:26');
INSERT INTO `glpi_tickets` VALUES ('79','0','Comcash Report PLU Sale มันไม่แสดง Coupon Food memo option  office Bythesea','2017-01-23 20:00:00','2017-02-08 03:03:17','2017-02-08 03:03:17','2017-02-08 03:03:17','6','6','6','1','Comcash Report PLU Sale มันไม่แสดง Coupon Food memo option','3','3','3','43','1','0','&lt;p&gt;สอบถามไปยัง Newsoft แล้วพบว่า&lt;/p&gt;
&lt;p&gt;เป็นปัญหาเรื่อง Version ของ Comcash&lt;/p&gt;
&lt;p&gt;โดยของใหม่จะไม่นำ Memo Option food มา Summary&lt;/p&gt;
&lt;p&gt;เบื้องต้นสามารถใช้ Version เก่าเพื่อเรียก Report ได้&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1321397','1321397','1321397','0','0','0','0','2017-02-08 03:02:01');
INSERT INTO `glpi_tickets` VALUES ('80','0','Printer FBGrand ไม่สามารถใช้งานได้','2017-01-23 19:02:00','2017-02-08 03:04:31','2017-02-08 03:04:31','2017-02-08 03:04:31','6','6','6','1','Printer FBGrand ไม่สามารถใช้งานได้','3','3','3','70','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว สายไฟหลวม&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1324951','1324951','1324951','0','0','0','0','2017-02-08 03:04:09');
INSERT INTO `glpi_tickets` VALUES ('81','0','wifi R7310 PASSWORD WRONG','2017-01-24 19:04:00','2017-02-08 03:06:20','2017-02-08 03:06:20','2017-02-08 03:06:20','6','6','6','1','wifi R7310 PASSWORD WRONG','3','3','3','10','1','0','&lt;p&gt;Create New Password &lt;/p&gt;
&lt;p&gt;Guest available wifi.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1238540','1238540','1238540','0','0','0','0','2017-02-08 03:05:51');
INSERT INTO `glpi_tickets` VALUES ('82','0','Internet Pool by the sea หลุด ไม่สามารถใช้งานได้','2017-01-24 19:05:00','2017-02-08 03:08:18','2017-02-08 03:08:18','2017-02-08 03:08:18','6','6','6','1','ช่างเข้ามาตรวจเช็คwifi และได้ทำการถอดสาย Lan มาเส้นออก','3','3','3','10','1','0','&lt;p&gt;ช่างเข้ามาตรวจเช็คwifi และได้ทำการถอดสาย Lan มาเส้นออก&lt;/p&gt;
&lt;p&gt;ได้ดำเนินการแก้ไขแล้วขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1238598','1238598','1238598','0','0','0','0','2017-02-08 03:07:55');
INSERT INTO `glpi_tickets` VALUES ('83','0','Printer Pool By the sea print เป็น ภาษาต่างดาว','2017-01-24 15:07:00','2017-02-08 03:09:41','2017-02-08 03:09:41','2017-02-08 03:09:41','6','6','6','1','Printer Pool By the sea print เป็น ภาษาต่างดาว','3','3','3','70','1','0','&lt;p&gt;ทาง Newsoft แจ้งว่า ROM PRINTER มีปัญหา&lt;/p&gt;
&lt;p&gt;ต้องส่งไปอัพ ROM&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1252961','1252961','1252961','0','0','0','0','2017-02-08 03:09:02');
INSERT INTO `glpi_tickets` VALUES ('84','0','หน้า Front sunwing ดูกล้อง กระเป๋าแขกหาย','2017-01-24 21:09:00','2017-02-08 03:10:41','2017-02-08 03:10:41','2017-02-08 03:10:41','6','6','6','1','หน้า Front sunwing ดูกล้อง กระเป๋าแขกหาย','3','3','3','45','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้วครับ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1231301','1231301','1231301','0','0','0','0','2017-02-08 03:10:26');
INSERT INTO `glpi_tickets` VALUES ('85','0','คุณนิภาภรแจ้งให้ ปิด บล็อกปลั๊กไฟ','2017-01-24 18:10:00','2017-02-08 03:11:49','2017-02-08 03:11:49','2017-02-08 03:11:49','6','6','6','1','คุณนิภาภรแจ้งให้ ปิด บล็อกปลั๊กไฟ','3','3','3','75','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1242109','1242109','1242109','0','0','0','0','2017-02-08 03:11:36');
INSERT INTO `glpi_tickets` VALUES ('86','0','Front KML FROMAS ค้าง','2017-01-24 19:11:00','2017-02-08 03:13:00','2017-02-08 03:13:00','2017-02-08 03:13:00','6','6','6','1','Front KML FROMAS ค้าง','3','3','3','33','1','0','&lt;p&gt;Restart service&lt;/p&gt;
&lt;p&gt;restart computer&lt;/p&gt;
&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1238520','1238520','1238520','0','0','0','0','2017-02-08 03:12:32');
INSERT INTO `glpi_tickets` VALUES ('87','0','printer ค้าง Front KML','2017-01-24 19:29:00','2017-02-08 03:13:58','2017-02-08 03:13:58','2017-02-08 03:13:58','6','6','6','1','printer ค้าง Front KML','3','3','3','69','1','0','&lt;p&gt;Restart Service ใช้งานได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1237498','1237498','1237498','0','0','0','0','2017-02-08 03:13:33');
INSERT INTO `glpi_tickets` VALUES ('88','0','Check DVR 134 ปัญหากล้องไม่ติด','2017-01-24 17:13:00','2017-02-08 03:15:31','2017-02-08 03:15:31','2017-02-08 03:15:31','6','6','6','1','Check DVR 134 ปัญหากล้องไม่ติด','3','3','3','47','1','0','&lt;p&gt;เช็คเครื่องบันทึกและสาย&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1245751','1245751','1245751','0','0','0','0','2017-02-08 03:15:07');
INSERT INTO `glpi_tickets` VALUES ('89','0','Aof เข้ามาเซ็ต IBSG ','2017-01-25 14:15:00','2017-02-08 03:16:46','2017-02-08 03:16:46','2017-02-08 03:16:46','6','6','6','1','Aof เข้ามาเซ็ต IBSG','3','3','3','64','1','0','&lt;p&gt;ค่าต่างๆยังคงเดิมยกเว้น เซ็ตค่า DHCP NETWORK 1DAY&lt;/p&gt;
&lt;p&gt;และเอาในส่วนของ Restart server 1วันออก&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1170106','1170106','1170106','0','0','0','0','2017-02-08 03:16:13');
INSERT INTO `glpi_tickets` VALUES ('90','0','computer minimarket ใช้ไม่ได้','2017-01-25 14:16:00','2017-02-08 03:17:56','2017-02-08 03:17:56','2017-02-08 03:17:56','6','6','6','1','computer minimarket ใช้ไม่ได้','3','3','3','9','1','0','&lt;p&gt;ช่าง Amati เข้ามาตรวจเช็คสาย wifi ทำสาย LAN MINIMARKET หลุด&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1170116','1170116','1170116','0','0','0','0','2017-02-08 03:17:24');
INSERT INTO `glpi_tickets` VALUES ('91','0','Printer Pool By the sea print เป็น ภาษาต่างดาว','2017-01-25 16:18:00','2017-02-08 03:19:32','2017-02-08 03:19:32','2017-02-08 03:19:32','6','6','6','1','Printer Pool By the sea print เป็น ภาษาต่างดาว','3','3','3','70','1','0','&lt;p&gt;ดำเนินการสลับอุปกรณ์ Spare ไว้ก่อน&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1162892','1162892','1162892','0','0','0','0','2017-02-08 03:18:48');
INSERT INTO `glpi_tickets` VALUES ('92','0','khun DAM Mail ไม่เข้า','2017-01-25 17:21:00','2017-02-08 03:22:33','2017-02-08 03:22:33','2017-02-08 03:22:33','6','6','6','1','khun DAM Mail ไม่เข้า','3','3','3','78','1','0','&lt;p&gt;mail server full&lt;/p&gt;
&lt;p&gt;clear old mail already.&lt;/p&gt;
&lt;p&gt;user available.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1159293','1159293','1159293','0','0','0','0','2017-02-08 03:21:45');
INSERT INTO `glpi_tickets` VALUES ('93','0','Printer Front ไม่สามารถใช้งานได้ Sunprime','2017-01-25 20:21:00','2017-02-08 03:23:53','2017-02-08 03:23:53','2017-02-08 03:23:53','6','6','6','1','Printer Front ไม่สามารถใช้งานได้ Sunprime','3','3','3','69','1','0','&lt;p&gt;Restart เครื่องใหม่ใช้งานได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','1148573','1148573','1148573','0','0','0','0','2017-02-08 03:23:40');
INSERT INTO `glpi_tickets` VALUES ('94','0','Printer Khun baby paper JAM','2017-01-27 14:23:00','2017-02-08 03:24:56','2017-02-08 03:24:56','2017-02-08 03:24:56','6','6','6','1','Printer Khun baby paper JAM','3','3','3','71','1','0','&lt;p&gt;Clear paper Jam&lt;/p&gt;
&lt;p&gt;User Available.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','997316','997316','997316','0','0','0','0','2017-02-08 03:24:27');
INSERT INTO `glpi_tickets` VALUES ('95','0','Test Wifi 5Login Sunwing','2017-01-27 16:24:00','2017-02-08 03:26:08','2017-02-08 03:26:08','2017-02-08 03:26:08','6','6','6','1','Test Wifi 5Login Sunwing
Tell Khun Aoi Set 5login 1Password','3','3','3','10','1','0','&lt;p&gt;Test Wifi 5Login Sunwing&lt;br /&gt;Tell Khun Aoi Set 5 login 1 Password&lt;/p&gt;
&lt;p&gt;Now available.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','990128','990128','990128','0','0','0','0','2017-02-08 03:25:44');
INSERT INTO `glpi_tickets` VALUES ('96','0','SETUP AIS FIBER','2017-01-27 15:25:00','2017-02-08 03:28:16','2017-02-08 03:28:16','2017-02-08 03:28:16','6','6','6','1','SETUP AIS FIBER','3','3','3','19','1','0','&lt;p&gt;engineer come to setup fiber.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','993796','993796','993796','0','0','0','0','2017-02-08 03:27:17');
INSERT INTO `glpi_tickets` VALUES ('97','0','Excel เปิดไม่ได้','2017-01-28 14:27:00','2017-02-08 03:29:48','2017-02-08 03:29:48','2017-02-08 03:29:48','6','6','6','1','Excel เปิดไม่ได้ คุณวิลาสินี','3','3','3','27','1','0','&lt;p&gt;ลบ Excel version เก่าออก&lt;/p&gt;
&lt;p&gt;และดำเนินการตั้ง Defalt App window10 เป็น excel&lt;/p&gt;
&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','910968','910968','910968','0','0','0','0','2017-02-08 03:29:03');
INSERT INTO `glpi_tickets` VALUES ('98','0','Wifi ห้องกระจกใช้งานไม่ได้','2017-01-28 14:29:00','2017-02-08 03:30:50','2017-02-08 03:30:50','2017-02-08 03:30:50','6','6','6','1','Wifi ห้องกระจกใช้งานไม่ได้','3','3','3','10','1','0','&lt;p&gt;ช่างตรวจเช็คสาย ทำสาย wifi หลุด&lt;/p&gt;
&lt;p&gt;ดำเนินการแก้ไขแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','910910','910910','910910','0','0','0','0','2017-02-08 03:30:29');
INSERT INTO `glpi_tickets` VALUES ('99','0','R3303 SUNPRIME COUPON EXPIRE','2017-01-28 15:30:00','2017-02-08 03:33:23','2017-02-08 03:33:23','2017-02-08 03:33:23','6','6','6','1','R3303 SUNPRIME COUPON EXPIRE','3','3','3','10','1','0','&lt;p&gt;CREATE NEW ACCOUNT&lt;/p&gt;
&lt;p&gt;AUTHEN HAVE SOME PROBLEM CAN\'T Sync Data.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','907403','907403','907403','0','0','0','0','2017-02-08 03:31:27');
INSERT INTO `glpi_tickets` VALUES ('100','0','เปิด PDF File ไม่ได้','2017-01-28 15:31:00','2017-02-08 03:35:42','2017-02-08 03:35:42','2017-02-08 03:35:42','6','6','6','1','เปิด PDF File ไม่ได้','3','3','3','78','1','0','&lt;p&gt;mail ที่ส่งมาไม่ใช่ File PDF ต้องให้ Guest ส่งไฟล์ใหม่อีกครั้ง&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','907482','907482','907482','0','0','0','0','2017-02-08 03:34:46');
INSERT INTO `glpi_tickets` VALUES ('101','0','ย้ายเมล SPAM GMAIL KHUN DAM','2017-01-28 11:55:00','2017-02-08 03:57:18','2017-02-08 03:57:18','2017-02-08 03:57:18','6','6','6','1','ย้ายเมล SPAM GMAIL KHUN DAM','3','3','3','78','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','921738','921738','921738','0','0','0','0','2017-02-08 03:57:06');
INSERT INTO `glpi_tickets` VALUES ('102','0','HR @payroll ไม่แสดง วันที่8','2017-01-28 13:57:00','2017-02-08 03:58:54','2017-02-08 03:58:54','2017-02-08 03:58:54','6','6','6','1','HR @payroll ไม่แสดง วันที่8','3','3','3','29','1','0','&lt;p&gt;ดึงฐานข้อมูลที่ได้ BACKUP ไว้มาใช้แทน&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','914514','914514','914514','0','0','0','0','2017-02-08 03:58:19');
INSERT INTO `glpi_tickets` VALUES ('103','0','R4201 Wifi ไม่สามารถใช้งานได้ SUNPRIME','2017-01-28 14:58:00','2017-02-08 04:00:14','2017-02-08 04:00:14','2017-02-08 04:00:14','6','6','6','1','R4201 Wifi ไม่สามารถใช้งานได้ SUNPRIME','3','3','3','10','1','0','&lt;p&gt;ช่าง AMATI ถอดสาย LAN ทิ้งไว้&lt;/p&gt;
&lt;p&gt;ขณะนี้ แขกสามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','910934','910934','910934','0','0','0','0','2017-02-08 03:59:35');
INSERT INTO `glpi_tickets` VALUES ('104','0','R1307 GUEST ไม่สามารถใช้ wifi ได้','2017-01-28 15:59:00','2017-02-08 04:01:19','2017-02-08 04:01:19','2017-02-08 04:01:19','6','6','6','1','R1307 GUEST ไม่สามารถใช้ wifi ได้','3','3','3','10','1','0','&lt;p&gt;Reboot AP &lt;/p&gt;
&lt;p&gt;Guest สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','907339','907339','907339','0','0','0','0','2017-02-08 04:00:52');
INSERT INTO `glpi_tickets` VALUES ('105','0','ติดตั้งโปรแกรม Newsoft fino ชั้น2','2017-01-28 19:00:00','2017-02-08 04:02:12','2017-02-08 04:02:12','2017-02-08 04:02:12','6','6','6','1','ติดตั้งโปรแกรม Newsoft fino ชั้น2','3','3','3','25','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','896532','896532','896532','0','0','0','0','2017-02-08 04:02:01');
INSERT INTO `glpi_tickets` VALUES ('106','0','R3104 SUNPRIME Coupon Expire Guest Hamil','2017-01-28 20:02:00','2017-02-08 04:04:02','2017-02-08 04:04:02','2017-02-08 04:04:02','6','6','6','1','R3104 SUNPRIME Coupon Expire Guest Hamil','3','3','3','10','1','0','&lt;p&gt;Fix Already.&lt;/p&gt;
&lt;p&gt;Guest available.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','892922','892922','892922','0','0','0','0','2017-02-08 04:03:22');
INSERT INTO `glpi_tickets` VALUES ('107','0','HR @payroll ไม่แสดง วันที่8','2017-01-29 15:04:00','2017-02-08 04:05:22','2017-02-08 04:05:22','2017-02-08 04:05:22','6','6','6','1','HR @payroll ไม่แสดง วันที่8
ย้ายฐานข้อมูลกลับปัจจุบัน','3','3','3','29','1','0','&lt;p&gt;HR @payroll ไม่แสดง วันที่8&lt;br /&gt;ย้ายฐานข้อมูลกลับปัจจุบัน&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','824482','824482','824482','0','0','0','0','2017-02-08 04:05:14');
INSERT INTO `glpi_tickets` VALUES ('108','0','Khun Eif Upload File Video Google Drive','2017-01-29 15:05:00','2017-02-08 04:06:15','2017-02-08 04:06:15','2017-02-08 04:06:15','6','6','6','1','Khun Eif Upload File Video Google Drive','3','3','3','75','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','824475','824475','824475','0','0','0','0','2017-02-08 04:06:02');
INSERT INTO `glpi_tickets` VALUES ('109','0','เปลี่ยน Switch latasca ใหม่แก้ปัญหา Network','2017-01-30 14:06:00','2017-02-08 04:07:15','2017-02-08 04:07:15','2017-02-08 04:07:15','6','6','6','1','เปลี่ยน Switch latasca ใหม่แก้ปัญหา Network','3','3','3','13','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว แต่ยังคงพบปัญหา Comcash ค้าง&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','741675','741675','741675','0','0','0','0','2017-02-08 04:06:53');
INSERT INTO `glpi_tickets` VALUES ('110','0','Check Program fino','2017-01-30 19:06:00','2017-02-08 04:08:12','2017-02-08 04:08:12','2017-02-08 04:08:12','6','6','6','1','Check Program fino','3','3','3','27','1','0','&lt;p&gt;แก้ปัญหา ภาษาต่างดาว &lt;/p&gt;
&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','723732','723732','723732','0','0','0','0','2017-02-08 04:07:51');
INSERT INTO `glpi_tickets` VALUES ('111','0','AIS FIBER ช่างเข้าดำเนินการติดตั้ง Router','2017-01-30 15:07:00','2017-02-08 04:08:53','2017-02-08 04:08:53','2017-02-08 04:08:53','6','6','6','1','AIS FIBER ช่างเข้าดำเนินการติดตั้ง Router','3','3','3','21','1','0','&lt;p&gt;AIS FIBER ช่างเข้าดำเนินการติดตั้ง Router&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','738113','738113','738113','0','0','0','0','2017-02-08 04:08:44');
INSERT INTO `glpi_tickets` VALUES ('112','0','ตึก2 sunwing WIFI ใช้งานไม่ได้','2017-01-30 16:08:00','2017-02-08 04:09:50','2017-02-08 04:09:50','2017-02-08 04:09:50','6','6','6','1','ตึก2 sunwing WIFI ใช้งานไม่ได้
UPS เสีย','3','3','3','10','1','0','&lt;p&gt;ตึก2 sunwing WIFI ใช้งานไม่ได้&lt;br /&gt;UPS เสีย&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','734510','734510','734510','0','0','0','0','2017-02-08 04:09:42');
INSERT INTO `glpi_tickets` VALUES ('113','0','Printer HR เสีย ไฟไม่เข้า ได้ลองสลัยสาย AC และปลั๊กเสียบแล้ว','2017-01-30 16:09:00','2017-02-08 04:13:43','2017-02-08 04:13:43','2017-02-08 04:13:43','6','6','6','1','Printer HR เสีย ไฟไม่เข้า ได้ลองสลัยสาย AC และปลั๊กเสียบแล้ว
ยังคงไม่สามารถใช้งานได้','3','3','3','69','1','0','&lt;p&gt;ได้ดำเนินการติดตั้งกลับจุดเดิมแล้วสามารถใช้งานได้ตามปกติ&lt;/p&gt;
&lt;p&gt;ในส่วนของการทดสอบก่อนการส่งซ่อมนั้น ได้ร่วมมือกับคุณโจมทดสอบแล้วพบไฟไม่เข้า&lt;/p&gt;
&lt;p&gt;โดยมีพยานบุคคลพี่ชะ โส และกิ่งอยู่ในเหตุการณ์&lt;/p&gt;
&lt;p&gt;อาการลักษณะนี้คล้ายกับตะกั่วที่บัคกรีอยู่บนบอร์ดเสื่อมสภาพ ทำให้ขณะ ขนย้ายเกิดการกระทบจนสามารถใช้งานได้&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt; &lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','734683','734683','734520','0','0','0','0','2017-02-08 04:10:40');
INSERT INTO `glpi_tickets` VALUES ('114','0','Ubuntu Crenic แก้ไข Icon Desktop','2017-01-31 14:10:00','2017-02-08 04:15:49','2017-02-08 04:15:49','2017-02-08 04:15:49','6','6','6','1','Ubuntu Crenic แก้ไข Icon Desktop','3','3','3','75','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','655549','655549','655549','0','0','0','0','2017-02-08 04:15:38');
INSERT INTO `glpi_tickets` VALUES ('115','0','คุณวิลาสินี เปิด Sale Force ไม่ได้','2017-01-31 17:16:00','2017-02-08 04:18:00','2017-02-08 04:18:00','2017-02-08 04:18:00','6','6','6','1','คุณวิลาสินี เปิด Sale Force ไม่ได้','3','3','3','27','1','0','&lt;p&gt;ดำเนินการตั้ง Defalt App window10 เป็น excel&lt;/p&gt;
&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','644520','644520','644520','0','0','0','0','2017-02-08 04:17:46');
INSERT INTO `glpi_tickets` VALUES ('116','0','ปรับมุมกล้อง DVR 136 ประตูทางออก','2017-01-31 16:17:00','2017-02-08 04:18:39','2017-02-08 04:18:39','2017-02-08 04:18:39','6','6','6','1','ปรับมุมกล้อง DVR 136 ประตูทางออก','3','3','3','46','1','0','&lt;p&gt;ปรับมุมกล้อง DVR 136 ประตูทางออก&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','648099','648099','648099','0','0','0','0','2017-02-08 04:18:32');
INSERT INTO `glpi_tickets` VALUES ('117','0','Comcash latasca ค้าง','2017-01-31 19:18:00','2017-02-08 04:20:13','2017-02-08 04:20:13','2017-02-08 04:20:13','6','6','6','1','Comcash latasca ค้าง','3','3','3','43','1','0','&lt;p&gt;Comcash latasca ค้าง&lt;/p&gt;
&lt;p&gt;Ping ไม่หลุด&lt;/p&gt;
&lt;p&gt;VNC REMOTE ไม่หลุด&lt;/p&gt;
&lt;p&gt;เวลาค้างจะเป็นแค่ Outlet latasca &lt;/p&gt;
&lt;p&gt;server ไม่ค้าง&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','637333','637333','637333','0','0','0','0','2017-02-08 04:19:21');
INSERT INTO `glpi_tickets` VALUES ('118','0','R2140 COUPON EXPIRE','2017-02-01 09:19:00','2017-02-08 04:21:54','2017-02-08 04:21:54','2017-02-08 04:21:54','6','6','6','1','R2140 COUPON EXPIRE','3','3','3','10','1','0','&lt;p&gt;SYNC DATA Fromas แล้วยังไม่ได้&lt;/p&gt;
&lt;p&gt;ต้องลบ Account และสร้างใหม่&lt;/p&gt;
&lt;p&gt;ขณะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','586974','586974','586974','0','0','0','0','2017-02-08 04:21:04');
INSERT INTO `glpi_tickets` VALUES ('119','0','ติดตั้งโปรแกรมแช่แข็ง HDD Shadow.Defender COM GUEST','2017-02-02 10:21:00','2017-02-08 04:23:23','2017-02-08 04:23:23','2017-02-08 04:23:23','6','6','6','1','ติดตั้งโปรแกรมแช่แข็ง HDD Shadow.Defender COM GUEST','3','3','3','2','1','0','&lt;p&gt;ติดตั้งโปรแกรมแช่แข็ง HDD Shadow.Defender COM GUEST ทั้งสองฝั่ง&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','496943','496943','496943','0','0','0','0','2017-02-08 04:23:09');
INSERT INTO `glpi_tickets` VALUES ('120','0','ปรับฐานข้อมูลภาษีใหม่ Utech','2017-01-03 10:00:00','2017-02-08 04:24:50','2017-02-08 04:24:50','2017-02-08 04:24:50','6','6','6','1','ปรับฐานข้อมูลภาษีใหม่ Utech','3','3','3','29','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','3090290','3090290','3090290','0','0','0','0','2017-02-08 04:24:36');
INSERT INTO `glpi_tickets` VALUES ('121','0','printer store SUKA ไม่สามารถใช้งานได้','2017-02-03 11:24:00','2017-02-08 04:26:06','2017-02-08 04:26:06','2017-02-08 04:26:06','6','6','6','1','printer store SUKA ไม่สามารถใช้งานได้','3','3','3','69','1','0','&lt;p&gt;RESTART SERVICE&lt;/p&gt;
&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','406926','406926','406926','0','0','0','0','2017-02-08 04:25:39');
INSERT INTO `glpi_tickets` VALUES ('122','0','Khun anusorn ดู Full Screen กล้องไม่ได้','2017-02-03 09:25:00','2017-02-08 04:27:25','2017-02-08 04:27:25','2017-02-08 04:27:25','6','6','6','1','Khun anusorn ดู Full Screen กล้องไม่ได้','3','3','3','45','1','0','&lt;p&gt;ดำเนินการ Add กล้องใหม่&lt;/p&gt;
&lt;p&gt;สามารถดูได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','414145','414145','414145','0','0','0','0','2017-02-08 04:27:06');
INSERT INTO `glpi_tickets` VALUES ('123','0','เปลี่ยน Swtich Hub Latasca ทั้งหมด','2017-02-03 13:27:00','2017-02-08 04:28:17','2017-02-08 04:28:17','2017-02-08 04:28:17','6','6','6','1','เปลี่ยน Swtich Hub Latasca ทั้งหมด
แก้ปัญหา Comcash','3','3','3','13','1','0','&lt;p&gt;เปลี่ยน Swtich Hub Latasca ทั้งหมด&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','399677','399677','399677','0','0','0','0','2017-02-08 04:28:08');
INSERT INTO `glpi_tickets` VALUES ('124','0','แจ้ง KHUN KIM DATA EXPRESS เปลี่ยน Channel เป็น 1,6,11','2017-02-03 11:28:00','2017-02-08 04:29:24','2017-02-08 04:29:24','2017-02-08 04:29:24','6','6','6','1','แจ้ง KHUN KIM DATA EXPRESS เปลี่ยน Channel เป็น 1,6,11','3','3','3','11','1','0','&lt;p&gt;แจ้ง KHUN KIM DATA EXPRESS เปลี่ยน Channel เป็น 1,6,11&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','406884','406884','406884','0','0','0','0','2017-02-08 04:29:17');
INSERT INTO `glpi_tickets` VALUES ('125','0','IBSG ค้าง R 1216 แจ้งไม่สามารถใช้งาน wifi ได้','2017-02-03 07:29:00','2017-02-08 04:30:52','2017-02-08 04:30:52','2017-02-08 04:30:52','6','6','6','1','IBSG ค้าง R 1216 แจ้งไม่สามารถใช้งาน wifi ได้','3','3','3','64','1','0','&lt;p&gt;ทำการปิดเครื่องและเปิดใหม่&lt;/p&gt;
&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;
&lt;p&gt;ใช้งานได้7วันหลังจาก AOF เข้ามาเซ็ตค่า Config โดยไม่ต้อง Restart Server!&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','421312','421312','421312','0','0','0','0','2017-02-08 04:30:09');
INSERT INTO `glpi_tickets` VALUES ('126','0','Com minimart เสีย','2017-02-03 10:30:00','2017-02-08 04:31:47','2017-02-08 04:31:47','2017-02-08 04:31:47','6','6','6','1','Com minimart เสีย','3','3','3','51','1','0','&lt;p&gt;เปลี่ยน RAM สามารถใช้งานได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','410507','410507','410507','0','0','0','0','2017-02-08 04:31:25');
INSERT INTO `glpi_tickets` VALUES ('127','0','Setup Antivirus kaspersky controller','2017-02-03 13:31:00','2017-02-08 04:32:57','2017-02-08 04:32:57','2017-02-08 04:32:57','6','6','6','1','Setup Antivirus kaspersky controller','3','3','3','26','1','0','&lt;p&gt;Setup Antivirus kaspersky controller&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','399717','399717','399717','0','0','0','0','2017-02-08 04:32:46');
INSERT INTO `glpi_tickets` VALUES ('128','0','Check Dvr128,Dvr129','2017-02-03 14:32:00','2017-02-08 04:33:41','2017-02-08 04:33:41','2017-02-08 04:33:41','6','6','6','1','Check Dvr128,Dvr129','3','3','3','47','1','0','&lt;p&gt;สายสัญญาณเสีย&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','396101','396101','396101','0','0','0','0','2017-02-08 04:33:25');
INSERT INTO `glpi_tickets` VALUES ('129','0','นํ้าหยดลงcomputer latasca','2017-02-03 11:33:00','2017-02-08 04:34:35','2017-02-08 04:34:35','2017-02-08 04:34:35','6','6','6','1','นํ้าหยดลงcomputer latasca','3','3','3','2','1','0','&lt;p&gt;แก้ไขเรียบร้อยแล้ว&lt;/p&gt;
&lt;p&gt;สามารถใช้งานได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','406895','406895','406895','0','0','0','0','2017-02-08 04:34:16');
INSERT INTO `glpi_tickets` VALUES ('130','0','WIFI R3140 มีปัญหา Login ไม่ได้','2017-02-03 16:34:00','2017-02-08 04:35:35','2017-02-08 04:35:35','2017-02-08 04:35:35','6','6','6','1','WIFI R3140 มีปัญหา Login ไม่ได้','3','3','3','10','1','0','&lt;p&gt;ลบและสร้าง Account ใหม่&lt;/p&gt;
&lt;p&gt;Guest สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','388895','388895','388895','0','0','0','0','2017-02-08 04:35:12');
INSERT INTO `glpi_tickets` VALUES ('131','0','Computer mini market ใช้งาน Internet ไม่ได้','2017-02-04 09:35:00','2017-02-08 04:36:25','2017-02-08 04:36:25','2017-02-08 04:36:25','6','6','6','1','Computer mini market ใช้งาน Internet ไม่ได้','3','3','3','9','1','0','&lt;p&gt;สาย LAN หลวม&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','327685','327685','327685','0','0','0','0','2017-02-08 04:36:08');
INSERT INTO `glpi_tickets` VALUES ('132','0','Notebook Khun Dam เปิดไม่ติด','2017-02-04 10:36:00','2017-02-08 04:37:27','2017-02-08 04:37:27','2017-02-08 04:37:27','6','6','6','1','Notebook Khun Dam เปิดไม่ติด','3','3','3','52','1','0','&lt;p&gt;สาย Adapter เสีย&lt;/p&gt;
&lt;p&gt;ได้ไป BIGC ซื้อมาให้คุณดำแล้ว&lt;/p&gt;
&lt;p&gt;สามารถใช้งานได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','324087','324087','324087','0','0','0','0','2017-02-08 04:36:58');
INSERT INTO `glpi_tickets` VALUES ('133','0','CHECK DVR 134 กล้องไม่ติด','2017-02-04 14:36:00','2017-02-08 04:38:49','2017-02-08 04:38:49','2017-02-08 04:38:49','6','6','6','1','CHECK DVR 134 กล้องไม่ติด','3','3','3','47','1','0','&lt;p&gt;หนูกัดสาย Adapter ห้องเก็บของแก้ไขแล้ว&lt;/p&gt;
&lt;p&gt;ส่วนที่เหลือเป็นปัญหาสายสัยญาณ ส่งเรื่องให้ทางช่างดำเนินการแล้ว&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','309769','309769','309769','0','0','0','0','2017-02-08 04:37:57');
INSERT INTO `glpi_tickets` VALUES ('134','0','Printer KC BY THE SEA ปริ้นไม่ได้','2017-02-04 15:37:00','2017-02-08 04:40:20','2017-02-08 04:40:20','2017-02-08 04:40:20','6','6','6','1','Printer KC BY THE SEA ปริ้นไม่ได้','3','3','3','70','1','0','&lt;p&gt;ทำการ Reboot print Server &lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','306200','306200','306200','0','0','0','0','2017-02-08 04:39:59');
INSERT INTO `glpi_tickets` VALUES ('135','0','ดูกล้อง DVR132 จดหมายหาย Bell sunprime','2017-02-04 22:00:00','2017-02-08 04:41:37','2017-02-08 04:41:37','2017-02-08 04:41:37','6','6','6','1','ดูกล้อง DVR132 จดหมายหาย Bell sunprime','3','3','3','45','1','0','&lt;p&gt;ดำเนินการเปิดกล้องให้แล้วครับ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','283297','283297','283297','0','0','0','0','2017-02-08 04:41:18');
INSERT INTO `glpi_tickets` VALUES ('136','0','R2204 COUPON EXPIRE','2017-02-05 09:41:00','2017-02-08 04:42:31','2017-02-08 04:42:31','2017-02-08 04:42:31','6','6','6','1','R2204 COUPON EXPIRE','3','3','3','10','1','0','&lt;p&gt;ดำเนินการแก้ไขแล้วครับ&lt;/p&gt;
&lt;p&gt;ลบและสร้าง Account ใหม่&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','241291','241291','241291','0','0','0','0','2017-02-08 04:42:08');
INSERT INTO `glpi_tickets` VALUES ('137','0','R2109 COUPON EXPIRE','2017-02-05 15:42:00','2017-02-08 04:43:25','2017-02-08 04:43:25','2017-02-08 04:43:25','6','6','6','1','R2109 COUPON EXPIRE','3','3','3','10','1','0','&lt;p&gt;ลบและสร้าง Account ใหม่&lt;/p&gt;
&lt;p&gt;Guest สามารถใช้งานได้ปกติครับ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','219685','219685','219685','0','0','0','0','2017-02-08 04:43:02');
INSERT INTO `glpi_tickets` VALUES ('138','0','Printer Pool By the sea print เป็น ภาษาต่างดาว','2017-02-05 15:43:00','2017-02-08 04:44:46','2017-02-08 04:44:46','2017-02-08 04:44:46','6','6','6','1','Printer Pool By the sea print เป็น ภาษาต่างดาว','3','3','3','70','1','0','&lt;p&gt;เปลี่ยน Computer เครื่องใหม่ ไม่พบอาการผิดปกติแล้วครับ&lt;/p&gt;
&lt;p&gt;สาเหตุมาจาก Port Serial เสีย&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','219706','219706','219706','0','0','0','0','2017-02-08 04:44:10');
INSERT INTO `glpi_tickets` VALUES ('139','0','wifi R6105 coupon expire','2017-02-05 16:44:00','2017-02-08 04:45:56','2017-02-08 04:45:56','2017-02-08 04:45:56','6','6','6','1','wifi R6105 coupon expire','3','3','3','10','1','0','&lt;p&gt;ทำการสร้าง Account ให้ใหม่ครับ&lt;/p&gt;
&lt;p&gt;สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','216116','216116','216116','0','0','0','0','2017-02-08 04:45:33');
INSERT INTO `glpi_tickets` VALUES ('140','0','Check DVR135,136','2017-02-05 14:45:00','2017-02-08 04:47:51','2017-02-08 04:47:51','2017-02-08 04:47:51','6','6','6','1','Check DVR135,136 with Khun Jom','3','3','3','47','1','0','&lt;p&gt;136 ไฟ220 V สายขาด อันตรายไฟรั่วใต้ซิงค์นํ้า Pool Bar by the pool ปาล์มเล้าท์&lt;/p&gt;
&lt;p&gt;135 Fino Adapter เสีย&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','223371','223371','223371','0','0','0','0','2017-02-08 04:46:27');
INSERT INTO `glpi_tickets` VALUES ('141','0','Notebook Khun Dam เปิดไม่ติด','2017-02-06 10:46:00','2017-02-08 04:49:55','2017-02-08 04:49:55','2017-02-08 04:49:55','6','6','6','1','ซื้อสาย Adapter ไปเปลี่ยนให้แล้วครับ','3','3','3','52','1','0','&lt;p&gt;ซื้อสาย Adapter ไปเปลี่ยนให้แล้วครับ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','151435','151435','151435','0','0','0','0','2017-02-08 04:49:48');
INSERT INTO `glpi_tickets` VALUES ('142','0','Check DVR 122,131','2017-02-06 14:49:00','2017-02-08 04:51:13','2017-02-08 04:51:13','2017-02-08 04:51:13','6','6','6','1','Check DVR 122,131','3','3','3','47','1','0','&lt;p&gt;DVR122 ไฟ11 V สายสัญญาณLose กล้องไม่ทำงาน&lt;/p&gt;
&lt;p&gt;DVR131 Adapter หลวม&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','136933','136933','136933','0','0','0','0','2017-02-08 04:50:26');
INSERT INTO `glpi_tickets` VALUES ('143','0','Check DVR 126 WITH KHUN JOM','2017-02-07 14:50:00','2017-02-08 04:52:42','2017-02-08 04:52:42','2017-02-08 04:52:42','6','6','6','1','Check DVR 122,131','3','3','3','47','1','0','&lt;p&gt;CH 4 ต้นไม้บัง ให้คนสวนไปดำเนินการแล้ว&lt;/p&gt;
&lt;p&gt;CH 5 ไม่มีไฟเลี้ยงกล้องสายขาดใน&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','50562','50562','50562','0','0','0','0','2017-02-08 04:51:53');
INSERT INTO `glpi_tickets` VALUES ('144','0','Setup kaspersky for window server 2012 R2','2017-02-07 10:51:00','2017-02-08 04:54:12','2017-02-08 04:54:12','2017-02-08 04:54:12','6','6','6','1','Setup kaspersky for window server 2012 R2','3','3','3','26','1','0','&lt;p&gt;แจ้งทางคุณเพลง SUPPORT KASPERSKY THAILAND&lt;/p&gt;
&lt;p&gt;Remote ติดตั้ง Antivirus ใน Server Domain เรียบร้อยแล้วครับ&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt; &lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','64992','64992','64992','0','0','0','0','2017-02-08 04:53:25');
INSERT INTO `glpi_tickets` VALUES ('145','0','ลงไดร์เวอร์ Printer wilasine','2017-02-07 11:53:00','2017-02-08 04:55:40','2017-02-08 04:55:40','2017-02-08 04:55:40','6','6','6','1','ลงไดร์เวอร์ Printer wilasine','3','3','3','71','1','0','&lt;p&gt;ติดตั้งไดร์เวอร์เรียบร้อยแล้วครับ&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','61360','61360','61360','0','0','0','0','2017-02-08 04:54:53');
INSERT INTO `glpi_tickets` VALUES ('146','0','เปลี่ยน Printer Fornt Sunwing ใหม่','2017-02-07 16:54:00','2017-02-08 04:57:01','2017-02-08 04:57:01','2017-02-08 04:57:01','6','6','6','1','เปลี่ยน Printer Fornt Sunwing ใหม่

ตัวเก่า ปริ้นได้1ครั้ง ขึ้น Error กระดาษ','3','3','3','69','1','0','&lt;p&gt;ดำเนินการเปลี่ยนเรียบร้อยแล้วครับ&lt;/p&gt;
&lt;p&gt;User สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','43381','43381','43381','0','0','0','0','2017-02-08 04:56:44');
INSERT INTO `glpi_tickets` VALUES ('147','0','Khun Anusorn กู้ไฟล์ Excel','2017-02-08 07:56:00','2017-02-08 07:56:00','2017-02-08 07:56:00','2017-02-08 04:58:25','6','6','6','1','Khun Anusorn กู้ไฟล์ Excel','3','3','3','27','1','0','&lt;p&gt;ดำเนินการกู้ไฟล์เรียบร้อยแล้วครับ&lt;/p&gt;
&lt;p&gt;โดยดึงจาก App datalocal History&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','0','0','1','0','0','0','0','2017-02-08 04:57:40');
INSERT INTO `glpi_tickets` VALUES ('148','0','ได้รับแจ้งจากคุณ Eban ว่า ไม่สามารถใช้งานFromad ได้','2017-02-08 02:57:00','2017-02-08 04:59:41','2017-02-08 04:59:41','2017-02-08 04:59:41','6','6','6','1','ได้รับแจ้งจากคุณ Eban ว่า ไม่สามารถใช้งานFromad ได้','3','3','3','63','1','0','&lt;p&gt;Server ShutDown ได้ให้คุณ Eban ช่วยดำเนินการเปิดเครื่องใหม่&lt;/p&gt;
&lt;p&gt;ขณะนี้สามารถใช้งานได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','7361','7361','7361','0','0','0','0','2017-02-08 04:59:11');
INSERT INTO `glpi_tickets` VALUES ('149','0','Computer Pool By The Pool เปิดไม่ติด','2017-02-08 10:59:00','2017-02-08 10:59:00','2017-02-08 10:59:00','2017-02-08 05:00:56','6','6','6','1','ได้รับแจ้งจาก AOM ว่า
Computer Pool By The Pool เปิดไม่ติด','3','3','3','2','1','0','&lt;p&gt;UPS ดับอยุ่&lt;/p&gt;
&lt;p&gt;ดำเนินการเปิดขึ้นมาใหม่&lt;/p&gt;
&lt;p&gt;สามารถใช้งานได้ปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','0','0','1','0','0','0','0','2017-02-08 05:00:29');
INSERT INTO `glpi_tickets` VALUES ('150','0','Printer Epson Kc Latasca หมึกหมด','2017-02-08 12:38:00','2017-02-10 09:08:43','2017-02-10 09:08:43','2017-02-10 09:08:43','6','6','2','1','Printer Epson Kc Latasca หมึกหมด','3','3','3','71','1','0','&lt;p&gt;ดำเนินการเปลี่ยนเรียบร้อยแล้วครับ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','160243','160243','1','0','0','0','0','2017-02-08 05:39:26');
INSERT INTO `glpi_tickets` VALUES ('151','0','ติดตั้งเครื่องปริ้น KC BY THE SEA','2017-02-08 12:48:00',NULL,NULL,'2017-02-08 05:42:01','2','2','2','1','ติดตั้งเครื่องปริ้น KC BY THE SEA
พี่หญิงขอตัวใหม่ติดตั้ง','3','3','3','71','1','0',NULL,'1','0','0','0',NULL,NULL,NULL,'0','0','0','0','1','0','0','0','0','2017-02-08 05:40:10');
INSERT INTO `glpi_tickets` VALUES ('152','0','ติดตั้ง Note Book และ Projector ห้องประชุมเล็ก วันที่ 13-2-60  ก่อน10โมง','2017-02-08 05:40:22',NULL,NULL,'2017-02-08 05:41:46','2','2','2','1','ติดตั้ง Note Book และ Projector ห้องประชุมเล็ก วันที่ 13-2-60 ก่อน10โมง
ส่งเมลแจ้งกลับด้วย','3','3','3','75','1','0',NULL,'1','0','0','0',NULL,NULL,NULL,'0','0','0','0','46','0','0','0','0','2017-02-08 05:41:08');
INSERT INTO `glpi_tickets` VALUES ('153','0','Print ภาพ คุณ Montre  Guest Relation','2017-02-10 09:08:54','2017-02-10 09:11:29','2017-02-10 09:11:29','2017-02-10 09:11:29','6','6','6','1','Print ภาพ คุณ Montre Guest Relation','3','3','3','75','1','0','&lt;p&gt;ดำเนินการเรียบร้อยแล้วครับ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','155','155','155','0','0','0','0','2017-02-10 09:10:09');
INSERT INTO `glpi_tickets` VALUES ('154','0','สาย LAN มีปัญหา Pool By the sea','2017-02-10 14:10:00','2017-02-10 14:10:00','2017-02-10 14:10:00','2017-02-10 09:11:40','6','6','6','1','สาย LAN มีปัญหา Pool By the sea','3','3','3','9','1','0','&lt;p&gt;หนูกัดสาย Lan&lt;/p&gt;
&lt;p&gt;ดำเนินการเรียบร้อยแล้วครับ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','0','0','1','0','0','0','0','2017-02-10 09:11:06');
INSERT INTO `glpi_tickets` VALUES ('155','0','เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้','2017-02-08 16:12:00','2017-02-10 09:14:45','2017-02-10 09:14:45','2017-02-10 09:14:45','6','6','6','1','เครื่องคุณอีฟ ไม่สามารถใช้งาน @Pay roll ได้
TR ไม่สามารถใช้งานได้','3','3','3','29','1','0','&lt;p&gt;ย้ายฐานข้อมูลภาษีจาก59ไป60&lt;/p&gt;
&lt;p&gt;Run administrator Program&lt;/p&gt;
&lt;p&gt;ข๊ะนี้สามารถใช้งานได้ตามปกติ&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','147765','147765','147765','0','0','0','0','2017-02-10 09:14:16');

### Dump table glpi_tickets_tickets

DROP TABLE IF EXISTS `glpi_tickets_tickets`;
CREATE TABLE `glpi_tickets_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id_1` int(11) NOT NULL DEFAULT '0',
  `tickets_id_2` int(11) NOT NULL DEFAULT '0',
  `link` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `unicity` (`tickets_id_1`,`tickets_id_2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickets_users

DROP TABLE IF EXISTS `glpi_tickets_users`;
CREATE TABLE `glpi_tickets_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '1',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickets_users` VALUES ('1','1','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('2','2','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('3','3','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('4','4','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('5','5','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('6','6','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('7','7','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('8','8','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('9','9','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('10','10','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('11','11','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('12','12','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('13','13','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('14','14','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('15','15','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('16','16','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('17','17','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('18','18','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('19','19','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('20','20','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('21','21','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('22','22','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('23','23','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('24','24','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('25','25','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('26','26','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('27','27','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('28','28','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('29','29','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('30','30','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('31','31','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('32','32','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('33','33','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('34','34','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('35','35','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('36','36','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('37','37','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('38','38','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('39','39','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('40','40','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('41','41','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('42','42','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('43','43','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('44','44','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('45','45','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('46','46','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('47','47','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('48','48','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('49','49','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('50','50','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('51','51','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('52','52','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('53','53','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('54','54','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('55','55','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('56','56','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('57','57','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('58','58','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('59','59','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('60','60','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('61','61','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('62','62','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('63','63','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('64','64','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('65','65','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('66','66','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('67','67','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('68','68','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('69','69','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('70','70','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('71','71','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('72','72','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('73','73','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('74','74','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('75','75','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('76','76','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('77','77','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('78','78','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('79','79','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('80','80','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('81','81','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('82','82','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('83','83','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('84','84','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('85','85','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('86','86','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('87','87','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('88','88','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('89','89','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('90','90','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('91','91','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('92','92','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('93','93','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('94','94','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('95','95','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('96','96','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('97','97','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('98','98','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('99','99','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('100','100','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('101','101','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('102','102','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('103','103','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('104','104','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('105','105','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('106','106','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('107','107','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('108','108','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('109','109','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('110','110','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('111','111','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('112','112','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('113','113','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('114','114','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('115','115','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('116','116','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('117','117','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('118','118','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('119','119','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('120','120','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('121','121','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('122','122','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('123','123','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('124','124','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('125','125','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('126','126','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('127','127','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('128','128','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('129','129','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('130','130','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('131','131','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('132','132','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('133','133','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('134','134','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('135','135','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('136','136','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('137','137','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('138','138','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('139','139','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('140','140','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('141','141','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('142','142','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('143','143','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('144','144','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('145','145','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('146','146','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('147','147','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('148','148','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('149','149','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('150','150','2','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('151','150','2','2','1','');
INSERT INTO `glpi_tickets_users` VALUES ('152','151','2','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('153','151','2','2','1','');
INSERT INTO `glpi_tickets_users` VALUES ('154','152','2','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('155','152','2','2','1','');
INSERT INTO `glpi_tickets_users` VALUES ('156','152','6','2','1','');
INSERT INTO `glpi_tickets_users` VALUES ('157','151','6','2','1','');
INSERT INTO `glpi_tickets_users` VALUES ('158','150','6','2','1','');
INSERT INTO `glpi_tickets_users` VALUES ('159','153','6','1','1','itswrkb@oceanresortgroup.net');
INSERT INTO `glpi_tickets_users` VALUES ('160','154','6','1','1','itswrkb@oceanresortgroup.net');
INSERT INTO `glpi_tickets_users` VALUES ('161','155','6','1','1','itswrkb@oceanresortgroup.net');

### Dump table glpi_ticketsatisfactions

DROP TABLE IF EXISTS `glpi_ticketsatisfactions`;
CREATE TABLE `glpi_ticketsatisfactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `date_begin` datetime DEFAULT NULL,
  `date_answered` datetime DEFAULT NULL,
  `satisfaction` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettasks

DROP TABLE IF EXISTS `glpi_tickettasks`;
CREATE TABLE `glpi_tickettasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '1',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `is_private` (`is_private`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `state` (`state`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `begin` (`begin`),
  KEY `end` (`end`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettemplatehiddenfields

DROP TABLE IF EXISTS `glpi_tickettemplatehiddenfields`;
CREATE TABLE `glpi_tickettemplatehiddenfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettemplatemandatoryfields

DROP TABLE IF EXISTS `glpi_tickettemplatemandatoryfields`;
CREATE TABLE `glpi_tickettemplatemandatoryfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplatemandatoryfields` VALUES ('1','1','21');

### Dump table glpi_tickettemplatepredefinedfields

DROP TABLE IF EXISTS `glpi_tickettemplatepredefinedfields`;
CREATE TABLE `glpi_tickettemplatepredefinedfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettemplates

DROP TABLE IF EXISTS `glpi_tickettemplates`;
CREATE TABLE `glpi_tickettemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplates` VALUES ('1','Default','0','1',NULL);

### Dump table glpi_ticketvalidations

DROP TABLE IF EXISTS `glpi_ticketvalidations`;
CREATE TABLE `glpi_ticketvalidations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `users_id_validate` int(11) NOT NULL DEFAULT '0',
  `comment_submission` text COLLATE utf8_unicode_ci,
  `comment_validation` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `submission_date` datetime DEFAULT NULL,
  `validation_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id` (`users_id`),
  KEY `users_id_validate` (`users_id_validate`),
  KEY `tickets_id` (`tickets_id`),
  KEY `submission_date` (`submission_date`),
  KEY `validation_date` (`validation_date`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_transfers

DROP TABLE IF EXISTS `glpi_transfers`;
CREATE TABLE `glpi_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keep_ticket` int(11) NOT NULL DEFAULT '0',
  `keep_networklink` int(11) NOT NULL DEFAULT '0',
  `keep_reservation` int(11) NOT NULL DEFAULT '0',
  `keep_history` int(11) NOT NULL DEFAULT '0',
  `keep_device` int(11) NOT NULL DEFAULT '0',
  `keep_infocom` int(11) NOT NULL DEFAULT '0',
  `keep_dc_monitor` int(11) NOT NULL DEFAULT '0',
  `clean_dc_monitor` int(11) NOT NULL DEFAULT '0',
  `keep_dc_phone` int(11) NOT NULL DEFAULT '0',
  `clean_dc_phone` int(11) NOT NULL DEFAULT '0',
  `keep_dc_peripheral` int(11) NOT NULL DEFAULT '0',
  `clean_dc_peripheral` int(11) NOT NULL DEFAULT '0',
  `keep_dc_printer` int(11) NOT NULL DEFAULT '0',
  `clean_dc_printer` int(11) NOT NULL DEFAULT '0',
  `keep_supplier` int(11) NOT NULL DEFAULT '0',
  `clean_supplier` int(11) NOT NULL DEFAULT '0',
  `keep_contact` int(11) NOT NULL DEFAULT '0',
  `clean_contact` int(11) NOT NULL DEFAULT '0',
  `keep_contract` int(11) NOT NULL DEFAULT '0',
  `clean_contract` int(11) NOT NULL DEFAULT '0',
  `keep_software` int(11) NOT NULL DEFAULT '0',
  `clean_software` int(11) NOT NULL DEFAULT '0',
  `keep_document` int(11) NOT NULL DEFAULT '0',
  `clean_document` int(11) NOT NULL DEFAULT '0',
  `keep_cartridgeitem` int(11) NOT NULL DEFAULT '0',
  `clean_cartridgeitem` int(11) NOT NULL DEFAULT '0',
  `keep_cartridge` int(11) NOT NULL DEFAULT '0',
  `keep_consumable` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `keep_disk` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_transfers` VALUES ('1','complete','2','2','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1',NULL,NULL,'1');

### Dump table glpi_usercategories

DROP TABLE IF EXISTS `glpi_usercategories`;
CREATE TABLE `glpi_usercategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_useremails

DROP TABLE IF EXISTS `glpi_useremails`;
CREATE TABLE `glpi_useremails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`email`),
  KEY `email` (`email`),
  KEY `is_default` (`is_default`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_useremails` VALUES ('1','2','1','0','suthamtg@gmail.com');
INSERT INTO `glpi_useremails` VALUES ('2','6','1','0','itswrkb@oceanresortgroup.net');

### Dump table glpi_users

DROP TABLE IF EXISTS `glpi_users`;
CREATE TABLE `glpi_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `language` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php CFG_GLPI[language] array',
  `use_mode` int(11) NOT NULL DEFAULT '0',
  `list_limit` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `auths_id` int(11) NOT NULL DEFAULT '0',
  `authtype` int(11) NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_sync` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `usertitles_id` int(11) NOT NULL DEFAULT '0',
  `usercategories_id` int(11) NOT NULL DEFAULT '0',
  `date_format` int(11) DEFAULT NULL,
  `number_format` int(11) DEFAULT NULL,
  `names_format` int(11) DEFAULT NULL,
  `csv_delimiter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_ids_visible` tinyint(1) DEFAULT NULL,
  `use_flat_dropdowntree` tinyint(1) DEFAULT NULL,
  `show_jobs_at_login` tinyint(1) DEFAULT NULL,
  `priority_1` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_2` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_3` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_4` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_5` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_6` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `followup_private` tinyint(1) DEFAULT NULL,
  `task_private` tinyint(1) DEFAULT NULL,
  `default_requesttypes_id` int(11) DEFAULT NULL,
  `password_forget_token` char(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_forget_token_date` datetime DEFAULT NULL,
  `user_dn` text COLLATE utf8_unicode_ci,
  `registration_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_count_on_tabs` tinyint(1) DEFAULT NULL,
  `refresh_ticket_list` int(11) DEFAULT NULL,
  `set_default_tech` tinyint(1) DEFAULT NULL,
  `personal_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal_token_date` datetime DEFAULT NULL,
  `display_count_on_home` int(11) DEFAULT NULL,
  `notification_to_myself` tinyint(1) DEFAULT NULL,
  `duedateok_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatewarning_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatecritical_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatewarning_less` int(11) DEFAULT NULL,
  `duedatecritical_less` int(11) DEFAULT NULL,
  `duedatewarning_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatecritical_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_options` text COLLATE utf8_unicode_ci,
  `is_deleted_ldap` tinyint(1) NOT NULL DEFAULT '0',
  `pdffont` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `keep_devices_when_purging_item` tinyint(1) DEFAULT NULL,
  `privatebookmarkorder` longtext COLLATE utf8_unicode_ci,
  `backcreated` tinyint(1) DEFAULT NULL,
  `task_state` int(11) DEFAULT NULL,
  `layout` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `palette` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ticket_timeline` tinyint(1) DEFAULT NULL,
  `ticket_timeline_keep_replaced_tabs` tinyint(1) DEFAULT NULL,
  `set_default_requester` tinyint(1) DEFAULT NULL,
  `lock_autolock_mode` tinyint(1) DEFAULT NULL,
  `lock_directunlock_notification` tinyint(1) DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `highcontrast_css` tinyint(1) DEFAULT '0',
  `plannings` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`name`),
  KEY `firstname` (`firstname`),
  KEY `realname` (`realname`),
  KEY `entities_id` (`entities_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `locations_id` (`locations_id`),
  KEY `usertitles_id` (`usertitles_id`),
  KEY `usercategories_id` (`usercategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `authitem` (`authtype`,`auths_id`),
  KEY `is_deleted_ldap` (`is_deleted_ldap`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_users` VALUES ('2','dong','$2y$10$jfrRihrrGm02oPJkmQvfOuTHxcQB3MSYldviod9ZcZG47QSnVmLsa','','','','','itsunwing','0',NULL,'0','20','1',NULL,'0','1','2017-02-10 09:20:04','2017-02-05 03:32:14',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'');
INSERT INTO `glpi_users` VALUES ('3','post-only','$2y$10$.V165TgZOCunVFpFItcLEOHCqYOwVSYr69YgUE61CJLB1DT6WsUci','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','0',NULL,'2017-02-06 04:15:50',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','');
INSERT INTO `glpi_users` VALUES ('4','tech','$2y$10$74DOc255tRkxR/IXoGtkT.0Z1RUIILYCRXoHXlniXr.yiIhymnDLS','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','0',NULL,'2017-02-06 04:16:03',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','');
INSERT INTO `glpi_users` VALUES ('5','normal','$2y$10$yCms6pDHh/RXUQgojWsAvOS8A4TDTVBf5oVIzYAy5A0tuqEVClATK','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','0',NULL,'2017-02-06 04:15:33',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','');
INSERT INTO `glpi_users` VALUES ('6','sutham','$2y$10$6YZq7VEn0Cvb9ITA7.GDBOuavDLrCgXRkEyDPayDkEXVhO4un9tO6','7961','','0987021699','Manassrisuksai','Sutham','0',NULL,'0',NULL,'1','','0','1','2017-02-10 09:08:20','2017-02-06 04:26:21',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'g58hryglkek1lmgi4sqm4l63que32re4eqdiccg4','2017-02-06 04:26:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'2017-02-06 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-02-06 04:19:25',NULL,NULL);

### Dump table glpi_usertitles

DROP TABLE IF EXISTS `glpi_usertitles`;
CREATE TABLE `glpi_usertitles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinestates

DROP TABLE IF EXISTS `glpi_virtualmachinestates`;
CREATE TABLE `glpi_virtualmachinestates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinesystems

DROP TABLE IF EXISTS `glpi_virtualmachinesystems`;
CREATE TABLE `glpi_virtualmachinesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinetypes

DROP TABLE IF EXISTS `glpi_virtualmachinetypes`;
CREATE TABLE `glpi_virtualmachinetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_vlans

DROP TABLE IF EXISTS `glpi_vlans`;
CREATE TABLE `glpi_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `tag` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `tag` (`tag`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_wifinetworks

DROP TABLE IF EXISTS `glpi_wifinetworks`;
CREATE TABLE `glpi_wifinetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `essid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ad-hoc, access_point',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `essid` (`essid`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

